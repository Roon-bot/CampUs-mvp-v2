export type RecipientType = 'all' | 'group' | 'person';

export type ScreenTab = 'comunicacion' | 'apuntes' | 'acuerdos';

export interface Member {
  id: string;
  name: string;
  fullName: string;
  role: string;
  status: 'online' | 'in_class' | 'busy' | string;
  statusLabel: string;
  avatarBg: string;
  initials: string;
}

export interface Group {
  id: string;
  name: string;
  shortName: string;
  membersCount: number;
  description: string;
  code: string;
  tagColor: string;
}

export interface Transmission {
  id: string;
  recipientType: RecipientType;
  recipientName: string;
  targetLabel: string;
  timestamp: string;
  timeAgo: string;
  durationSeconds: number;
  summary: string;
  detail?: string;
  channel: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  category: string;
  createdAt: string;
  author: string;
  course?: string;
  week?: string;
}

export interface Agreement {
  id: string;
  description: string;
  assignee: string;
  deadline: string;
  status: 'pending' | 'completed';
  createdAt: string;
  course: string;
  week: string;
}

