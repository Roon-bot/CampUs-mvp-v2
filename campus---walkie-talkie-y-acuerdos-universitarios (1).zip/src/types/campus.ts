/**
 * Tipos de datos para CampUs - Prototipo Maestro
 */

export type NavigationTab = 
  | 'inicio' 
  | 'comunicacion' 
  | 'apuntes' 
  | 'acuerdos' 
  | 'pizarra' 
  | 'historial' 
  | 'configuracion';

export type RecipientType = 'all' | 'group' | 'person';

export interface Participant {
  id: string;
  name: string;
  fullName: string;
  role: string;
  initials: string;
  avatarBg: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
}

export interface Course {
  id: string;
  name: string;
  code: string;
  color: string;
  projects: Project[];
}

export interface AcademicSettings {
  startDate: string; // YYYY-MM-DD
  totalWeeks: number; // Por defecto 16
  courses: Course[];
}

export interface WalkieTransmission {
  id: string;
  recipientType: RecipientType;
  recipientName: string;
  targetLabel: string;
  timestamp: string; // HH:mm
  durationSeconds: number;
  summary: string;
  detail: string;
}

export interface SimulatedRecording {
  id: string;
  durationSeconds: number;
  startTime: string;
  endTime: string;
  status: 'completed' | 'none';
  audioSimulatedUrl?: string;
  consentConfirmed: boolean;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  author: string;
  createdAt: string; // Formatted date/time
  courseId: string;
  courseName: string;
  projectId?: string;
  projectName?: string;
  weekNumber: number;
  meetingId?: string;
}

export interface AgreementItem {
  id: string;
  description: string;
  assignee: string;
  deadline: string;
  status: 'pending' | 'completed';
  createdAt: string;
  courseId: string;
  courseName: string;
  projectId?: string;
  projectName?: string;
  weekNumber: number;
  meetingId?: string;
}

export interface DrawingItem {
  id: string;
  dataUrl: string; // Base64 data URL
  title: string;
  createdAt: string;
  meetingId?: string;
  courseId: string;
  weekNumber: number;
}

export interface MeetingSession {
  id: string;
  courseId: string;
  courseName: string;
  projectId: string;
  projectName: string;
  groupName: string;
  participants: Participant[];
  startDate: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endDate?: string;
  endTime?: string;
  weekNumber: number;
  durationSeconds: number;
  walkieTransmissions: WalkieTransmission[];
  recording?: SimulatedRecording;
  notes: NoteItem[];
  agreements: AgreementItem[];
  drawings: DrawingItem[];
  status: 'active' | 'completed';
}
