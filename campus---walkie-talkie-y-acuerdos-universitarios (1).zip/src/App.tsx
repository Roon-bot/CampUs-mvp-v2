/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { WalkieTalkieView } from './components/WalkieTalkieView';
import { NotesView } from './components/NotesView';
import { AgreementsView } from './components/AgreementsView';
import { WhiteboardView } from './components/WhiteboardView';
import { HistoryView } from './components/HistoryView';
import { AcademicConfigView } from './components/AcademicConfigView';
import { StartMeetingModal } from './components/StartMeetingModal';
import { EndMeetingModal } from './components/EndMeetingModal';

import { 
  NavigationTab, 
  AcademicSettings, 
  MeetingSession, 
  NoteItem, 
  AgreementItem, 
  DrawingItem, 
  WalkieTransmission, 
  SimulatedRecording 
} from './types/campus';
import { 
  INITIAL_ACADEMIC_SETTINGS, 
  INITIAL_MEETINGS_HISTORY,
  EXACT_VALUE_PROMISE 
} from './config/initialData';
import { soundEffects } from './utils/sound';
import { formatTime } from './utils/academic';
import { downloadMeetingZip } from './utils/zipExport';
import { CheckCircle2, Smartphone, Monitor } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('inicio');
  const [isPhoneFrameActive, setIsPhoneFrameActive] = useState(true);
  const [isStartMeetingModalOpen, setIsStartMeetingModalOpen] = useState(false);
  const [isEndMeetingModalOpen, setIsEndMeetingModalOpen] = useState(false);
  const [selectedMeetingDetail, setSelectedMeetingDetail] = useState<MeetingSession | null>(null);
  const [saveSuccessNotification, setSaveSuccessNotification] = useState<string | null>(null);

  // Sound settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const s = localStorage.getItem('campus_sound');
      return s !== null ? JSON.parse(s) : true;
    } catch {
      return true;
    }
  });

  // Academic Settings
  const [settings, setSettings] = useState<AcademicSettings>(() => {
    try {
      const s = localStorage.getItem('campus_academic_settings');
      return s ? JSON.parse(s) : INITIAL_ACADEMIC_SETTINGS;
    } catch {
      return INITIAL_ACADEMIC_SETTINGS;
    }
  });

  // Meetings History
  const [meetings, setMeetings] = useState<MeetingSession[]>(() => {
    try {
      const m = localStorage.getItem('campus_meetings_history');
      return m ? JSON.parse(m) : INITIAL_MEETINGS_HISTORY;
    } catch {
      return INITIAL_MEETINGS_HISTORY;
    }
  });

  // Active Meeting Session
  const [activeMeeting, setActiveMeeting] = useState<MeetingSession | null>(() => {
    try {
      const a = localStorage.getItem('campus_active_meeting');
      return a ? JSON.parse(a) : null;
    } catch {
      return null;
    }
  });

  // Global Notes (collected from meetings + loose notes)
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const n = localStorage.getItem('campus_global_notes');
      if (n) return JSON.parse(n);
      // Seed from initial meetings
      return INITIAL_MEETINGS_HISTORY.flatMap((m) => m.notes);
    } catch {
      return [];
    }
  });

  // Global Agreements (collected from meetings + loose agreements)
  const [agreements, setAgreements] = useState<AgreementItem[]>(() => {
    try {
      const a = localStorage.getItem('campus_global_agreements');
      if (a) return JSON.parse(a);
      // Seed from initial meetings
      return INITIAL_MEETINGS_HISTORY.flatMap((m) => m.agreements);
    } catch {
      return [];
    }
  });

  // Active meeting drawings buffer
  const [activeDrawings, setActiveDrawings] = useState<DrawingItem[]>([]);

  // Timer for active meeting duration
  useEffect(() => {
    let interval: number | null = null;
    if (activeMeeting) {
      interval = window.setInterval(() => {
        setActiveMeeting((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            durationSeconds: (prev.durationSeconds || 0) + 1,
          };
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeMeeting?.id]);

  // Persist State Changes
  useEffect(() => {
    soundEffects.enabled = soundEnabled;
    try {
      localStorage.setItem('campus_sound', JSON.stringify(soundEnabled));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [soundEnabled]);

  useEffect(() => {
    try {
      localStorage.setItem('campus_academic_settings', JSON.stringify(settings));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem('campus_meetings_history', JSON.stringify(meetings));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [meetings]);

  useEffect(() => {
    try {
      localStorage.setItem('campus_active_meeting', JSON.stringify(activeMeeting));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [activeMeeting]);

  useEffect(() => {
    try {
      localStorage.setItem('campus_global_notes', JSON.stringify(notes));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [notes]);

  useEffect(() => {
    try {
      localStorage.setItem('campus_global_agreements', JSON.stringify(agreements));
    } catch (e) {
      console.warn('Storage error', e);
    }
  }, [agreements]);

  // Handle Starting a Meeting
  const handleStartMeeting = (meetingData: Omit<MeetingSession, 'id' | 'walkieTransmissions' | 'notes' | 'agreements' | 'drawings' | 'status' | 'durationSeconds'>) => {
    const newSession: MeetingSession = {
      ...meetingData,
      id: `meet-${Date.now()}`,
      durationSeconds: 0,
      walkieTransmissions: [],
      notes: [],
      agreements: [],
      drawings: [],
      status: 'active',
    };

    setActiveMeeting(newSession);
    setActiveDrawings([]);
    setActiveTab('comunicacion');
    setSaveSuccessNotification(`Reunión iniciada: ${newSession.courseName}`);
    setTimeout(() => setSaveSuccessNotification(null), 3500);
  };

  // Handle Ending a Meeting (Section 12)
  const handleConfirmEndMeeting = () => {
    if (!activeMeeting) return;

    const now = new Date();
    const todayStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
    const endTimeStr = formatTime(now);

    const completedSession: MeetingSession = {
      ...activeMeeting,
      endDate: todayStr,
      endTime: endTimeStr,
      status: 'completed',
      drawings: [...activeMeeting.drawings, ...activeDrawings],
    };

    // Save to meetings history
    setMeetings((prev) => [completedSession, ...prev]);

    // Clear active session
    setActiveMeeting(null);
    setActiveDrawings([]);
    setIsEndMeetingModalOpen(false);
    setActiveTab('historial');

    // Descarga automática en formato ZIP con Curso, Semana y Fecha en el dispositivo
    downloadMeetingZip(completedSession)
      .then((fileName) => {
        setSaveSuccessNotification(`¡Reunión guardada! Se descargó automáticamente: ${fileName}`);
        setTimeout(() => setSaveSuccessNotification(null), 6000);
      })
      .catch((err) => {
        console.error('Error al generar ZIP automático:', err);
        setSaveSuccessNotification('Reunión guardada correctamente en el historial');
        setTimeout(() => setSaveSuccessNotification(null), 4000);
      });
  };

  // Walkie-Talkie Transmissions handler
  const handleAddTransmission = (tx: WalkieTransmission) => {
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          walkieTransmissions: [tx, ...prev.walkieTransmissions],
        };
      });
    }
  };

  // Recording update handler
  const handleUpdateRecording = (rec: SimulatedRecording) => {
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          recording: rec,
        };
      });
    }
  };

  // Notes handlers
  const handleAddNote = (note: NoteItem) => {
    setNotes((prev) => [note, ...prev]);
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          notes: [note, ...prev.notes],
        };
      });
    }
  };

  const handleUpdateNote = (updatedNote: NoteItem) => {
    setNotes((prev) => prev.map((n) => (n.id === updatedNote.id ? updatedNote : n)));
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          notes: prev.notes.map((n) => (n.id === updatedNote.id ? updatedNote : n)),
        };
      });
    }
  };

  const handleDeleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          notes: prev.notes.filter((n) => n.id !== id),
        };
      });
    }
  };

  // Agreements handlers
  const handleAddAgreement = (agr: AgreementItem) => {
    setAgreements((prev) => [agr, ...prev]);
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          agreements: [agr, ...prev.agreements],
        };
      });
    }
  };

  const handleUpdateAgreement = (updatedAgr: AgreementItem) => {
    setAgreements((prev) => prev.map((a) => (a.id === updatedAgr.id ? updatedAgr : a)));
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          agreements: prev.agreements.map((a) => (a.id === updatedAgr.id ? updatedAgr : a)),
        };
      });
    }
  };

  const handleToggleAgreementStatus = (id: string) => {
    setAgreements((prev) =>
      prev.map((a) =>
        a.id === id
          ? { ...a, status: a.status === 'completed' ? 'pending' : 'completed' }
          : a
      )
    );
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          agreements: prev.agreements.map((a) =>
            a.id === id
              ? { ...a, status: a.status === 'completed' ? 'pending' : 'completed' }
              : a
          ),
        };
      });
    }
  };

  const handleDeleteAgreement = (id: string) => {
    setAgreements((prev) => prev.filter((a) => a.id !== id));
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          agreements: prev.agreements.filter((a) => a.id !== id),
        };
      });
    }
  };

  // Drawing handler
  const handleSaveDrawingToMeeting = (drawing: DrawingItem) => {
    setActiveDrawings((prev) => [drawing, ...prev]);
    if (activeMeeting) {
      setActiveMeeting((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          drawings: [drawing, ...prev.drawings],
        };
      });
    }
  };

  const pendingAgreementsCount = agreements.filter((a) => a.status === 'pending').length;

  return (
    <div className="min-h-screen bg-[#0d121f] text-slate-900 flex flex-col items-center justify-start antialiased selection:bg-[#6857E8] selection:text-white">
      {/* Top Demo Bar for Evaluators (allows toggling mobile frame vs fluid desktop layout) */}
      <div className="w-full max-w-4xl px-4 py-2 flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/80 z-20">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#42C99A] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#42C99A]"></span>
          </span>
          <span className="font-extrabold text-slate-200">CampUs</span>
          <span className="hidden sm:inline text-slate-500">| Prototipo Interactivo Universitario</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsPhoneFrameActive(!isPhoneFrameActive)}
            className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800"
            title="Alternar marco de celular"
          >
            {isPhoneFrameActive ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-[#4778F5]" />
                <span className="hidden sm:inline">Vista extendida</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-[#42C99A]" />
                <span className="hidden sm:inline">Marco móvil</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container */}
      <main className="w-full flex-1 flex justify-center py-1 sm:py-6 px-0 sm:px-4">
        <div
          className={`w-full flex flex-col bg-[#F5F6FA] transition-all relative ${
            isPhoneFrameActive
              ? 'max-w-[430px] rounded-none sm:rounded-[44px] shadow-2xl border-0 sm:border-8 sm:border-slate-800 overflow-hidden min-h-[820px]'
              : 'max-w-md rounded-none sm:rounded-3xl shadow-xl border border-slate-800 min-h-[740px]'
          }`}
        >
          {/* Smartphone Speaker / Island on desktop */}
          {isPhoneFrameActive && (
            <div className="hidden sm:flex justify-center items-center h-5 bg-[#111827] w-full pt-1">
              <div className="w-24 h-3 bg-slate-950 rounded-full flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
              </div>
            </div>
          )}

          {/* Persistent Top Header */}
          <Header
            settings={settings}
            activeMeeting={activeMeeting}
            currentTab={activeTab}
            soundEnabled={soundEnabled}
            onToggleSound={() => setSoundEnabled(!soundEnabled)}
            onNavigate={setActiveTab}
            onOpenEndMeetingModal={() => setIsEndMeetingModalOpen(true)}
          />

          {/* Success Notification Banner */}
          {saveSuccessNotification && (
            <div className="sticky top-0 z-40 mx-3 mt-2 p-3 bg-emerald-600 text-white font-extrabold text-xs rounded-2xl shadow-lg flex items-center justify-center gap-2 animate-in slide-in-from-top-2 duration-200">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{saveSuccessNotification}</span>
            </div>
          )}

          {/* VIEW SWITCHER FOR THE 7 CORE SECTIONS */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'inicio' && (
              <HomeView
                settings={settings}
                meetings={meetings}
                agreements={agreements}
                activeMeeting={activeMeeting}
                onOpenStartMeetingModal={() => setIsStartMeetingModalOpen(true)}
                onNavigate={setActiveTab}
                onSelectMeetingDetail={(m) => {
                  setSelectedMeetingDetail(m);
                  setActiveTab('historial');
                }}
              />
            )}

            {activeTab === 'comunicacion' && (
              <WalkieTalkieView
                activeMeeting={activeMeeting}
                onAddTransmission={handleAddTransmission}
                onUpdateRecording={handleUpdateRecording}
                onOpenStartMeetingModal={() => setIsStartMeetingModalOpen(true)}
              />
            )}

            {activeTab === 'apuntes' && (
              <NotesView
                notes={notes}
                activeMeeting={activeMeeting}
                settings={settings}
                onAddNote={handleAddNote}
                onUpdateNote={handleUpdateNote}
                onDeleteNote={handleDeleteNote}
              />
            )}

            {activeTab === 'acuerdos' && (
              <AgreementsView
                agreements={agreements}
                activeMeeting={activeMeeting}
                settings={settings}
                onAddAgreement={handleAddAgreement}
                onUpdateAgreement={handleUpdateAgreement}
                onToggleStatus={handleToggleAgreementStatus}
                onDeleteAgreement={handleDeleteAgreement}
              />
            )}

            {activeTab === 'pizarra' && (
              <WhiteboardView
                activeMeeting={activeMeeting}
                onSaveDrawingToMeeting={handleSaveDrawingToMeeting}
                savedDrawings={activeMeeting ? [...activeMeeting.drawings, ...activeDrawings] : activeDrawings}
              />
            )}

            {activeTab === 'historial' && (
              <HistoryView
                meetings={meetings}
                settings={settings}
                selectedMeetingDetail={selectedMeetingDetail}
                onSelectMeetingDetail={setSelectedMeetingDetail}
              />
            )}

            {activeTab === 'configuracion' && (
              <AcademicConfigView
                settings={settings}
                onSaveSettings={setSettings}
              />
            )}
          </div>

          {/* Fixed Bottom Navigation */}
          <BottomNav
            activeTab={activeTab}
            onNavigate={setActiveTab}
            activeMeeting={activeMeeting}
            onOpenEndMeetingModal={() => setIsEndMeetingModalOpen(true)}
            pendingAgreementsCount={pendingAgreementsCount}
          />
        </div>
      </main>

      {/* Start Meeting Modal */}
      <StartMeetingModal
        isOpen={isStartMeetingModalOpen}
        onClose={() => setIsStartMeetingModalOpen(false)}
        settings={settings}
        onStartMeeting={handleStartMeeting}
      />

      {/* End Meeting Modal */}
      <EndMeetingModal
        isOpen={isEndMeetingModalOpen}
        onClose={() => setIsEndMeetingModalOpen(false)}
        activeMeeting={activeMeeting}
        onConfirmEndMeeting={handleConfirmEndMeeting}
      />
    </div>
  );
}
