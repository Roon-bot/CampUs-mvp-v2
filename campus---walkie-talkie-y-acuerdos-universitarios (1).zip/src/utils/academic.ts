/**
 * Utilidades para cálculo académico y fechas en CampUs
 */

export interface WeekCalculationResult {
  weekNumber: number;
  status: 'before' | 'active' | 'finished';
  label: string;
  daysElapsed: number;
}

/**
 * Calcula la semana académica según la fórmula exacta del requerimiento:
 * weekNumber = 1 + Math.floor((currentDate - semesterStartDate) / (7 * 24 * 60 * 60 * 1000))
 */
export function calculateAcademicWeek(
  startDateStr: string,
  totalWeeks: number = 16,
  targetDate: Date = new Date()
): WeekCalculationResult {
  if (!startDateStr) {
    return {
      weekNumber: 1,
      status: 'active',
      label: 'Semana 1',
      daysElapsed: 0,
    };
  }

  // Parsear fecha local sin desfase de zona horaria (año, mes - 1, día a las 00:00:00)
  const parts = startDateStr.split('-').map(Number);
  if (parts.length !== 3) {
    return { weekNumber: 1, status: 'active', label: 'Semana 1', daysElapsed: 0 };
  }

  const semesterStartDate = new Date(parts[0], parts[1] - 1, parts[2], 0, 0, 0, 0);
  const currentDate = new Date(
    targetDate.getFullYear(),
    targetDate.getMonth(),
    targetDate.getDate(),
    0,
    0,
    0,
    0
  );

  const diffMs = currentDate.getTime() - semesterStartDate.getTime();
  const ONE_DAY_MS = 24 * 60 * 60 * 1000;
  const ONE_WEEK_MS = 7 * ONE_DAY_MS;

  const daysElapsed = Math.floor(diffMs / ONE_DAY_MS);

  if (diffMs < 0) {
    const daysUntil = Math.abs(daysElapsed);
    return {
      weekNumber: 0,
      status: 'before',
      label: `Antes del inicio del ciclo (inicia en ${daysUntil} ${daysUntil === 1 ? 'día' : 'días'})`,
      daysElapsed,
    };
  }

  const calculatedWeek = 1 + Math.floor(diffMs / ONE_WEEK_MS);

  if (calculatedWeek > totalWeeks) {
    return {
      weekNumber: totalWeeks,
      status: 'finished',
      label: `Ciclo finalizado (${totalWeeks} semanas concluidas)`,
      daysElapsed,
    };
  }

  return {
    weekNumber: calculatedWeek,
    status: 'active',
    label: `Semana ${calculatedWeek}`,
    daysElapsed,
  };
}

/**
 * Formatea la fecha actual en español legible (ej. "Jueves, 15 de Octubre de 2026")
 */
export function formatLongDate(date: Date = new Date()): string {
  const options: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  };
  const str = date.toLocaleDateString('es-ES', options);
  // Capitalizar primera letra
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Formatea la hora actual (ej. "17:45")
 */
export function formatTime(date: Date = new Date()): string {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Convierte segundos a formato MM:SS
 */
export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
