import JSZip from 'jszip';
import { MeetingSession } from '../types/campus';
import { formatDuration } from './academic';

/**
 * Limpia cadenas de texto para nombres seguros de archivo
 */
function sanitizeFileName(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_\-]/g, '_')
    .replace(/_+/g, '_')
    .slice(0, 40);
}

/**
 * Convierte un Data URL (base64 o SVG) en Blob o binario para JSZip
 */
function dataUrlToBinary(dataUrl: string): { data: string | Uint8Array; extension: string; isBase64: boolean } {
  if (dataUrl.startsWith('data:image/png;base64,')) {
    return {
      data: dataUrl.replace('data:image/png;base64,', ''),
      extension: 'png',
      isBase64: true,
    };
  }
  if (dataUrl.startsWith('data:image/jpeg;base64,')) {
    return {
      data: dataUrl.replace('data:image/jpeg;base64,', ''),
      extension: 'jpg',
      isBase64: true,
    };
  }
  if (dataUrl.startsWith('data:image/svg+xml')) {
    // Si viene codificado en SVG URL
    const svgContent = decodeURIComponent(dataUrl.replace(/^data:image\/svg\+xml(;\w+=\w+)*,/, ''));
    return {
      data: svgContent,
      extension: 'svg',
      isBase64: false,
    };
  }

  // Fallback si es base64 genérico
  const parts = dataUrl.split(',');
  if (parts.length === 2) {
    return {
      data: parts[1],
      extension: 'png',
      isBase64: true,
    };
  }

  return {
    data: dataUrl,
    extension: 'txt',
    isBase64: false,
  };
}

/**
 * Genera el paquete ZIP con todos los archivos de la reunión
 * incluyendo curso, semana, fecha, apuntes libres, acuerdos, grabaciones y pizarra
 */
export async function generateMeetingZip(session: MeetingSession): Promise<{ blob: Blob; fileName: string }> {
  const zip = new JSZip();

  const safeCourse = sanitizeFileName(session.courseName || 'Curso');
  const safeWeek = session.weekNumber || 1;
  const safeDate = sanitizeFileName(session.startDate || session.endDate || new Date().toISOString().slice(0, 10));
  const zipFileName = `CampUs_${safeCourse}_Semana${safeWeek}_${safeDate}.zip`;

  // 1. Resumen General de la Reunión
  const participantsList = session.participants?.length
    ? session.participants.map((p) => `  - ${p.fullName} (${p.role})`).join('\n')
    : '  - Carlos Morales (Coordinador)\n  - Integrantes del equipo';

  const pendingAgreements = session.agreements.filter((a) => a.status === 'pending');
  const completedAgreements = session.agreements.filter((a) => a.status === 'completed');

  const summaryContent = `======================================================================
CAMPUS — REGISTRO ACADÉMICO CONSOLIDADO DE REUNIÓN
======================================================================
Curso:            ${session.courseName}
Semana Académica: Semana ${session.weekNumber}
Fecha de Sesión:  ${session.startDate || safeDate}
Horario:          ${session.startTime || '--:--'} - ${session.endTime || '--:--'}
Duración Total:   ${formatDuration(session.durationSeconds || 0)}
Proyecto:         ${session.projectName}
Equipo / Grupo:   ${session.groupName}
Estado:           ${session.status === 'completed' ? 'Finalizada y Registrada' : 'En Curso'}

PARTICIPANTES:
${participantsList}

RESUMEN DE ARCHIVOS Y CONTENIDOS ADJUNTOS EN ESTE PAQUETE:
- 01_APUNTES_BLOCK_DE_NOTAS.txt : ${session.notes.length} apunte(s) registrados libremente
- 02_ACUERDOS_Y_COMPROMISOS.txt : ${session.agreements.length} acuerdo(s) (${pendingAgreements.length} pendientes, ${completedAgreements.length} cumplidos)
- 03_HISTORIAL_WALKIE_TALKIE.txt: ${session.walkieTransmissions.length} transmisión(es) de voz rápida
- 04_REGISTRO_GRABACION.txt     : ${session.recording?.status === 'completed' ? `Grabación registrada (${formatDuration(session.recording.durationSeconds)})` : 'Sin grabación'}
- Carpeta PIZARRA_BOCETOS/      : ${session.drawings.length} boceto(s) / esquema(s) de la pizarra infinita
- 05_METADATOS_CAMPUS.json      : Datos estructurados completos en formato JSON

PROMESA CAMPUS:
"Para estudiantes que hacen trabajos grupales, CampUs permite hablar por voz con una persona, un grupo o todo el equipo, grabar la reunión y guardar sus apuntes, acuerdos y dibujos por curso y semana para encontrar lo trabajado en menos de un minuto."
======================================================================
Generado automáticamente por CampUs el ${new Date().toLocaleString('es-ES')}
`;

  zip.file('00_RESUMEN_REUNION.txt', summaryContent);

  // 2. Apuntes de Block de Notas Libre
  let notesContent = `======================================================================
CAMPUS — BLOCK DE NOTAS LIBRE DE LA REUNIÓN
Curso: ${session.courseName} | Semana: ${session.weekNumber} | Fecha: ${session.startDate}
======================================================================\n\n`;

  if (session.notes.length === 0) {
    notesContent += 'No se redactaron apuntes durante esta sesión.\n';
  } else {
    session.notes.forEach((note, index) => {
      notesContent += `----------------------------------------------------------------------
[APUNTE #${index + 1}] ${note.title.toUpperCase()}
Autor: ${note.author} | Registrado: ${note.createdAt}
----------------------------------------------------------------------
${note.content}

\n`;
    });
  }

  zip.file('01_APUNTES_BLOCK_DE_NOTAS.txt', notesContent);

  // 3. Acuerdos y Compromisos
  let agreementsContent = `======================================================================
CAMPUS — ACUERDOS Y RESPONSABLES
Curso: ${session.courseName} | Semana: ${session.weekNumber} | Fecha: ${session.startDate}
======================================================================\n\n`;

  if (session.agreements.length === 0) {
    agreementsContent += 'No se registraron acuerdos formalmente en esta sesión.\n';
  } else {
    session.agreements.forEach((agr, index) => {
      const statusLabel = agr.status === 'completed' ? '[✓ COMPLETADO]' : '[! PENDIENTE]';
      agreementsContent += `${index + 1}. ${statusLabel} ${agr.description}\n`;
      agreementsContent += `   Responsable: ${agr.assignee}\n`;
      agreementsContent += `   Plazo / Entrega: ${agr.deadline}\n`;
      agreementsContent += `   Registrado el: ${agr.createdAt}\n\n`;
    });
  }

  zip.file('02_ACUERDOS_Y_COMPROMISOS.txt', agreementsContent);

  // 4. Transmisiones Walkie-Talkie
  let walkieContent = `======================================================================
CAMPUS — REGISTRO DE COMUNICACIÓN RÁPIDA WALKIE-TALKIE
Curso: ${session.courseName} | Semana: ${session.weekNumber} | Fecha: ${session.startDate}
======================================================================\n\n`;

  if (session.walkieTransmissions.length === 0) {
    walkieContent += 'No se realizaron transmisiones de voz durante esta sesión.\n';
  } else {
    session.walkieTransmissions.forEach((tx, index) => {
      walkieContent += `[TX #${index + 1}] ${tx.timestamp} (${tx.durationSeconds} seg) -> ${tx.targetLabel}\n`;
      walkieContent += `  Tipo: ${tx.recipientType.toUpperCase()} | Destinatario: ${tx.recipientName}\n`;
      walkieContent += `  Detalle: ${tx.detail || tx.summary}\n\n`;
    });
  }

  zip.file('03_HISTORIAL_WALKIE_TALKIE.txt', walkieContent);

  // 5. Registro de Grabación de Sesión
  let recContent = `======================================================================
CAMPUS — REGISTRO DE GRABACIÓN DE SESIÓN (SIMULACIÓN)
Curso: ${session.courseName} | Semana: ${session.weekNumber} | Fecha: ${session.startDate}
======================================================================\n\n`;

  if (session.recording && session.recording.status === 'completed') {
    recContent += `Estado: REGISTRADA CON ÉXITO\n`;
    recContent += `Duración: ${formatDuration(session.recording.durationSeconds)} (${session.recording.durationSeconds} segundos)\n`;
    recContent += `Hora Inicio: ${session.recording.startTime}\n`;
    recContent += `Hora Fin: ${session.recording.endTime}\n`;
    recContent += `Consentimiento de participantes: SÍ (Aprobado antes de iniciar)\n`;
    recContent += `Nota: Simulación de audio registrada dentro del paquete de la sesión.\n`;
  } else {
    recContent += `No se activó la grabación continua durante esta sesión.\n`;
  }

  zip.file('04_REGISTRO_GRABACION.txt', recContent);

  // 6. Bocetos y Dibujos de la Pizarra Infinita
  if (session.drawings && session.drawings.length > 0) {
    const drawingsFolder = zip.folder('PIZARRA_BOCETOS');
    if (drawingsFolder) {
      session.drawings.forEach((drawing, idx) => {
        const { data, extension, isBase64 } = dataUrlToBinary(drawing.dataUrl);
        const fileName = `boceto_${idx + 1}_${sanitizeFileName(drawing.title || 'pizarra')}.${extension}`;
        drawingsFolder.file(fileName, data, { base64: isBase64 });
      });
    }
  }

  // 7. Metadata JSON estructurada
  zip.file('05_METADATOS_CAMPUS.json', JSON.stringify(session, null, 2));

  // Generar el archivo ZIP Blob
  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  return { blob, fileName: zipFileName };
}

/**
 * Descarga directamente el archivo ZIP en el dispositivo del usuario
 */
export async function downloadMeetingZip(session: MeetingSession): Promise<string> {
  const { blob, fileName } = await generateMeetingZip(session);

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  // Limpieza de memoria
  setTimeout(() => URL.revokeObjectURL(url), 15000);

  return fileName;
}
