import { AcademicSettings, Participant, MeetingSession } from '../types/campus';

export const EXACT_VALUE_PROMISE = 
  "Para estudiantes que hacen trabajos grupales, CampUs permite hablar por voz con una persona, un grupo o todo el equipo, grabar la reunión y guardar sus apuntes, acuerdos y dibujos por curso y semana para encontrar lo trabajado en menos de un minuto.";

export const DEMO_PARTICIPANTS: Participant[] = [
  {
    id: 'carlos',
    name: 'Carlos',
    fullName: 'Carlos Morales (Tú)',
    role: 'Coordinador',
    initials: 'CM',
    avatarBg: 'from-amber-500 to-orange-600',
  },
  {
    id: 'diego',
    name: 'Diego',
    fullName: 'Diego Mendoza',
    role: 'Investigador',
    initials: 'DM',
    avatarBg: 'from-blue-500 to-indigo-600',
  },
  {
    id: 'camila',
    name: 'Camila',
    fullName: 'Camila Torres',
    role: 'Diseño UX & Redacción',
    initials: 'CT',
    avatarBg: 'from-violet-500 to-purple-600',
  },
  {
    id: 'luis',
    name: 'Luis',
    fullName: 'Luis Valdivia',
    role: 'Análisis de datos',
    initials: 'LV',
    avatarBg: 'from-emerald-500 to-teal-600',
  },
  {
    id: 'sofia',
    name: 'Sofía',
    fullName: 'Sofía Ramos',
    role: 'Validación de usuarios',
    initials: 'SR',
    avatarBg: 'from-rose-500 to-pink-600',
  },
];

// Calcula una fecha de inicio del ciclo que ubique la fecha actual exactamente en la semana 7
// (42 días antes de hoy, según el ejemplo del prompt maestro)
export function getDefaultSemesterStartDate(): string {
  const d = new Date();
  d.setDate(d.getDate() - 42); // 6 semanas completas transcurridas -> Semana 7
  const year = d.getFullYear();
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const INITIAL_ACADEMIC_SETTINGS: AcademicSettings = {
  startDate: getDefaultSemesterStartDate(),
  totalWeeks: 16,
  courses: [
    {
      id: 'course-emp',
      name: 'Emprendimiento I',
      code: 'EMP-101',
      color: '#6857E8',
      projects: [
        { id: 'proj-val', name: 'Validación del problema', description: 'Entrevistas a 20 estudiantes y mapa de empatía' },
        { id: 'proj-lean', name: 'Modelo de Negocio', description: 'Canvas Lean y propuesta de valor inicial' },
      ],
    },
    {
      id: 'course-inv',
      name: 'Proyecto de Investigación',
      code: 'INV-402',
      color: '#4778F5',
      projects: [
        { id: 'proj-paper', name: 'Paper Científico', description: 'Redacción del marco metodológico y fuentes APA 7' },
        { id: 'proj-tesis', name: 'Marco Teórico', description: 'Revisión sistemática de literatura 2022-2025' },
      ],
    },
    {
      id: 'course-lab',
      name: 'Laboratorio de Redes',
      code: 'LAB-B04',
      color: '#42C99A',
      projects: [
        { id: 'proj-top', name: 'Simulación de Topologías', description: 'Configuración de VLANs y enrutamiento dinámico' },
      ],
    },
  ],
};

// SVG data URLs para dibujos de ejemplo prealmacenados en el historial
const SAMPLE_DRAWING_EMPRENDIMIENTO = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240"><rect width="100%" height="100%" fill="%23111827"/><circle cx="100" cy="120" r="45" stroke="%236857E8" stroke-width="4" fill="none"/><circle cx="200" cy="120" r="45" stroke="%234778F5" stroke-width="4" fill="none"/><circle cx="300" cy="120" r="45" stroke="%2342C99A" stroke-width="4" fill="none"/><text x="100" y="125" fill="white" font-size="12" text-anchor="middle" font-family="sans-serif">Problema</text><text x="200" y="125" fill="white" font-size="12" text-anchor="middle" font-family="sans-serif">Solución</text><text x="300" y="125" fill="white" font-size="12" text-anchor="middle" font-family="sans-serif">Canales</text><path d="M 145 120 L 155 120" stroke="white" stroke-width="2"/><path d="M 245 120 L 255 120" stroke="white" stroke-width="2"/><text x="200" y="210" fill="%2342C99A" font-size="14" text-anchor="middle" font-family="sans-serif">Boceto de Flujo de Trabajo (Semana 7)</text></svg>';

export const INITIAL_MEETINGS_HISTORY: MeetingSession[] = [
  {
    id: 'meet-demo-1',
    courseId: 'course-emp',
    courseName: 'Emprendimiento I',
    projectId: 'proj-val',
    projectName: 'Validación del problema',
    groupName: 'Equipo Alpha · Sección B',
    participants: [DEMO_PARTICIPANTS[0], DEMO_PARTICIPANTS[1], DEMO_PARTICIPANTS[2], DEMO_PARTICIPANTS[3]],
    startDate: '2026-10-14',
    startTime: '16:00',
    endDate: '2026-10-14',
    endTime: '16:25',
    weekNumber: 7,
    durationSeconds: 1500, // 25 min
    status: 'completed',
    walkieTransmissions: [
      {
        id: 'tx-hist-1',
        recipientType: 'all',
        recipientName: 'Todos',
        targetLabel: 'Todo el equipo (4 miembros)',
        timestamp: '16:05',
        durationSeconds: 12,
        summary: 'Indicación de inicio para todos',
        detail: 'Revisemos los resultados de las 20 entrevistas antes de cerrar la matriz de hipótesis.',
      },
      {
        id: 'tx-hist-2',
        recipientType: 'person',
        recipientName: 'Diego',
        targetLabel: 'Diego Mendoza',
        timestamp: '16:18',
        durationSeconds: 8,
        summary: 'Aclaración a Diego',
        detail: 'Diego, por favor consolida las métricas cuantitativas en el apunte del equipo.',
      },
    ],
    recording: {
      id: 'rec-demo-1',
      durationSeconds: 1480,
      startTime: '16:02',
      endTime: '16:25',
      status: 'completed',
      consentConfirmed: true,
    },
    notes: [
      {
        id: 'note-hist-1',
        title: 'Hallazgos de 20 entrevistas de campo',
        content: 'El 85% de los alumnos reportó que pierden más de 15 minutos buscando acuerdos pasados dispersos en chats de mensajería informal.',
        author: 'Carlos',
        createdAt: '14 Oct, 16:12',
        courseId: 'course-emp',
        courseName: 'Emprendimiento I',
        projectId: 'proj-val',
        projectName: 'Validación del problema',
        weekNumber: 7,
        meetingId: 'meet-demo-1',
      },
      {
        id: 'note-hist-2',
        title: 'Propuesta de solución aprobada',
        content: 'Centralizar los acuerdos por curso y semana con walkie-talkie instantáneo sin videollamada.',
        author: 'Camila',
        createdAt: '14 Oct, 16:20',
        courseId: 'course-emp',
        courseName: 'Emprendimiento I',
        projectId: 'proj-val',
        projectName: 'Validación del problema',
        weekNumber: 7,
        meetingId: 'meet-demo-1',
      },
    ],
    agreements: [
      {
        id: 'agr-hist-1',
        description: 'Entregar las fuentes y matriz de hipótesis',
        assignee: 'Diego',
        deadline: 'Viernes 18:00',
        status: 'pending',
        createdAt: '14 Oct, 16:22',
        courseId: 'course-emp',
        courseName: 'Emprendimiento I',
        projectId: 'proj-val',
        projectName: 'Validación del problema',
        weekNumber: 7,
        meetingId: 'meet-demo-1',
      },
      {
        id: 'agr-hist-2',
        description: 'Diseñar el prototipo en Figma para Semana 8',
        assignee: 'Camila',
        deadline: 'Lunes 10:00',
        status: 'completed',
        createdAt: '14 Oct, 16:24',
        courseId: 'course-emp',
        courseName: 'Emprendimiento I',
        projectId: 'proj-val',
        projectName: 'Validación del problema',
        weekNumber: 7,
        meetingId: 'meet-demo-1',
      },
    ],
    drawings: [
      {
        id: 'draw-hist-1',
        title: 'Esquema de Problema-Solución',
        dataUrl: SAMPLE_DRAWING_EMPRENDIMIENTO,
        createdAt: '14 Oct, 16:19',
        courseId: 'course-emp',
        weekNumber: 7,
        meetingId: 'meet-demo-1',
      },
    ],
  },
  {
    id: 'meet-demo-2',
    courseId: 'course-inv',
    courseName: 'Proyecto de Investigación',
    projectId: 'proj-paper',
    projectName: 'Paper Científico',
    groupName: 'Mesa 4 · Tesis',
    participants: [DEMO_PARTICIPANTS[0], DEMO_PARTICIPANTS[1], DEMO_PARTICIPANTS[3]],
    startDate: '2026-10-07',
    startTime: '10:00',
    endDate: '2026-10-07',
    endTime: '10:35',
    weekNumber: 6,
    durationSeconds: 2100, // 35 min
    status: 'completed',
    walkieTransmissions: [
      {
        id: 'tx-hist-3',
        recipientType: 'group',
        recipientName: 'Investigación',
        targetLabel: 'Subgrupo de Análisis',
        timestamp: '10:15',
        durationSeconds: 15,
        summary: 'Revisión de muestra estadística',
        detail: 'Verifiquen que el intervalo de confianza sea del 95% para la muestra de 120 alumnos.',
      },
    ],
    recording: {
      id: 'rec-demo-2',
      durationSeconds: 2000,
      startTime: '10:05',
      endTime: '10:35',
      status: 'completed',
      consentConfirmed: true,
    },
    notes: [
      {
        id: 'note-hist-3',
        title: 'Criterios de inclusión bibliográfica',
        content: 'Solo artículos de revistas indexadas Scopus Q1/Q2 publicados en los últimos 4 años.',
        author: 'Luis',
        createdAt: '07 Oct, 10:25',
        courseId: 'course-inv',
        courseName: 'Proyecto de Investigación',
        projectId: 'proj-paper',
        projectName: 'Paper Científico',
        weekNumber: 6,
        meetingId: 'meet-demo-2',
      },
    ],
    agreements: [
      {
        id: 'agr-hist-3',
        description: 'Redactar capítulo de metodología',
        assignee: 'Luis',
        deadline: 'Jueves',
        status: 'completed',
        createdAt: '07 Oct, 10:30',
        courseId: 'course-inv',
        courseName: 'Proyecto de Investigación',
        projectId: 'proj-paper',
        projectName: 'Paper Científico',
        weekNumber: 6,
        meetingId: 'meet-demo-2',
      },
    ],
    drawings: [],
  },
];
