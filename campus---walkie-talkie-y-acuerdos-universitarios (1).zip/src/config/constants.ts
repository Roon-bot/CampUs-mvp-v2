/**
 * CampUs - Configuración Central
 * 
 * Aquí se centraliza la promesa de valor, el número de WhatsApp
 * y datos predeterminados para facilitar su edición y personalización.
 */

// PROMESA DE CAMPUS
export const VALUE_PROPOSITION = "Para estudiantes universitarios que coordinan trabajos grupales en distintos cursos, CampUs permite comunicarse por voz con una persona, un grupo o todo el equipo y registrar sus acuerdos por curso y semana, para encontrar cada decisión en menos de un minuto.";

// FRASE COMPLEMENTARIA
export const VALUE_SLOGAN = "Habla al instante. Guarda lo importante. Encuentra tus acuerdos cuando los necesites.";

// PILARES DE LA PROMESA
export const STRATEGIC_PILLARS = {
  persona: "Estudiantes universitarios que coordinan trabajos grupales en distintos cursos.",
  action: "Comunicación por voz y registro de acuerdos vinculados al curso y semana.",
  measurableBenefit: "Encontrar una decisión en menos de un minuto (meta medible por validar)."
};

// NÚMERO DE WHATSAPP (código internacional sin signos, guiones ni espacios)
export const WHATSAPP_NUMBER = "51912481539";

// Mensaje precargado oficial para contactar sobre CampUs
export const WHATSAPP_MESSAGE = "Hola, estoy interesado/a en CampUs. Me gustaría conocer más sobre el proyecto y recibir información cuando esté disponible su versión final. ¡Muchas gracias!";

/**
 * Genera el enlace oficial de WhatsApp directo
 */
export function buildWhatsAppLink(number: string = WHATSAPP_NUMBER, message: string = WHATSAPP_MESSAGE): string {
  const target = number ? `https://wa.me/${number}` : 'https://wa.me';
  return `${target}?text=${encodeURIComponent(message)}`;
}

// Cursos académicos vinculados
export const ACADEMIC_COURSES = [
  { id: "inv-402", name: "Proyecto de investigación", code: "INV-402" },
  { id: "lab-b04", name: "Laboratorio", code: "LAB-B04" },
  { id: "tf-sec2", name: "Trabajo final", code: "TF-SEC2" },
  { id: "met-301", name: "Metodología", code: "MET-301" }
];

// Semanas lectivas del ciclo
export const SEMESTER_WEEKS = [
  "Semana 1",
  "Semana 2",
  "Semana 3",
  "Semana 4",
  "Semana 5",
  "Semana 6",
  "Semana 7"
];

// Datos de demostración de los integrantes ficticios del equipo
export const DEMO_MEMBERS = [
  {
    id: "diego",
    name: "Diego",
    fullName: "Diego Mendoza",
    role: "Investigador / Fuentes",
    status: "online",
    statusLabel: "En línea",
    avatarBg: "from-blue-500 to-indigo-600",
    initials: "DM"
  },
  {
    id: "camila",
    name: "Camila",
    fullName: "Camila Torres",
    role: "Diseño & Redacción",
    status: "in_class",
    statusLabel: "En clase (salida 18:00)",
    avatarBg: "from-violet-500 to-purple-600",
    initials: "CT"
  },
  {
    id: "luis",
    name: "Luis",
    fullName: "Luis Valdivia",
    role: "Análisis estadístico",
    status: "online",
    statusLabel: "En línea",
    avatarBg: "from-emerald-500 to-teal-600",
    initials: "LV"
  },
  {
    id: "carlos",
    name: "Carlos",
    fullName: "Carlos Morales (Tú)",
    role: "Coordinador del grupo",
    status: "online",
    statusLabel: "Tú",
    avatarBg: "from-amber-500 to-orange-600",
    initials: "CM"
  }
];

// Grupos de estudio disponibles
export const DEMO_GROUPS = [
  {
    id: "proyecto-investigacion",
    name: "Proyecto de investigación",
    shortName: "Investigación",
    membersCount: 4,
    description: "Tesis y paper final de ciclo",
    code: "INV-402",
    tagColor: "bg-indigo-50 text-indigo-700 border-indigo-200"
  },
  {
    id: "laboratorio",
    name: "Laboratorio",
    shortName: "Laboratorio",
    membersCount: 3,
    description: "Prácticas de laboratorio y simulaciones",
    code: "LAB-B04",
    tagColor: "bg-emerald-50 text-emerald-700 border-emerald-200"
  },
  {
    id: "trabajo-final",
    name: "Trabajo final",
    shortName: "Trabajo Final",
    membersCount: 4,
    description: "Presentación y sustentación",
    code: "TF-SEC2",
    tagColor: "bg-violet-50 text-violet-700 border-violet-200"
  }
];

// Transmisiones de ejemplo requeridas por la especificación
export const INITIAL_TRANSMISSIONS = [
  {
    id: "tx-1",
    recipientType: "all" as const,
    recipientName: "Todos",
    targetLabel: "Todo el equipo (4 integrantes)",
    timestamp: "17:30",
    timeAgo: "Hace 15 min",
    durationSeconds: 8,
    summary: "Mensaje para todos",
    detail: "Confirmemos si nos reunimos en la biblioteca a las 6:30 PM para revisar el borrador de la Semana 4.",
    channel: "Proyecto de investigación"
  },
  {
    id: "tx-2",
    recipientType: "group" as const,
    recipientName: "Laboratorio",
    targetLabel: "Grupo de Laboratorio",
    timestamp: "17:02",
    timeAgo: "Hace 42 min",
    durationSeconds: 12,
    summary: "Mensaje al grupo de laboratorio",
    detail: "Chicos, ya subí los datos del sensor 2 al drive compartido. Faltan las conclusiones de la Semana 4.",
    channel: "Laboratorio"
  },
  {
    id: "tx-3",
    recipientType: "person" as const,
    recipientName: "Diego",
    targetLabel: "Diego Mendoza",
    timestamp: "16:45",
    timeAgo: "Hace 1 h",
    durationSeconds: 5,
    summary: "Mensaje para Diego",
    detail: "Diego, recuerda validar las fuentes bibliográficas de la Semana 4 con formato APA 7.",
    channel: "Directo"
  }
];

// Apuntes iniciales vinculados por curso y semana
export const INITIAL_NOTES = [
  {
    id: "note-1",
    title: "Fuentes del capítulo 2",
    content: "Revisar los artículos de 2022 a 2025 sobre interfaces móviles y síntesis de voz.",
    category: "Investigación",
    createdAt: "Hoy, 16:50",
    author: "Carlos",
    course: "Proyecto de investigación",
    week: "Semana 4"
  },
  {
    id: "note-2",
    title: "Sala de estudio reservada",
    content: "Mesa 4 en el 3er piso de Biblioteca Central de 18:30 a 20:00 con pizarra acrílica.",
    category: "Coordinación",
    createdAt: "Hoy, 15:10",
    author: "Camila",
    course: "Trabajo final",
    week: "Semana 4"
  }
];

// Acuerdos iniciales organizados por curso y semana
export const INITIAL_AGREEMENTS = [
  {
    id: "agr-1",
    description: "Entregar las fuentes",
    assignee: "Diego",
    deadline: "Viernes",
    status: "pending" as const,
    createdAt: "Hoy, 16:46",
    course: "Proyecto de investigación",
    week: "Semana 4"
  },
  {
    id: "agr-2",
    description: "Armar la estructura de diapositivas",
    assignee: "Camila",
    deadline: "Sábado 18:00",
    status: "pending" as const,
    createdAt: "Hoy, 14:20",
    course: "Trabajo final",
    week: "Semana 4"
  },
  {
    id: "agr-3",
    description: "Validar las encuestas del muestreo",
    assignee: "Luis",
    deadline: "Jueves",
    status: "completed" as const,
    createdAt: "Ayer, 18:00",
    course: "Laboratorio",
    week: "Semana 3"
  },
  {
    id: "agr-4",
    description: "Aprobar matriz de consistencia y variables",
    assignee: "Carlos",
    deadline: "Miércoles",
    status: "completed" as const,
    createdAt: "Semana 2",
    course: "Proyecto de investigación",
    week: "Semana 2"
  }
];
