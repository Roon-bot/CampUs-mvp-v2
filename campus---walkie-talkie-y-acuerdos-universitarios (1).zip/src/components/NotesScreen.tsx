import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Clock, 
  Search, 
  Check, 
  Copy, 
  Bookmark, 
  User, 
  Sparkles,
  BookOpen,
  Layers,
  Zap
} from 'lucide-react';
import { Note } from '../types';
import { ACADEMIC_COURSES, SEMESTER_WEEKS, VALUE_SLOGAN } from '../config/constants';
import { soundEffects } from '../utils/sound';

interface NotesScreenProps {
  notes: Note[];
  onAddNote: (newNote: Note) => void;
  onDeleteNote: (id: string) => void;
}

const CATEGORIES = ['General', 'Investigación', 'Coordinación', 'Laboratorio', 'Dudas'];

export const NotesScreen: React.FC<NotesScreenProps> = ({
  notes,
  onAddNote,
  onDeleteNote,
}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('General');
  const [selectedCourse, setSelectedCourse] = useState(ACADEMIC_COURSES[0].name);
  const [selectedWeek, setSelectedWeek] = useState('Semana 4');
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    const now = new Date();
    const formattedHours = now.getHours().toString().padStart(2, '0');
    const formattedMinutes = now.getMinutes().toString().padStart(2, '0');
    const timeString = `Hoy, ${formattedHours}:${formattedMinutes}`;

    const newNote: Note = {
      id: `note-${Date.now()}`,
      title: title.trim() || 'Apunte rápido',
      content: content.trim(),
      category: selectedCategory,
      createdAt: timeString,
      author: 'Carlos',
      course: selectedCourse,
      week: selectedWeek
    };

    onAddNote(newNote);
    soundEffects.playSuccess();

    // Reset form
    setTitle('');
    setContent('');
    setIsFormOpen(false);
  };

  const handleCopy = (note: Note) => {
    const textToCopy = `${note.title}\n${note.content}\n[${note.course || 'General'} · ${note.week || ''}]\n(${note.createdAt})`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedId(note.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredNotes = notes.filter((n) => {
    const q = searchTerm.toLowerCase();
    return (
      n.title.toLowerCase().includes(q) ||
      n.content.toLowerCase().includes(q) ||
      n.category.toLowerCase().includes(q) ||
      (n.course && n.course.toLowerCase().includes(q)) ||
      (n.week && n.week.toLowerCase().includes(q))
    );
  });

  return (
    <div className="flex flex-col gap-3.5 pb-24 px-4 pt-3 select-none">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#6558E8]" />
            Apuntes del Equipo
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Registra y vincula notas por curso y semana
          </p>
        </div>

        <button
          onClick={() => {
            setIsFormOpen(!isFormOpen);
            soundEffects.playSuccess();
          }}
          className="flex items-center gap-1.5 px-3 py-2 bg-[#6558E8] hover:bg-[#5447d6] text-white text-xs font-bold rounded-xl shadow-md shadow-[#6558E8]/25 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>{isFormOpen ? 'Cerrar' : 'Nuevo apunte'}</span>
        </button>
      </div>

      {/* Slogan banner */}
      <div className="p-2.5 rounded-xl bg-gradient-to-r from-violet-50 via-indigo-50 to-emerald-50 border border-violet-100 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Zap className="w-4 h-4 text-[#6558E8] shrink-0" />
          <p className="text-[11px] font-bold text-slate-800 truncate">
            «{VALUE_SLOGAN}»
          </p>
        </div>
        <span className="shrink-0 text-[10px] font-bold text-[#6558E8] bg-violet-100 px-2 py-0.5 rounded-md">
          Por curso y semana
        </span>
      </div>

      {/* Note Creation Form (Collapsible or Card) */}
      {isFormOpen && (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl p-4 shadow-md border border-[#6558E8]/20 animate-in fade-in slide-in-from-top-2 duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#6558E8]" />
              Escribir Anotación
            </span>
            <span className="text-[10px] text-slate-400 font-medium">Por: Carlos</span>
          </div>

          <div className="space-y-3">
            <div>
              <input
                type="text"
                placeholder="Título del apunte (ej. Fuentes del capítulo 2)"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#6558E8]/30 focus:border-[#6558E8] bg-[#F4F6FA]/50"
              />
            </div>

            <div>
              <textarea
                placeholder="Escribe aquí los detalles de la indicación o apunte..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={3}
                required
                className="w-full text-xs px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#6558E8]/30 focus:border-[#6558E8] bg-[#F4F6FA]/50 resize-none"
              />
            </div>

            {/* Course & Week association */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] font-bold text-slate-600 mb-1 block">Curso:</span>
                <select
                  value={selectedCourse}
                  onChange={(e) => setSelectedCourse(e.target.value)}
                  className="w-full text-[11px] font-medium px-2.5 py-1.5 rounded-xl border border-slate-200 bg-[#F4F6FA]/60"
                >
                  {ACADEMIC_COURSES.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <span className="text-[10px] font-bold text-slate-600 mb-1 block">Semana:</span>
                <select
                  value={selectedWeek}
                  onChange={(e) => setSelectedWeek(e.target.value)}
                  className="w-full text-[11px] font-medium px-2.5 py-1.5 rounded-xl border border-slate-200 bg-[#F4F6FA]/60"
                >
                  {SEMESTER_WEEKS.map((w) => (
                    <option key={w} value={w}>{w}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Category selection */}
            <div>
              <span className="text-[10px] font-bold text-slate-500 mb-1 block">Categoría:</span>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`text-[11px] font-medium px-2.5 py-1 rounded-lg transition-all ${
                      selectedCategory === cat
                        ? 'bg-[#6558E8] text-white font-bold shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit button */}
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-semibold"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!content.trim()}
                className="px-4 py-2 bg-[#10172A] hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all shadow-sm active:scale-95 flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Guardar apunte</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Buscar en apuntes (por curso, semana o texto)..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-[#6558E8]/20 focus:border-[#6558E8]"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="text-[11px] text-slate-400 hover:text-slate-600 absolute right-3 top-1/2 -translate-y-1/2"
          >
            Limpiar
          </button>
        )}
      </div>

      {/* Notes List */}
      <div className="space-y-3">
        {filteredNotes.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-dashed border-slate-200">
            <Bookmark className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-xs font-bold text-slate-700">No hay apuntes registrados</h4>
            <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
              {searchTerm 
                ? 'No se encontraron resultados con ese término de búsqueda.' 
                : 'Usa el botón "Nuevo apunte" para registrar anotaciones del equipo.'}
            </p>
          </div>
        ) : (
          filteredNotes.map((note) => (
            <div
              key={note.id}
              className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80 hover:border-slate-300 transition-all flex flex-col gap-2 relative group"
            >
              {/* Note Header */}
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#6558E8]/10 text-[#6558E8]">
                      {note.category}
                    </span>
                    {note.course && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 flex items-center gap-1">
                        <BookOpen className="w-2.5 h-2.5 text-slate-400" />
                        {note.course}
                      </span>
                    )}
                    {note.week && (
                      <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 flex items-center gap-1">
                        <Layers className="w-2.5 h-2.5 text-slate-400" />
                        {note.week}
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-xs text-slate-900 mt-0.5">
                    {note.title}
                  </h3>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopy(note)}
                    title="Copiar texto del apunte"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-[#6558E8] hover:bg-slate-100 transition-colors"
                  >
                    {copiedId === note.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    onClick={() => {
                      onDeleteNote(note.id);
                      soundEffects.playPttEnd();
                    }}
                    title="Eliminar apunte"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Note Content */}
              <p className="text-xs text-slate-700 leading-relaxed bg-[#F4F6FA]/70 p-3 rounded-xl whitespace-pre-wrap font-normal">
                {note.content}
              </p>

              {/* Author footer */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  Registrado por: <strong className="text-slate-600 font-semibold">{note.author}</strong>
                </span>
                <span className="flex items-center gap-1 font-medium text-slate-400">
                  <Clock className="w-3 h-3" />
                  {note.createdAt}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
