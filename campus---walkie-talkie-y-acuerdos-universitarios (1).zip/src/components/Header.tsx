import React from 'react';
import { Radio, Volume2, VolumeX, Settings, Calendar, Disc, CheckCircle } from 'lucide-react';
import { MeetingSession, AcademicSettings, NavigationTab } from '../types/campus';
import { calculateAcademicWeek, formatLongDate } from '../utils/academic';

interface HeaderProps {
  settings: AcademicSettings;
  activeMeeting: MeetingSession | null;
  currentTab: NavigationTab;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onNavigate: (tab: NavigationTab) => void;
  onOpenEndMeetingModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  activeMeeting,
  currentTab,
  soundEnabled,
  onToggleSound,
  onNavigate,
  onOpenEndMeetingModal,
}) => {
  const weekInfo = calculateAcademicWeek(settings.startDate, settings.totalWeeks);

  return (
    <header className="relative bg-[#111827] text-white pt-3 pb-3 px-4 border-b border-slate-800 shadow-md select-none z-30">
      {/* Top Bar: Brand + Quick Actions */}
      <div className="flex items-center justify-between gap-2">
        <button
          onClick={() => onNavigate('inicio')}
          className="flex items-center gap-2.5 text-left focus:outline-none group"
        >
          {/* Logo mark */}
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#6857E8] via-[#4778F5] to-[#42C99A] p-[2px] shadow-sm flex items-center justify-center shrink-0">
            <div className="w-full h-full bg-[#111827] rounded-[14px] flex items-center justify-center">
              <Radio className="w-4 h-4 text-[#42C99A]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-white group-hover:text-slate-100">
                CampUs
              </span>
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-[#6857E8]/20 text-[#857BF2] border border-[#6857E8]/40 uppercase tracking-wider">
                Prototipo
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium">Coordinación de Trabajos Grupales</p>
          </div>
        </button>

        {/* Right tools: Sound toggle & Settings button */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Silenciar sonidos de demostración' : 'Activar sonidos de demostración'}
            className="w-8 h-8 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors border border-slate-700/50"
            aria-label="Alternar sonido"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-[#42C99A]" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>

          <button
            onClick={() => onNavigate('configuracion')}
            title="Configuración académica"
            className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors border ${
              currentTab === 'configuracion'
                ? 'bg-[#6857E8] text-white border-[#6857E8]'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700/50'
            }`}
            aria-label="Configuración"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Second Row: Live Academic Week Badge & Active Meeting Alert */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
        {/* Academic Week status */}
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-lg bg-[#6857E8]/20 text-indigo-300 border border-[#6857E8]/30">
            <Calendar className="w-3 h-3 text-[#6857E8]" />
            {weekInfo.label}
          </span>
          <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
            {formatLongDate(new Date())}
          </span>
        </div>

        {/* Active Meeting Indicator if running */}
        {activeMeeting && (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-red-950/80 border border-red-500/40 text-red-300 text-[11px] font-bold">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span className="truncate max-w-[140px]">Reunión: {activeMeeting.courseName}</span>
            </div>
            {onOpenEndMeetingModal && (
              <button
                onClick={onOpenEndMeetingModal}
                className="px-2 py-0.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-[10px] transition-colors"
              >
                Finalizar
              </button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
