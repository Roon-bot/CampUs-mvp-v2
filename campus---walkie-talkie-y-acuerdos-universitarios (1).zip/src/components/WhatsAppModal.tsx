import React from 'react';
import { MessageCircle, ExternalLink, X, ShieldCheck, Sparkles, Phone, Info } from 'lucide-react';
import { WHATSAPP_NUMBER, WHATSAPP_MESSAGE, buildWhatsAppLink } from '../config/constants';

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const fullLink = buildWhatsAppLink(WHATSAPP_NUMBER, WHATSAPP_MESSAGE);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-150"
        role="dialog"
        aria-modal="true"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-800 transition-colors"
          aria-label="Cerrar modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Brand Icon Header */}
        <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center mb-3">
          <MessageCircle className="w-6 h-6 text-[#25D366] fill-[#25D366]" />
        </div>

        <h3 className="text-base font-extrabold text-slate-900">
          Conoce más sobre CampUs
        </h3>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">
          Comunícate por voz con tus grupos de estudio y organiza acuerdos por curso y semana para encontrar cada decisión en menos de un minuto.
        </p>

        {/* Preloaded message preview box */}
        <div className="my-3.5 p-3 rounded-xl bg-[#F4F6FA] border border-slate-200 text-left space-y-1">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
            <Info className="w-3 h-3 text-[#6558E8]" />
            Mensaje precargado:
          </div>
          <p className="text-xs text-slate-700 italic font-medium leading-relaxed">
            "{WHATSAPP_MESSAGE}"
          </p>
        </div>

        {/* WhatsApp Button */}
        <div className="space-y-2">
          <a
            href={fullLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={onClose}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs shadow-lg shadow-emerald-500/25 transition-all active:scale-95"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>Quiero conocer CampUs</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </a>

          <p className="text-[10px] text-slate-400 text-center font-medium">
            Se abrirá WhatsApp en una pestaña segura (wa.me)
          </p>
        </div>

        {/* Technical notice */}
        <div className="mt-3 pt-3 border-t border-slate-100 text-[10px] text-slate-500 flex items-center justify-between">
          <span>Configuración central:</span>
          <code className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono text-[9px]">
            {WHATSAPP_NUMBER}
          </code>
        </div>
      </div>
    </div>
  );
};
