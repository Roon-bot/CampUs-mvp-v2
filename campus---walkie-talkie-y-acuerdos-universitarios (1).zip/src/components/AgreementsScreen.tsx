import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Calendar, 
  User, 
  CheckCircle, 
  Circle, 
  Trash2, 
  Sparkles, 
  Search,
  BookOpen,
  Layers,
  Clock,
  Zap,
  Filter
} from 'lucide-react';
import { Agreement } from '../types';
import { DEMO_MEMBERS, ACADEMIC_COURSES, SEMESTER_WEEKS, VALUE_SLOGAN } from '../config/constants';
import { soundEffects } from '../utils/sound';

interface AgreementsScreenProps {
  agreements: Agreement[];
  onAddAgreement: (newAgr: Agreement) => void;
  onToggleStatus: (id: string) => void;
  onDeleteAgreement: (id: string) => void;
}

export const AgreementsScreen: React.FC<AgreementsScreenProps> = ({
  agreements,
  onAddAgreement,
  onToggleStatus,
  onDeleteAgreement,
}) => {
  // Form state
  const [description, setDescription] = useState('');
  const [assignee, setAssignee] = useState('Diego');
  const [customAssignee, setCustomAssignee] = useState('');
  const [deadline, setDeadline] = useState('Viernes');
  const [course, setCourse] = useState(ACADEMIC_COURSES[0].name);
  const [week, setWeek] = useState('Semana 4');
  const [status, setStatus] = useState<'pending' | 'completed'>('pending');
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Filters & Search for finding decisions in < 1 minute
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCourse, setFilterCourse] = useState('all');
  const [filterWeek, setFilterWeek] = useState('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    const finalAssignee = assignee === 'Otro' ? (customAssignee.trim() || 'Compañero') : assignee;

    const newAgreement: Agreement = {
      id: `agr-${Date.now()}`,
      description: description.trim(),
      assignee: finalAssignee,
      deadline: deadline.trim() || 'Sin fecha fija',
      status,
      createdAt: 'Hoy',
      course,
      week
    };

    onAddAgreement(newAgreement);
    soundEffects.playSuccess();

    // Reset fields
    setDescription('');
    setDeadline('Viernes');
    setStatus('pending');
    setIsFormOpen(false);
  };

  const filteredAgreements = agreements.filter((agr) => {
    // Status filter
    if (filterStatus !== 'all' && agr.status !== filterStatus) return false;
    // Course filter
    if (filterCourse !== 'all' && agr.course !== filterCourse) return false;
    // Week filter
    if (filterWeek !== 'all' && agr.week !== filterWeek) return false;
    // Search filter
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchDesc = agr.description.toLowerCase().includes(q);
      const matchAssignee = agr.assignee.toLowerCase().includes(q);
      const matchCourse = (agr.course || '').toLowerCase().includes(q);
      const matchWeek = (agr.week || '').toLowerCase().includes(q);
      if (!matchDesc && !matchAssignee && !matchCourse && !matchWeek) return false;
    }
    return true;
  });

  const pendingCount = agreements.filter((a) => a.status === 'pending').length;
  const completedCount = agreements.filter((a) => a.status === 'completed').length;

  return (
    <div className="flex flex-col gap-3.5 pb-24 px-4 pt-3 select-none">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-[#42C99A]" />
            Acuerdos del Equipo
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Organizados por curso y semana
          </p>
        </div>

        <button
          onClick={() => {
            setIsFormOpen(!isFormOpen);
            soundEffects.playSuccess();
          }}
          className="flex items-center gap-1.5 px-3 py-2 bg-[#10172A] hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4 text-[#42C99A]" />
          <span>{isFormOpen ? 'Cerrar' : 'Nuevo acuerdo'}</span>
        </button>
      </div>

      {/* Slogan banner */}
      <div className="p-2.5 rounded-xl bg-gradient-to-r from-indigo-50 via-purple-50 to-emerald-50 border border-indigo-100 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Zap className="w-4 h-4 text-[#6558E8] shrink-0" />
          <p className="text-[11px] font-bold text-slate-800 truncate">
            «{VALUE_SLOGAN}»
          </p>
        </div>
        <span className="shrink-0 text-[10px] font-extrabold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
          Meta: &lt; 1 min
        </span>
      </div>

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700">Pendientes</span>
            <div className="text-xl font-extrabold text-slate-900">{pendingCount}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xs">
            ⏳
          </div>
        </div>

        <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#42C99A]">Completados</span>
            <div className="text-xl font-extrabold text-slate-900">{completedCount}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs">
            ✓
          </div>
        </div>
      </div>

      {/* DECISION FINDER: Search & Filter in < 1 minute */}
      <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-200 space-y-2.5">
        <div className="flex items-center justify-between">
          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-[#6558E8]" />
            Buscador de decisiones (&lt; 1 minuto)
          </label>
          {(searchTerm || filterCourse !== 'all' || filterWeek !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setFilterCourse('all');
                setFilterWeek('all');
                setFilterStatus('all');
              }}
              className="text-[10px] text-[#6558E8] font-bold hover:underline"
            >
              Restablecer filtros
            </button>
          )}
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por acuerdo, responsable, curso o semana..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-2 rounded-xl border border-slate-200 bg-[#F4F6FA]/50 focus:outline-none focus:ring-2 focus:ring-[#6558E8]/20 focus:border-[#6558E8]"
          />
        </div>

        {/* Filter Pills by Course */}
        <div>
          <span className="text-[10px] font-semibold text-slate-400 block mb-1">Por curso:</span>
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              type="button"
              onClick={() => setFilterCourse('all')}
              className={`text-[10px] px-2.5 py-1 rounded-lg shrink-0 font-medium transition-all ${
                filterCourse === 'all'
                  ? 'bg-[#10172A] text-white font-bold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Todos los cursos
            </button>
            {ACADEMIC_COURSES.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setFilterCourse(c.name)}
                className={`text-[10px] px-2.5 py-1 rounded-lg shrink-0 font-medium transition-all ${
                  filterCourse === c.name
                    ? 'bg-[#6558E8] text-white font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Pills by Week */}
        <div>
          <span className="text-[10px] font-semibold text-slate-400 block mb-1">Por semana:</span>
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              type="button"
              onClick={() => setFilterWeek('all')}
              className={`text-[10px] px-2.5 py-1 rounded-lg shrink-0 font-medium transition-all ${
                filterWeek === 'all'
                  ? 'bg-[#10172A] text-white font-bold'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Todas
            </button>
            {SEMESTER_WEEKS.slice(0, 5).map((w) => (
              <button
                key={w}
                type="button"
                onClick={() => setFilterWeek(w)}
                className={`text-[10px] px-2.5 py-1 rounded-lg shrink-0 font-medium transition-all ${
                  filterWeek === w
                    ? 'bg-[#4A75F5] text-white font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {w}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Accordion / Creation Form */}
      {isFormOpen && (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl p-4 shadow-md border border-slate-300 animate-in fade-in slide-in-from-top-2 duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#42C99A]" />
              Registrar Nuevo Acuerdo
            </span>
            <span className="text-[10px] text-slate-400 font-medium">Coordinación académica</span>
          </div>

          <div className="space-y-3">
            {/* 1. Descripción del acuerdo */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Descripción del acuerdo:
              </label>
              <input
                type="text"
                placeholder="Ej. Entregar las fuentes"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                className="w-full text-xs font-medium px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#42C99A]/40 focus:border-[#42C99A] bg-[#F4F6FA]/50"
              />
            </div>

            {/* 2. Curso vinculado */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Curso:
              </label>
              <select
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full text-xs font-medium px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F4F6FA]/50 focus:outline-none focus:ring-2 focus:ring-[#6558E8]/30"
              >
                {ACADEMIC_COURSES.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Semana del ciclo */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Semana académica:
              </label>
              <div className="flex gap-1.5 flex-wrap">
                {SEMESTER_WEEKS.slice(0, 6).map((w) => (
                  <button
                    key={w}
                    type="button"
                    onClick={() => setWeek(w)}
                    className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                      week === w
                        ? 'bg-violet-50 border-violet-300 text-violet-700 font-bold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {w}
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Responsable */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Responsable:
              </label>
              <div className="grid grid-cols-4 gap-1.5 mb-1.5">
                {DEMO_MEMBERS.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setAssignee(m.name);
                      setCustomAssignee('');
                    }}
                    className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition-all truncate text-center ${
                      assignee === m.name
                        ? 'bg-[#10172A] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {m.name}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setAssignee('Otro')}
                className={`text-[11px] font-medium px-2 py-0.5 rounded ${
                  assignee === 'Otro' ? 'bg-[#10172A] text-white font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                + Otro responsable
              </button>
              {assignee === 'Otro' && (
                <input
                  type="text"
                  placeholder="Nombre del responsable..."
                  value={customAssignee}
                  onChange={(e) => setCustomAssignee(e.target.value)}
                  className="w-full mt-1 text-xs px-3 py-2 rounded-xl border border-slate-200 bg-[#F4F6FA]"
                />
              )}
            </div>

            {/* 5. Fecha límite */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Fecha límite:
              </label>
              <div className="flex gap-1.5 mb-1.5 flex-wrap">
                {['Hoy', 'Mañana', 'Viernes', 'Sábado', 'Próxima semana'].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setDeadline(preset)}
                    className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                      deadline === preset
                        ? 'bg-indigo-50 border-indigo-300 text-indigo-700 font-bold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
              <input
                type="text"
                placeholder="O escribe la fecha (ej. Viernes 18:00)"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 bg-[#F4F6FA]/50"
              />
            </div>

            {/* 6. Estado inicial */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Estado inicial:
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStatus('pending')}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                    status === 'pending'
                      ? 'bg-amber-50 border-amber-300 text-amber-800 shadow-xs'
                      : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  Pendiente
                </button>
                <button
                  type="button"
                  onClick={() => setStatus('completed')}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                    status === 'completed'
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 shadow-xs'
                      : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  Completado
                </button>
              </div>
            </div>

            {/* Submit button */}
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-semibold"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!description.trim()}
                className="px-4 py-2 bg-[#42C99A] hover:bg-[#38b287] disabled:opacity-50 text-slate-950 text-xs font-bold rounded-xl transition-all shadow-sm active:scale-95 flex items-center gap-1.5"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Guardar acuerdo</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* State Filter Buttons */}
      <div className="flex items-center justify-between gap-1 p-1 bg-white rounded-xl border border-slate-200">
        <button
          onClick={() => setFilterStatus('all')}
          className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-colors ${
            filterStatus === 'all'
              ? 'bg-[#10172A] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Todos ({agreements.length})
        </button>
        <button
          onClick={() => setFilterStatus('pending')}
          className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-colors ${
            filterStatus === 'pending'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Pendientes ({pendingCount})
        </button>
        <button
          onClick={() => setFilterStatus('completed')}
          className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-colors ${
            filterStatus === 'completed'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Completados ({completedCount})
        </button>
      </div>

      {/* Visual Agreements List */}
      <div className="space-y-2.5">
        {filteredAgreements.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-dashed border-slate-200">
            <CheckSquare className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-xs font-bold text-slate-700">No hay acuerdos con los filtros actuales</h4>
            <p className="text-[11px] text-slate-400 mt-1">
              Prueba cambiando o limpiando los filtros de curso, semana o estado.
            </p>
          </div>
        ) : (
          filteredAgreements.map((agr) => {
            const isCompleted = agr.status === 'completed';
            return (
              <div
                key={agr.id}
                className={`p-3.5 rounded-2xl border transition-all bg-white shadow-xs flex items-start gap-3 ${
                  isCompleted 
                    ? 'border-emerald-200/90 bg-emerald-50/20' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Status Toggle Checkbox */}
                <button
                  type="button"
                  onClick={() => {
                    onToggleStatus(agr.id);
                    soundEffects.playSuccess();
                  }}
                  className="mt-0.5 shrink-0 focus:outline-none transition-transform active:scale-90"
                  title={isCompleted ? "Marcar como pendiente" : "Marcar como completado"}
                >
                  {isCompleted ? (
                    <div className="w-6 h-6 rounded-lg bg-[#42C99A] text-slate-950 flex items-center justify-center shadow-xs">
                      <CheckCircle className="w-4 h-4 fill-slate-950 text-[#42C99A]" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-lg border-2 border-slate-300 hover:border-slate-400 flex items-center justify-center bg-white">
                      <Circle className="w-3.5 h-3.5 text-transparent" />
                    </div>
                  )}
                </button>

                {/* Agreement Body */}
                <div className="flex-1 min-w-0">
                  {/* Course & Week Tag Bar */}
                  <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#6558E8]/10 text-[#6558E8] flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      {agr.course}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 flex items-center gap-1">
                      <Layers className="w-3 h-3 text-slate-400" />
                      {agr.week}
                    </span>
                    <span
                      className={`ml-auto text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        isCompleted
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {isCompleted ? 'Completado' : 'Pendiente'}
                    </span>
                  </div>

                  {/* Description */}
                  <h3
                    className={`text-xs font-bold transition-all ${
                      isCompleted ? 'text-slate-400 line-through' : 'text-slate-900'
                    }`}
                  >
                    {agr.description}
                  </h3>

                  {/* Metadata Row: Responsable & Fecha */}
                  <div className="flex flex-wrap items-center gap-2 mt-2 text-[11px] text-slate-600 font-medium">
                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                      <User className="w-3 h-3 text-[#6558E8]" />
                      <span>Responsable: <strong className="text-slate-800">{agr.assignee}</strong></span>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                      <Calendar className="w-3 h-3 text-[#4A75F5]" />
                      <span>Fecha: <strong className="text-slate-800">{agr.deadline}</strong></span>
                    </div>
                  </div>
                </div>

                {/* Delete button */}
                <button
                  type="button"
                  onClick={() => {
                    onDeleteAgreement(agr.id);
                    soundEffects.playPttEnd();
                  }}
                  className="p-1 rounded-lg text-slate-300 hover:text-red-500 hover:bg-red-50 transition-colors"
                  title="Eliminar acuerdo"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
