import React, { useRef, useState, useEffect, useCallback } from 'react';
import { 
  PenTool, 
  Eraser, 
  RotateCcw, 
  RotateCw,
  Trash2, 
  Download, 
  Save, 
  Check, 
  Sparkles, 
  Move, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Image as ImageIcon,
  Highlighter,
  Crosshair
} from 'lucide-react';
import { DrawingItem, MeetingSession } from '../types/campus';
import { soundEffects } from '../utils/sound';

interface WhiteboardViewProps {
  activeMeeting: MeetingSession | null;
  onSaveDrawingToMeeting: (drawing: DrawingItem) => void;
  savedDrawings: DrawingItem[];
}

export interface WhiteboardStroke {
  id: string;
  tool: 'pen' | 'highlighter' | 'eraser';
  color: string;
  width: number;
  points: Array<{ x: number; y: number }>;
}

const PALETTE = [
  { name: 'Azul noche', color: '#111827' },
  { name: 'Violeta', color: '#6857E8' },
  { name: 'Azul', color: '#4778F5' },
  { name: 'Verde menta', color: '#42C99A' },
  { name: 'Rojo', color: '#EF4444' },
  { name: 'Ámbar', color: '#F59E0B' },
];

const STROKE_SIZES = [3, 6, 10, 18];

export const WhiteboardView: React.FC<WhiteboardViewProps> = ({
  activeMeeting,
  onSaveDrawingToMeeting,
  savedDrawings,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Tools & Styling
  const [activeTool, setActiveTool] = useState<'pen' | 'highlighter' | 'eraser' | 'pan'>('pen');
  const [currentColor, setCurrentColor] = useState<string>('#6857E8');
  const [strokeWidth, setStrokeWidth] = useState<number>(4);
  const [drawingTitle, setDrawingTitle] = useState('Boceto de la sesión');

  // Infinite Canvas State: Pan Offset & Zoom Scale
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState<number>(1.0);

  // Stroke data
  const [strokes, setStrokes] = useState<WhiteboardStroke[]>([]);
  const [history, setHistory] = useState<WhiteboardStroke[][]>([[]]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Interaction tracking refs
  const isPointerDownRef = useRef<boolean>(false);
  const currentStrokeRef = useRef<WhiteboardStroke | null>(null);
  const lastPointerPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Convert Screen Event coords -> Infinite World coordinates
  const screenToWorld = useCallback(
    (screenX: number, screenY: number): { x: number; y: number } => {
      const canvas = canvasRef.current;
      if (!canvas) return { x: 0, y: 0 };
      const rect = canvas.getBoundingClientRect();
      const clientX = screenX - rect.left;
      const clientY = screenY - rect.top;
      return {
        x: (clientX - panOffset.x) / zoom,
        y: (clientY - panOffset.y) / zoom,
      };
    },
    [panOffset, zoom]
  );

  // Redraw the infinite canvas whenever strokes, panOffset, or zoom changes
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear visible screen
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    // Apply Infinite Viewport Transformation
    ctx.translate(panOffset.x, panOffset.y);
    ctx.scale(zoom, zoom);

    // Render all committed strokes
    const allStrokes = currentStrokeRef.current ? [...strokes, currentStrokeRef.current] : strokes;

    for (const stroke of allStrokes) {
      if (stroke.points.length < 2) continue;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }

      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (stroke.tool === 'eraser') {
        // En pizarra blanca, borramos pintando en blanco o con composite
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = stroke.width * 2;
        ctx.stroke();
      } else if (stroke.tool === 'highlighter') {
        ctx.strokeStyle = stroke.color;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = stroke.width * 3;
        ctx.stroke();
      } else {
        ctx.strokeStyle = stroke.color;
        ctx.globalAlpha = 1.0;
        ctx.lineWidth = stroke.width;
        ctx.stroke();
      }

      ctx.restore();
    }

    ctx.restore();
  }, [strokes, panOffset, zoom]);

  // Adjust canvas pixel dimensions on resize
  useEffect(() => {
    const updateSize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const dpr = window.devicePixelRatio || 1;
      const width = container.clientWidth;
      const height = container.clientHeight || 450;

      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(dpr, dpr);
      }
      redrawCanvas();
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, [redrawCanvas]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  // Pointer Handlers for drawing and infinite panning
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.setPointerCapture(e.pointerId);
    isPointerDownRef.current = true;
    lastPointerPosRef.current = { x: e.clientX, y: e.clientY };

    if (activeTool === 'pan' || e.button === 1 || e.buttons === 4) {
      // Panning mode
      return;
    }

    // Drawing mode
    const worldPos = screenToWorld(e.clientX, e.clientY);
    const newStroke: WhiteboardStroke = {
      id: `stroke-${Date.now()}-${Math.random()}`,
      tool: activeTool === 'highlighter' ? 'highlighter' : activeTool === 'eraser' ? 'eraser' : 'pen',
      color: currentColor,
      width: strokeWidth,
      points: [worldPos, worldPos],
    };

    currentStrokeRef.current = newStroke;
    redrawCanvas();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isPointerDownRef.current) return;
    e.preventDefault();

    if (activeTool === 'pan' || e.button === 1 || e.buttons === 4) {
      // Infinite Pan: Shift the offset in any direction
      const dx = e.clientX - lastPointerPosRef.current.x;
      const dy = e.clientY - lastPointerPosRef.current.y;
      lastPointerPosRef.current = { x: e.clientX, y: e.clientY };

      setPanOffset((prev) => ({
        x: prev.x + dx,
        y: prev.y + dy,
      }));
      return;
    }

    // Add points to current stroke
    if (currentStrokeRef.current) {
      const worldPos = screenToWorld(e.clientX, e.clientY);
      currentStrokeRef.current.points.push(worldPos);
      redrawCanvas();
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isPointerDownRef.current) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }
    isPointerDownRef.current = false;

    if (currentStrokeRef.current) {
      const finishedStroke = currentStrokeRef.current;
      currentStrokeRef.current = null;

      const newStrokes = [...strokes, finishedStroke];
      setStrokes(newStrokes);

      // Save to undo history
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(newStrokes);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);

      soundEffects.playPttStart();
    }
  };

  // Wheel zoom around pointer
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    const newZoom = Math.min(3.5, Math.max(0.25, zoom * zoomFactor));

    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Zoom centered at mouse position
    const newPanX = mouseX - (mouseX - panOffset.x) * (newZoom / zoom);
    const newPanY = mouseY - (mouseY - panOffset.y) * (newZoom / zoom);

    setZoom(newZoom);
    setPanOffset({ x: newPanX, y: newPanY });
  };

  // Undo / Redo
  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevIndex = historyIndex - 1;
      setHistoryIndex(prevIndex);
      setStrokes(history[prevIndex]);
      soundEffects.playSuccess();
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIndex = historyIndex + 1;
      setHistoryIndex(nextIndex);
      setStrokes(history[nextIndex]);
      soundEffects.playSuccess();
    }
  };

  // Reset viewport to origin
  const handleCenterView = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoom(1.0);
    soundEffects.playSuccess();
  };

  // Fit all drawn strokes onto the screen
  const handleFitContent = () => {
    if (strokes.length === 0) {
      handleCenterView();
      return;
    }

    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    strokes.forEach((s) => {
      s.points.forEach((p) => {
        if (p.x < minX) minX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.x > maxX) maxX = p.x;
        if (p.y > maxY) maxY = p.y;
      });
    });

    const canvas = canvasRef.current;
    if (!canvas) return;

    const contentWidth = Math.max(100, maxX - minX);
    const contentHeight = Math.max(100, maxY - minY);
    const padding = 60;

    const rect = canvas.getBoundingClientRect();
    const scaleX = (rect.width - padding * 2) / contentWidth;
    const scaleY = (rect.height - padding * 2) / contentHeight;
    const newZoom = Math.min(2.0, Math.max(0.3, Math.min(scaleX, scaleY)));

    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    const newPanX = rect.width / 2 - centerX * newZoom;
    const newPanY = rect.height / 2 - centerY * newZoom;

    setZoom(newZoom);
    setPanOffset({ x: newPanX, y: newPanY });
    soundEffects.playSuccess();
  };

  // Clear Canvas
  const handleClear = () => {
    if (strokes.length === 0) return;
    setStrokes([]);
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push([]);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    soundEffects.playPttEnd();
  };

  /**
   * Exporta todo el contenido dibujado (sin recortar bordes) a un Data URL PNG de alta resolución
   */
  const exportFullInfiniteDrawing = (): string => {
    if (strokes.length === 0) {
      // Lienzo en blanco
      const blankCanvas = document.createElement('canvas');
      blankCanvas.width = 800;
      blankCanvas.height = 600;
      const bCtx = blankCanvas.getContext('2d');
      if (bCtx) {
        bCtx.fillStyle = '#FFFFFF';
        bCtx.fillRect(0, 0, 800, 600);
      }
      return blankCanvas.toDataURL('image/png');
    }

    // Calcular la caja delimitadora total de todos los trazos
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    strokes.forEach((s) => {
      s.points.forEach((p) => {
        if (p.x < minX) minX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.x > maxX) maxX = p.x;
        if (p.y > maxY) maxY = p.y;
      });
    });

    const padding = 50;
    const exportWidth = Math.max(400, Math.ceil(maxX - minX + padding * 2));
    const exportHeight = Math.max(300, Math.ceil(maxY - minY + padding * 2));

    const offscreen = document.createElement('canvas');
    offscreen.width = exportWidth;
    offscreen.height = exportHeight;
    const offCtx = offscreen.getContext('2d');
    if (!offCtx) return '';

    // Fondo blanco nítido
    offCtx.fillStyle = '#FFFFFF';
    offCtx.fillRect(0, 0, exportWidth, exportHeight);

    // Cuadrícula sutil de fondo en el export
    offCtx.strokeStyle = '#F1F5F9';
    offCtx.lineWidth = 1;
    for (let x = 0; x < exportWidth; x += 30) {
      offCtx.beginPath();
      offCtx.moveTo(x, 0);
      offCtx.lineTo(x, exportHeight);
      offCtx.stroke();
    }
    for (let y = 0; y < exportHeight; y += 30) {
      offCtx.beginPath();
      offCtx.moveTo(0, y);
      offCtx.lineTo(exportWidth, y);
      offCtx.stroke();
    }

    // Trasladar para que todo el dibujo quede centrado en el export
    offCtx.save();
    offCtx.translate(padding - minX, padding - minY);

    for (const stroke of strokes) {
      if (stroke.points.length < 2) continue;
      offCtx.save();
      offCtx.beginPath();
      offCtx.moveTo(stroke.points[0].x, stroke.points[0].y);

      for (let i = 1; i < stroke.points.length; i++) {
        offCtx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }

      offCtx.lineCap = 'round';
      offCtx.lineJoin = 'round';

      if (stroke.tool === 'eraser') {
        offCtx.strokeStyle = '#FFFFFF';
        offCtx.lineWidth = stroke.width * 2;
        offCtx.stroke();
      } else if (stroke.tool === 'highlighter') {
        offCtx.strokeStyle = stroke.color;
        offCtx.globalAlpha = 0.35;
        offCtx.lineWidth = stroke.width * 3;
        offCtx.stroke();
      } else {
        offCtx.strokeStyle = stroke.color;
        offCtx.globalAlpha = 1.0;
        offCtx.lineWidth = stroke.width;
        offCtx.stroke();
      }
      offCtx.restore();
    }

    // Firma de CampUs en la esquina
    offCtx.restore();
    offCtx.font = 'bold 12px Inter, sans-serif';
    offCtx.fillStyle = '#94A3B8';
    offCtx.fillText(`CampUs Pizarra Infinita · ${new Date().toLocaleDateString('es-ES')}`, 20, exportHeight - 15);

    return offscreen.toDataURL('image/png');
  };

  // Guardar en la sesión de reunión activa
  const handleSaveToMeeting = () => {
    if (strokes.length === 0) {
      setSaveToast('Dibuja algo antes de guardar');
      setTimeout(() => setSaveToast(null), 2500);
      return;
    }

    const dataUrl = exportFullInfiniteDrawing();
    const newDrawing: DrawingItem = {
      id: `draw-${Date.now()}`,
      dataUrl,
      title: drawingTitle.trim() || 'Boceto de la sesión',
      createdAt: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      meetingId: activeMeeting?.id,
      courseId: activeMeeting?.courseId || 'course-emp',
      weekNumber: activeMeeting?.weekNumber || 7,
    };

    onSaveDrawingToMeeting(newDrawing);
    soundEffects.playSuccess();
    setSaveToast('¡Boceto infinito guardado y vinculado a la sesión!');
    setTimeout(() => setSaveToast(null), 3500);
  };

  // Descarga directa a imagen PNG
  const handleDownloadImage = () => {
    const dataUrl = exportFullInfiniteDrawing();
    const link = document.createElement('a');
    link.download = `CampUs_Pizarra_Infinita_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
    soundEffects.playSuccess();
    setSaveToast('Imagen PNG descargada con éxito');
    setTimeout(() => setSaveToast(null), 3000);
  };

  return (
    <div className="flex flex-col gap-3 pb-28 px-4 pt-3 select-none">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <PenTool className="w-5 h-5 text-[#6857E8]" />
            Pizarra Infinita
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Lienzo libre sin bordes · Desplaza y haz zoom libremente
          </p>
        </div>

        <span className="text-[10px] font-extrabold px-2.5 py-1 rounded-full bg-[#42C99A]/15 text-emerald-800 border border-[#42C99A]/30 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-[#42C99A]" />
          Lienzo Infinito
        </span>
      </div>

      {/* Active Meeting Context Banner */}
      {activeMeeting ? (
        <div className="p-2.5 rounded-2xl bg-indigo-50/80 border border-indigo-200 flex items-center justify-between text-xs text-slate-800 font-medium">
          <div className="flex items-center gap-2 truncate">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shrink-0" />
            <span className="truncate">
              Sesión activa: <strong>{activeMeeting.courseName}</strong> (Semana {activeMeeting.weekNumber})
            </span>
          </div>
          <span className="text-[10px] bg-white px-2 py-0.5 rounded-md font-bold text-[#6857E8] border border-indigo-100">
            Se incluirá en el ZIP
          </span>
        </div>
      ) : (
        <div className="p-2.5 rounded-2xl bg-slate-100 border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
          <span>Modo boceto libre (Guarda dibujos en el historial o expórtalos a PNG)</span>
        </div>
      )}

      {/* BARRA DE HERRAMIENTAS SUPERIOR DEL LIENZO INFINITO */}
      <div className="bg-white rounded-3xl p-3 shadow-sm border border-slate-200 space-y-2.5">
        {/* Modos principales: Lápiz | Resaltador | Borrador | Mover Lienzo */}
        <div className="flex items-center justify-between gap-1 overflow-x-auto pb-0.5">
          <div className="flex items-center gap-1 bg-[#F5F6FA] p-1 rounded-2xl border border-slate-200">
            <button
              onClick={() => {
                setActiveTool('pen');
                soundEffects.playSuccess();
              }}
              className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'pen'
                  ? 'bg-[#111827] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white'
              }`}
              title="Lápiz"
            >
              <PenTool className="w-4 h-4" />
              <span className="hidden sm:inline">Lápiz</span>
            </button>

            <button
              onClick={() => {
                setActiveTool('highlighter');
                soundEffects.playSuccess();
              }}
              className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'highlighter'
                  ? 'bg-[#111827] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white'
              }`}
              title="Resaltador"
            >
              <Highlighter className="w-4 h-4" />
              <span className="hidden sm:inline">Resaltador</span>
            </button>

            <button
              onClick={() => {
                setActiveTool('eraser');
                soundEffects.playSuccess();
              }}
              className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'eraser'
                  ? 'bg-[#111827] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white'
              }`}
              title="Borrador"
            >
              <Eraser className="w-4 h-4" />
              <span className="hidden sm:inline">Borrador</span>
            </button>

            <button
              onClick={() => {
                setActiveTool('pan');
                soundEffects.playSuccess();
              }}
              className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'pan'
                  ? 'bg-[#6857E8] text-white shadow-xs ring-2 ring-[#6857E8]/30'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white'
              }`}
              title="Mover lienzo infinito en 360°"
            >
              <Move className="w-4 h-4" />
              <span>Mover</span>
            </button>
          </div>

          {/* Undo / Redo / Center Controls */}
          <div className="flex items-center gap-1">
            <button
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              className="p-2 rounded-xl bg-[#F5F6FA] text-slate-700 hover:bg-slate-200 disabled:opacity-40 transition-colors"
              title="Deshacer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              className="p-2 rounded-xl bg-[#F5F6FA] text-slate-700 hover:bg-slate-200 disabled:opacity-40 transition-colors"
              title="Rehacer"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={handleClear}
              className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors"
              title="Limpiar pizarra"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Paleta de Colores y Selector de Grosor */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 gap-2">
          {/* Colors */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
            {PALETTE.map((p) => (
              <button
                key={p.color}
                type="button"
                onClick={() => {
                  setCurrentColor(p.color);
                  if (activeTool === 'eraser' || activeTool === 'pan') setActiveTool('pen');
                  soundEffects.playSuccess();
                }}
                className={`w-6 h-6 rounded-full transition-transform flex items-center justify-center shrink-0 ${
                  currentColor === p.color && activeTool !== 'eraser' && activeTool !== 'pan'
                    ? 'ring-2 ring-offset-2 ring-slate-900 scale-115'
                    : 'hover:scale-105'
                }`}
                style={{ backgroundColor: p.color }}
                title={p.name}
              >
                {currentColor === p.color && activeTool !== 'eraser' && activeTool !== 'pan' && (
                  <Check className="w-3 h-3 text-white stroke-[3]" />
                )}
              </button>
            ))}
          </div>

          {/* Stroke Width Selector */}
          <div className="flex items-center gap-1 shrink-0 bg-[#F5F6FA] px-1.5 py-1 rounded-xl">
            {STROKE_SIZES.map((size) => (
              <button
                key={size}
                type="button"
                onClick={() => setStrokeWidth(size)}
                className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
                  strokeWidth === size ? 'bg-white shadow-xs font-bold text-slate-900' : 'text-slate-400'
                }`}
              >
                <div
                  className="rounded-full bg-slate-900"
                  style={{ width: `${Math.min(14, size + 2)}px`, height: `${Math.min(14, size + 2)}px` }}
                />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ÁREA DE PIZARRA INFINITA (CON CUADRÍCULA DINÁMICA QUE SE MUEVE Y HACE ZOOM) */}
      <div
        ref={containerRef}
        className="relative w-full h-[460px] sm:h-[500px] rounded-3xl bg-white border border-slate-200/90 shadow-md overflow-hidden select-none touch-none cursor-crosshair group"
        style={{
          backgroundImage: 'radial-gradient(#cbd5e1 1.5px, transparent 1.5px)',
          backgroundPosition: `${panOffset.x}px ${panOffset.y}px`,
          backgroundSize: `${24 * zoom}px ${24 * zoom}px`,
          backgroundColor: '#FFFFFF',
          cursor: activeTool === 'pan' ? 'grab' : activeTool === 'eraser' ? 'cell' : 'crosshair',
        }}
      >
        {/* Canvas HTML5 */}
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onWheel={handleWheel}
          className="absolute inset-0 w-full h-full"
        />

        {/* Indicador flotante de Coordenadas y Zoom en esquina superior */}
        <div className="absolute top-3 left-3 pointer-events-none flex items-center gap-1.5 z-10">
          <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-slate-900/80 backdrop-blur-xs text-white border border-slate-700">
            Zoom: {Math.round(zoom * 100)}%
          </span>
          <span className="text-[10px] font-medium px-2 py-1 rounded-lg bg-white/90 backdrop-blur-xs text-slate-700 border border-slate-200 shadow-xs">
            X: {Math.round(panOffset.x)} Y: {Math.round(panOffset.y)}
          </span>
        </div>

        {/* Controles flotantes de Zoom y Re-centrado en esquina inferior derecha */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 z-10 bg-white/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-200/80 shadow-lg">
          <button
            onClick={() => {
              const newZoom = Math.min(3.5, zoom + 0.2);
              setZoom(newZoom);
              soundEffects.playSuccess();
            }}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors"
            title="Acercar (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              const newZoom = Math.max(0.25, zoom - 0.2);
              setZoom(newZoom);
              soundEffects.playSuccess();
            }}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors"
            title="Alejar (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <button
            onClick={handleCenterView}
            className="px-2 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-[10px] font-bold transition-colors"
            title="Centrar en el origen (100%)"
          >
            100%
          </button>

          <button
            onClick={handleFitContent}
            className="p-1.5 rounded-xl bg-[#6857E8]/10 hover:bg-[#6857E8]/20 text-[#6857E8] transition-colors"
            title="Ajustar vista al contenido dibujado"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

        {/* Ayuda táctil si se está en modo Mover */}
        {activeTool === 'pan' && (
          <div className="absolute top-3 right-3 pointer-events-none z-10 bg-[#6857E8] text-white px-2.5 py-1 rounded-full text-[10px] font-bold shadow-md animate-pulse">
            Arrastra para desplazarte en el lienzo infinito
          </div>
        )}

        {/* Toast de confirmación */}
        {saveToast && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 bg-slate-950/90 text-white font-bold text-xs py-2.5 px-4 rounded-2xl shadow-2xl flex items-center gap-2 border border-slate-700 animate-in zoom-in-95 duration-150">
            <Check className="w-4 h-4 text-[#42C99A]" />
            <span>{saveToast}</span>
          </div>
        )}
      </div>

      {/* ACCIONES DE GUARDADO Y DESCARGA */}
      <div className="bg-white rounded-3xl p-3.5 shadow-sm border border-slate-200 space-y-2.5">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={drawingTitle}
            onChange={(e) => setDrawingTitle(e.target.value)}
            placeholder="Título del boceto..."
            className="flex-1 text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/30"
          />

          <button
            onClick={handleDownloadImage}
            className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0"
            title="Descargar imagen PNG completa"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Descargar PNG</span>
          </button>
        </div>

        <button
          onClick={handleSaveToMeeting}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#6857E8] to-[#4778F5] hover:from-[#5848db] hover:to-[#3867e0] text-white text-xs font-extrabold shadow-md shadow-[#6857E8]/25 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          <span>Guardar Boceto Infinito en la Reunión ({strokes.length} trazos)</span>
        </button>
      </div>

      {/* Galería de Bocetos Guardados en la Sesión */}
      {savedDrawings.length > 0 && (
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <ImageIcon className="w-4 h-4 text-[#6857E8]" />
              Bocetos de la Sesión ({savedDrawings.length})
            </span>
            <span className="text-[10px] text-slate-400">Incluidos en la descarga ZIP</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {savedDrawings.map((drawing) => (
              <div
                key={drawing.id}
                className="p-2 rounded-2xl border border-slate-200 bg-[#F5F6FA] flex flex-col gap-1.5"
              >
                <div className="w-full h-24 rounded-xl bg-white overflow-hidden border border-slate-200 flex items-center justify-center p-1">
                  <img
                    src={drawing.dataUrl}
                    alt={drawing.title}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-800 truncate">{drawing.title}</span>
                  <span className="text-slate-400 text-[10px]">{drawing.createdAt}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
