import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Edit3, 
  Clock, 
  BookOpen, 
  Search, 
  Check, 
  Copy, 
  CheckSquare, 
  List, 
  Minus, 
  Download, 
  Sparkles,
  Layers,
  ChevronRight,
  Save,
  Calendar
} from 'lucide-react';
import { NoteItem, MeetingSession, AcademicSettings } from '../types/campus';
import { soundEffects } from '../utils/sound';
import { formatTime } from '../utils/academic';

interface NotesViewProps {
  notes: NoteItem[];
  activeMeeting: MeetingSession | null;
  settings: AcademicSettings;
  onAddNote: (note: NoteItem) => void;
  onUpdateNote: (note: NoteItem) => void;
  onDeleteNote: (id: string) => void;
}

export const NotesView: React.FC<NotesViewProps> = ({
  notes,
  activeMeeting,
  settings,
  onAddNote,
  onUpdateNote,
  onDeleteNote,
}) => {
  // Mode: 'pad' (Block de notas libre) | 'archive' (Archivo de apuntes anteriores)
  const [viewMode, setViewMode] = useState<'pad' | 'archive'>('pad');

  // Currently active note in the Notepad
  const [activeNoteId, setActiveNoteId] = useState<string | null>(() => {
    return notes[0]?.id || null;
  });

  // Current Notepad Fields
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [courseId, setCourseId] = useState<string>(activeMeeting?.courseId || settings.courses[0]?.id || '');
  const [weekNumber, setWeekNumber] = useState<number>(activeMeeting?.weekNumber || 7);

  // Status & Feedback
  const [isSavedRecently, setIsSavedRecently] = useState<boolean>(true);
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterCourse, setFilterCourse] = useState<string>('all');
  const [deleteModalNote, setDeleteModalNote] = useState<NoteItem | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Sync course and week when activeMeeting changes
  useEffect(() => {
    if (activeMeeting) {
      setCourseId(activeMeeting.courseId);
      setWeekNumber(activeMeeting.weekNumber);
    }
  }, [activeMeeting]);

  // Load active note into editor when activeNoteId changes
  useEffect(() => {
    if (activeNoteId) {
      const found = notes.find((n) => n.id === activeNoteId);
      if (found) {
        setTitle(found.title);
        setContent(found.content);
        setCourseId(found.courseId);
        setWeekNumber(found.weekNumber);
      }
    } else if (notes.length > 0) {
      setActiveNoteId(notes[0].id);
    } else {
      // Create initial clean page
      setTitle('Apunte libre de reunión');
      setContent('');
    }
  }, [activeNoteId]);

  // Real-time Auto Save (Debounced)
  useEffect(() => {
    if (!title.trim() && !content.trim()) return;

    setIsSavedRecently(false);
    const timer = setTimeout(() => {
      const courseObj = settings.courses.find((c) => c.id === courseId) || settings.courses[0];
      const now = new Date();
      const formattedCreated = `${now.getDate()} ${now.toLocaleString('es-ES', { month: 'short' })}, ${formatTime(now)}`;

      if (activeNoteId) {
        const existing = notes.find((n) => n.id === activeNoteId);
        if (existing) {
          onUpdateNote({
            ...existing,
            title: title.trim() || 'Sin título',
            content,
            courseId,
            courseName: courseObj?.name || 'Curso General',
            weekNumber,
          });
        }
      } else {
        const newId = `note-${Date.now()}`;
        const newNote: NoteItem = {
          id: newId,
          title: title.trim() || 'Apunte libre',
          content,
          author: 'Carlos',
          createdAt: formattedCreated,
          courseId,
          courseName: courseObj?.name || 'Curso General',
          weekNumber,
          meetingId: activeMeeting?.id,
        };
        onAddNote(newNote);
        setActiveNoteId(newId);
      }
      setIsSavedRecently(true);
    }, 450);

    return () => clearTimeout(timer);
  }, [title, content, courseId, weekNumber]);

  // Quick Notepad Helper Insertions
  const insertTextAtCursor = (prefix: string) => {
    const el = textareaRef.current;
    if (!el) {
      setContent((prev) => prev + '\n' + prefix);
      return;
    }

    const start = el.selectionStart;
    const end = el.selectionEnd;
    const before = content.substring(0, start);
    const after = content.substring(end);

    const needsNewline = before.length > 0 && !before.endsWith('\n');
    const toInsert = (needsNewline ? '\n' : '') + prefix;

    const newContent = before + toInsert + after;
    setContent(newContent);

    setTimeout(() => {
      el.focus();
      const pos = start + toInsert.length;
      el.setSelectionRange(pos, pos);
    }, 10);
    soundEffects.playPttStart();
  };

  // Create a brand new blank note sheet
  const handleCreateNewSheet = () => {
    const now = new Date();
    const formattedCreated = `${now.getDate()} ${now.toLocaleString('es-ES', { month: 'short' })}, ${formatTime(now)}`;
    const courseObj = settings.courses.find((c) => c.id === courseId) || settings.courses[0];

    const newId = `note-${Date.now()}`;
    const newNote: NoteItem = {
      id: newId,
      title: `Apunte #${notes.length + 1}`,
      content: '',
      author: 'Carlos',
      createdAt: formattedCreated,
      courseId,
      courseName: courseObj?.name || 'Curso General',
      weekNumber,
      meetingId: activeMeeting?.id,
    };

    onAddNote(newNote);
    setActiveNoteId(newId);
    setTitle(newNote.title);
    setContent('');
    setViewMode('pad');
    soundEffects.playSuccess();

    setTimeout(() => {
      textareaRef.current?.focus();
    }, 50);
  };

  // Copy note
  const handleCopyNote = () => {
    const fullText = `${title}\n\n${content}\n\n[CampUs · ${courseObj?.name} · Semana ${weekNumber}]`;
    navigator.clipboard.writeText(fullText);
    setCopiedNotification(true);
    soundEffects.playSuccess();
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  // Download note as plain text
  const handleDownloadSingleNote = () => {
    const textBlob = new Blob([`${title}\n\n${content}`], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(textBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    soundEffects.playSuccess();
  };

  // Words and character counts
  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const charCount = content.length;
  const courseObj = settings.courses.find((c) => c.id === courseId);

  // Filtered notes for Archive view
  const filteredNotes = notes.filter((n) => {
    if (filterCourse !== 'all' && n.courseId !== filterCourse) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return (
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        n.courseName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="flex flex-col gap-3 pb-28 px-4 pt-3 select-none">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#6857E8]" />
            Block de Notas
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Escritura libre para apuntes e indicaciones rápidas
          </p>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1 bg-[#F5F6FA] p-1 rounded-2xl border border-slate-200">
          <button
            onClick={() => setViewMode('pad')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'pad'
                ? 'bg-[#111827] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Notepad</span>
          </button>

          <button
            onClick={() => setViewMode('archive')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'archive'
                ? 'bg-[#111827] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Hojas ({notes.length})</span>
          </button>
        </div>
      </div>

      {/* Active Meeting Context Banner */}
      {activeMeeting ? (
        <div className="p-2.5 rounded-2xl bg-indigo-50 border border-indigo-200/90 flex items-center justify-between text-xs text-slate-800 font-medium">
          <div className="flex items-center gap-2 truncate">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shrink-0" />
            <span className="truncate">
              Vinculado a: <strong>{activeMeeting.courseName}</strong> (Semana {activeMeeting.weekNumber})
            </span>
          </div>
          <span className="text-[10px] bg-white px-2 py-0.5 rounded-md font-bold text-[#6857E8] border border-indigo-100 shrink-0">
            Exportación ZIP activa
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-2xl border border-slate-200 text-xs text-slate-600">
          <span className="font-bold text-slate-700">Asociar a:</span>
          <select
            value={courseId}
            onChange={(e) => setCourseId(e.target.value)}
            className="bg-[#F5F6FA] text-slate-800 text-xs font-bold px-2 py-1 rounded-xl border border-slate-200 focus:outline-none"
          >
            {settings.courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <span className="text-slate-400">·</span>
          <span className="font-bold text-[#6857E8]">Semana {weekNumber}</span>
        </div>
      )}

      {/* VIEW 1: BLOCK DE NOTAS LIBRE (NOTEPAD REALISTA) */}
      {viewMode === 'pad' && (
        <div className="flex flex-col gap-2.5">
          {/* Hojas / Tabs Horizontal Switcher */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={handleCreateNewSheet}
              className="px-3 py-1.5 rounded-xl bg-[#6857E8] hover:bg-[#5848db] text-white text-xs font-extrabold flex items-center gap-1 shrink-0 shadow-sm transition-transform active:scale-95"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>Nueva Hoja</span>
            </button>

            {notes.map((note) => (
              <button
                key={note.id}
                onClick={() => {
                  setActiveNoteId(note.id);
                  soundEffects.playSuccess();
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all border flex items-center gap-1.5 max-w-[140px] ${
                  activeNoteId === note.id
                    ? 'bg-white border-slate-300 text-slate-900 shadow-xs ring-1 ring-slate-900/10'
                    : 'bg-[#F5F6FA] border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <FileText className="w-3 h-3 text-[#6857E8] shrink-0" />
                <span className="truncate">{note.title || 'Sin título'}</span>
              </button>
            ))}
          </div>

          {/* SUPERFICIE DEL BLOCK DE NOTAS */}
          <div className="relative rounded-3xl bg-[#FFFDF7] border-2 border-amber-200/70 shadow-md p-4 sm:p-5 flex flex-col gap-3 min-h-[460px]">
            {/* Cabecera del block estilo Libreta con grapas visuales */}
            <div className="flex items-center justify-between pb-2.5 border-b-2 border-amber-200/80">
              <div className="flex-1 mr-2">
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Título del apunte... (ej. Acuerdos de entrega, Metodología)"
                  className="w-full text-base font-extrabold text-slate-900 bg-transparent placeholder-amber-900/30 focus:outline-none"
                />
                <div className="flex items-center gap-2 text-[10px] text-amber-800/70 font-medium mt-0.5">
                  <span>{courseObj?.name}</span>
                  <span>·</span>
                  <span>Semana {weekNumber}</span>
                  <span>·</span>
                  <span>Carlos (Coordinador)</span>
                </div>
              </div>

              {/* Status de auto guardado */}
              <div className="flex items-center gap-1.5 shrink-0">
                {isSavedRecently ? (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-lg flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Guardado</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-medium text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-lg animate-pulse">
                    Guardando...
                  </span>
                )}
              </div>
            </div>

            {/* BARRA DE HERRAMIENTAS RÁPIDAS DEL BLOCK DE NOTAS */}
            <div className="flex items-center justify-between gap-1 py-1 px-1 bg-amber-100/50 rounded-2xl border border-amber-200/60 overflow-x-auto">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => insertTextAtCursor('• ')}
                  className="px-2 py-1 rounded-xl bg-white/80 hover:bg-white text-slate-800 text-[11px] font-bold flex items-center gap-1 shadow-2xs transition-colors"
                  title="Insertar viñeta"
                >
                  <List className="w-3 h-3 text-[#6857E8]" />
                  <span>Viñeta</span>
                </button>

                <button
                  type="button"
                  onClick={() => insertTextAtCursor('[ ] ')}
                  className="px-2 py-1 rounded-xl bg-white/80 hover:bg-white text-slate-800 text-[11px] font-bold flex items-center gap-1 shadow-2xs transition-colors"
                  title="Insertar casilla de verificación"
                >
                  <CheckSquare className="w-3 h-3 text-[#42C99A]" />
                  <span>Casilla</span>
                </button>

                <button
                  type="button"
                  onClick={() => insertTextAtCursor(`[${formatTime(new Date())}] `)}
                  className="px-2 py-1 rounded-xl bg-white/80 hover:bg-white text-slate-800 text-[11px] font-bold flex items-center gap-1 shadow-2xs transition-colors"
                  title="Insertar marca de hora actual"
                >
                  <Clock className="w-3 h-3 text-amber-600" />
                  <span>Hora</span>
                </button>

                <button
                  type="button"
                  onClick={() => insertTextAtCursor('\n────────────────────────────\n')}
                  className="px-2 py-1 rounded-xl bg-white/80 hover:bg-white text-slate-800 text-[11px] font-bold flex items-center gap-1 shadow-2xs transition-colors"
                  title="Insertar separador"
                >
                  <Minus className="w-3 h-3 text-slate-500" />
                  <span>Línea</span>
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleCopyNote}
                  className="p-1.5 rounded-xl bg-white/80 hover:bg-white text-slate-700 transition-colors"
                  title="Copiar texto completo"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={handleDownloadSingleNote}
                  className="p-1.5 rounded-xl bg-white/80 hover:bg-white text-slate-700 transition-colors"
                  title="Descargar este apunte en .txt"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* ÁREA DE TEXTO LIBRE (TEXTAREA ESTILO NOTEPAD) */}
            <div className="flex-1 flex flex-col relative">
              <textarea
                ref={textareaRef}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Escribe aquí con total libertad: ideas, pendientes, resúmenes o acuerdos hablados durante la llamada...

Ejemplo:
• Entregar marco teórico antes de medianoche.
• [ ] Camila redactará los objetivos específicos.
• [ ] Diego consolidará las métricas de campo."
                rows={12}
                className="w-full flex-1 bg-transparent text-slate-800 text-sm leading-relaxed placeholder-amber-900/35 focus:outline-none resize-none font-normal"
                style={{
                  lineHeight: '26px',
                  backgroundImage: 'repeating-linear-gradient(transparent, transparent 25px, #fde68a 26px)',
                  backgroundAttachment: 'local',
                }}
              />
            </div>

            {/* Pie del Block de Notas con conteo */}
            <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between text-[11px] text-amber-900/60 font-medium">
              <div className="flex items-center gap-2">
                <span>{wordCount} palabras</span>
                <span>·</span>
                <span>{charCount} caracteres</span>
              </div>
              <span>Se guardará en el ZIP al finalizar</span>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: ARCHIVO DE HOJAS GUARDADAS (HISTORIAL DE NOTAS CON BÚSQUEDA) */}
      {viewMode === 'archive' && (
        <div className="flex flex-col gap-3">
          {/* Search & Course Filter */}
          <div className="bg-white rounded-3xl p-3.5 shadow-sm border border-slate-200 space-y-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar apuntes por palabras clave..."
                className="w-full text-xs pl-9 pr-3 py-2 rounded-2xl border border-slate-200 bg-[#F5F6FA] focus:outline-none"
              />
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-0.5">
              <button
                onClick={() => setFilterCourse('all')}
                className={`text-[10px] px-3 py-1 rounded-xl shrink-0 font-bold transition-all ${
                  filterCourse === 'all'
                    ? 'bg-[#111827] text-white'
                    : 'bg-[#F5F6FA] text-slate-600 hover:bg-slate-200'
                }`}
              >
                Todos los Cursos
              </button>
              {settings.courses.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setFilterCourse(c.id)}
                  className={`text-[10px] px-3 py-1 rounded-xl shrink-0 font-bold transition-all ${
                    filterCourse === c.id
                      ? 'bg-[#6857E8] text-white'
                      : 'bg-[#F5F6FA] text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          {/* Notes Cards List */}
          {filteredNotes.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-400 text-xs">
              No se encontraron apuntes con el criterio de búsqueda.
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredNotes.map((note) => (
                <div
                  key={note.id}
                  className="bg-white rounded-3xl p-4 border border-slate-200 hover:border-indigo-200 shadow-sm transition-all flex flex-col gap-2 group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="text-[10px] font-bold text-[#6857E8] bg-[#6857E8]/10 px-2 py-0.5 rounded-md">
                          Semana {note.weekNumber}
                        </span>
                        <span className="text-[11px] font-bold text-slate-500">
                          {note.courseName}
                        </span>
                      </div>
                      <h3 className="text-sm font-extrabold text-slate-900 leading-snug">
                        {note.title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => {
                          setActiveNoteId(note.id);
                          setViewMode('pad');
                          soundEffects.playSuccess();
                        }}
                        className="p-1.5 rounded-xl bg-indigo-50 text-[#6857E8] hover:bg-indigo-100 transition-colors"
                        title="Abrir en Block de Notas"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => setDeleteModalNote(note)}
                        className="p-1.5 rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                        title="Eliminar apunte"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed font-normal whitespace-pre-wrap">
                    {note.content}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 border-t border-slate-100 font-medium">
                    <span>Autor: {note.author}</span>
                    <span>{note.createdAt}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteModalNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900">
              ¿Eliminar esta hoja de apunte?
            </h3>
            <p className="text-xs text-slate-600">
              Se eliminará <strong>"{deleteModalNote.title}"</strong> de los registros. Esta acción no se puede deshacer.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteModalNote(null)}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  onDeleteNote(deleteModalNote.id);
                  setDeleteModalNote(null);
                  soundEffects.playPttEnd();
                }}
                className="px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white transition-colors"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification for Clipboard Copy */}
      {copiedNotification && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white font-bold text-xs py-2 px-4 rounded-2xl shadow-xl flex items-center gap-2 animate-in zoom-in-95 duration-150">
          <Check className="w-4 h-4 text-[#42C99A]" />
          <span>Apunte copiado al portapapeles</span>
        </div>
      )}
    </div>
  );
};
