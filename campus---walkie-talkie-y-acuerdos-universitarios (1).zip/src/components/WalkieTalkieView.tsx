import React, { useState, useRef, useEffect } from 'react';
import { 
  Radio, 
  Disc, 
  Users, 
  FolderGit2, 
  User, 
  Mic, 
  Square, 
  Play, 
  Pause, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Sparkles,
  Info
} from 'lucide-react';
import { 
  RecipientType, 
  WalkieTransmission, 
  SimulatedRecording, 
  MeetingSession, 
  Participant 
} from '../types/campus';
import { DEMO_PARTICIPANTS } from '../config/initialData';
import { soundEffects } from '../utils/sound';
import { formatDuration, formatTime } from '../utils/academic';

interface WalkieTalkieViewProps {
  activeMeeting: MeetingSession | null;
  onAddTransmission: (tx: WalkieTransmission) => void;
  onUpdateRecording: (rec: SimulatedRecording) => void;
  onOpenStartMeetingModal: () => void;
}

export const WalkieTalkieView: React.FC<WalkieTalkieViewProps> = ({
  activeMeeting,
  onAddTransmission,
  onUpdateRecording,
  onOpenStartMeetingModal,
}) => {
  // PTT State
  const [recipientType, setRecipientType] = useState<RecipientType>('all');
  const [selectedGroupName, setSelectedGroupName] = useState<string>(
    activeMeeting?.projectName || 'Subgrupo de Trabajo'
  );
  const [selectedPerson, setSelectedPerson] = useState<Participant>(DEMO_PARTICIPANTS[1]); // Diego
  const [isTransmitting, setIsTransmitting] = useState<boolean>(false);
  const [transmissionSeconds, setTransmissionSeconds] = useState<number>(0);
  const [sentToast, setSentToast] = useState<string | null>(null);

  // Recording State
  const [isRecordingModalOpen, setIsRecordingModalOpen] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordingStartTime, setRecordingStartTime] = useState<string>('');

  // Refs for timers & safe pointer handling
  const pttTimerRef = useRef<number | null>(null);
  const pttStartMsRef = useRef<number>(0);
  const pttActiveRef = useRef<boolean>(false);
  const recTimerRef = useRef<number | null>(null);

  // Clean timers on unmount
  useEffect(() => {
    return () => {
      if (pttTimerRef.current) clearInterval(pttTimerRef.current);
      if (recTimerRef.current) clearInterval(recTimerRef.current);
    };
  }, []);

  // Update selected group name when meeting changes
  useEffect(() => {
    if (activeMeeting) {
      setSelectedGroupName(activeMeeting.projectName);
    }
  }, [activeMeeting]);

  // Handle Recording Timer
  useEffect(() => {
    if (isRecording && !isPaused) {
      recTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (recTimerRef.current) {
        clearInterval(recTimerRef.current);
        recTimerRef.current = null;
      }
    }
    return () => {
      if (recTimerRef.current) clearInterval(recTimerRef.current);
    };
  }, [isRecording, isPaused]);

  // Determine current active recipient label
  const getRecipientLabel = (): string => {
    if (recipientType === 'all') return 'Todos los participantes';
    if (recipientType === 'group') return `Subgrupo: ${selectedGroupName}`;
    return `Compañero: ${selectedPerson.name}`;
  };

  const getRecipientShortName = (): string => {
    if (recipientType === 'all') return 'Todos';
    if (recipientType === 'group') return selectedGroupName;
    return selectedPerson.name;
  };

  // Pointer Down -> Start PTT transmission
  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    if (pttActiveRef.current) return;

    pttActiveRef.current = true;
    setIsTransmitting(true);
    setTransmissionSeconds(0);
    pttStartMsRef.current = Date.now();

    soundEffects.playPttStart();

    pttTimerRef.current = window.setInterval(() => {
      setTransmissionSeconds((prev) => prev + 1);
    }, 1000);
  };

  // Pointer Up / Cancel / Leave -> End PTT transmission cleanly
  const handlePointerEnd = (e: React.PointerEvent) => {
    e.preventDefault();
    if (!pttActiveRef.current) return;

    pttActiveRef.current = false;
    setIsTransmitting(false);

    if (pttTimerRef.current) {
      clearInterval(pttTimerRef.current);
      pttTimerRef.current = null;
    }

    const elapsedMs = Date.now() - pttStartMsRef.current;
    const finalSeconds = Math.max(1, Math.round(elapsedMs / 1000));

    soundEffects.playPttEnd();

    const recipientShort = getRecipientShortName();
    const recipientFull = getRecipientLabel();
    const currentTimeStr = formatTime(new Date());

    const newTransmission: WalkieTransmission = {
      id: `tx-${Date.now()}`,
      recipientType,
      recipientName: recipientShort,
      targetLabel: recipientFull,
      timestamp: currentTimeStr,
      durationSeconds: finalSeconds,
      summary: `Mensaje simulado para ${recipientShort}`,
      detail: `[Maqueta de voz] Indicación táctil de ${finalSeconds}s enviada a ${recipientShort}.`,
    };

    onAddTransmission(newTransmission);

    setSentToast(`Transmisión de ${finalSeconds}s registrada para ${recipientShort}`);
    setTimeout(() => setSentToast(null), 3000);
  };

  // Recording Controls
  const handleRequestStartRecording = () => {
    if (!activeMeeting) {
      onOpenStartMeetingModal();
      return;
    }
    setIsRecordingModalOpen(true);
  };

  const handleConfirmStartRecording = () => {
    setIsRecordingModalOpen(false);
    setIsRecording(true);
    setIsPaused(false);
    setRecordingSeconds(0);
    const startStr = formatTime(new Date());
    setRecordingStartTime(startStr);
    soundEffects.playRecordStart();
  };

  const handleTogglePauseRecording = () => {
    setIsPaused(!isPaused);
    soundEffects.playSuccess();
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    setIsPaused(false);
    const endStr = formatTime(new Date());
    soundEffects.playRecordEnd();

    const recordingResult: SimulatedRecording = {
      id: `rec-${Date.now()}`,
      durationSeconds: Math.max(1, recordingSeconds),
      startTime: recordingStartTime || '16:00',
      endTime: endStr,
      status: 'completed',
      consentConfirmed: true,
    };

    onUpdateRecording(recordingResult);
    setSentToast(`Grabación simulada guardada (${formatDuration(recordingSeconds)})`);
    setTimeout(() => setSentToast(null), 3500);
  };

  return (
    <div className="flex flex-col gap-4 pb-28 px-4 pt-3 select-none">
      {/* Session Context Header Banner */}
      <div className="bg-white rounded-3xl p-3.5 shadow-sm border border-slate-200/80 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#42C99A] animate-pulse shrink-0" />
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500">
              Canal de Comunicación
            </span>
          </div>
          <div className="text-sm font-extrabold text-slate-900 truncate mt-0.5">
            {activeMeeting ? activeMeeting.courseName : 'Modo General (Sin reunión activa)'}
          </div>
          <div className="text-[11px] text-slate-500 truncate">
            {activeMeeting ? `${activeMeeting.projectName} · ${activeMeeting.groupName}` : 'Inicia una reunión para asociar transmisiones a una sesión'}
          </div>
        </div>

        {!activeMeeting && (
          <button
            onClick={onOpenStartMeetingModal}
            className="shrink-0 px-3 py-1.5 rounded-xl bg-[#6857E8] text-white text-xs font-bold hover:bg-[#5746db] transition-colors"
          >
            Iniciar Sesión
          </button>
        )}
      </div>

      {/* SISTEMA DE GRABACIÓN DE REUNIONES */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Disc className={`w-4 h-4 ${isRecording ? 'text-red-500 animate-spin' : 'text-slate-500'}`} />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Grabación de la Sesión
            </h2>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
            Simulación visual
          </span>
        </div>

        {isRecording ? (
          <div className="p-3.5 rounded-2xl bg-red-50/70 border border-red-200/80 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-600 animate-ping" />
                <span className="text-xs font-black text-red-700 uppercase tracking-wider">
                  {isPaused ? 'Grabación en Pausa' : 'Grabando Reunión...'}
                </span>
              </div>
              <span className="font-mono text-sm font-black text-red-900 tabular-nums">
                {formatDuration(recordingSeconds)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleTogglePauseRecording}
                className="flex-1 py-2 px-3 rounded-xl bg-white border border-red-200 text-red-800 text-xs font-bold hover:bg-red-50 transition-colors flex items-center justify-center gap-1.5"
              >
                {isPaused ? <Play className="w-3.5 h-3.5 fill-red-800" /> : <Pause className="w-3.5 h-3.5 fill-red-800" />}
                <span>{isPaused ? 'Reanudar' : 'Pausar'}</span>
              </button>

              <button
                type="button"
                onClick={handleStopRecording}
                className="flex-1 py-2 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm shadow-red-600/30"
              >
                <Square className="w-3.5 h-3.5 fill-white" />
                <span>Finalizar Grabación</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-2xl bg-[#F5F6FA] border border-slate-200">
            <div>
              <div className="text-xs font-bold text-slate-800">
                {activeMeeting?.recording?.status === 'completed' 
                  ? 'Grabación de demostración finalizada' 
                  : 'Listo para registrar audio simulado'}
              </div>
              <div className="text-[11px] text-slate-500">
                {activeMeeting?.recording?.status === 'completed'
                  ? `Duración registrada: ${formatDuration(activeMeeting.recording.durationSeconds)} (${activeMeeting.recording.startTime} - ${activeMeeting.recording.endTime})`
                  : 'Requiere consentimiento de los participantes antes de iniciar'}
              </div>
            </div>

            <button
              type="button"
              onClick={handleRequestStartRecording}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold transition-all shadow-md shadow-red-600/20 active:scale-95 flex items-center gap-2 shrink-0"
            >
              <Disc className="w-4 h-4" />
              <span>{activeMeeting?.recording?.status === 'completed' ? 'Grabar de Nuevo' : 'Iniciar Grabación'}</span>
            </button>
          </div>
        )}
      </div>

      {/* SELECTOR DE DESTINATARIO */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-2.5">
          <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-[#6857E8]" />
            1. Destinatario de Voz
          </label>
          <span className="text-[11px] text-[#6857E8] font-bold bg-[#6857E8]/10 px-2 py-0.5 rounded-full">
            {recipientType === 'all' ? 'Todo el equipo' : recipientType === 'group' ? 'Por subgrupo' : 'Individual'}
          </span>
        </div>

        {/* 3 Opciones funcionales: TODOS | GRUPO | PERSONA */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#F5F6FA] rounded-2xl border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setRecipientType('all');
              soundEffects.playSuccess();
            }}
            className={`py-2 px-1 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 ${
              recipientType === 'all'
                ? 'bg-[#111827] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>TODOS</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setRecipientType('group');
              soundEffects.playSuccess();
            }}
            className={`py-2 px-1 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 ${
              recipientType === 'group'
                ? 'bg-[#111827] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <FolderGit2 className="w-4 h-4" />
            <span>GRUPO</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setRecipientType('person');
              soundEffects.playSuccess();
            }}
            className={`py-2 px-1 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 ${
              recipientType === 'person'
                ? 'bg-[#111827] text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <User className="w-4 h-4" />
            <span>PERSONA</span>
          </button>
        </div>

        {/* Dynamic Context Selector based on Tab */}
        <div className="mt-3 pt-3 border-t border-slate-100">
          {recipientType === 'all' && (
            <div className="p-3 bg-gradient-to-r from-indigo-50/80 to-blue-50/80 border border-indigo-100 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#6857E8] to-[#4778F5] flex items-center justify-center text-white shadow-sm">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">Canal General Abierto</div>
                  <div className="text-[11px] text-slate-500">
                    Transmisión simulada a todos los miembros ({activeMeeting?.participants.length || DEMO_PARTICIPANTS.length} integrantes)
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                En vivo
              </span>
            </div>
          )}

          {recipientType === 'group' && (
            <div className="space-y-2">
              <span className="text-[11px] font-medium text-slate-500 block">Subgrupos disponibles:</span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  activeMeeting?.projectName || 'Validación del problema',
                  'Laboratorio / Métricas',
                  'Redacción del Informe',
                ].map((grp) => (
                  <button
                    key={grp}
                    type="button"
                    onClick={() => {
                      setSelectedGroupName(grp);
                      soundEffects.playSuccess();
                    }}
                    className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all ${
                      selectedGroupName === grp
                        ? 'border-[#6857E8] bg-[#6857E8]/10 text-[#6857E8] ring-1 ring-[#6857E8]/30'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {grp}
                  </button>
                ))}
              </div>
            </div>
          )}

          {recipientType === 'person' && (
            <div className="space-y-2">
              <span className="text-[11px] font-medium text-slate-500 block">Selecciona un compañero:</span>
              <div className="grid grid-cols-3 gap-2">
                {DEMO_PARTICIPANTS.filter((p) => p.id !== 'carlos').map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setSelectedPerson(p);
                      soundEffects.playSuccess();
                    }}
                    className={`p-2 rounded-xl border text-center transition-all flex flex-col items-center ${
                      selectedPerson.id === p.id
                        ? 'border-[#4778F5] bg-[#4778F5]/10 ring-2 ring-[#4778F5]/25 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full bg-gradient-to-tr ${p.avatarBg} text-white font-bold text-xs flex items-center justify-center mb-1 shadow-xs`}>
                      {p.initials}
                    </div>
                    <div className="text-xs font-bold text-slate-900 truncate max-w-full">
                      {p.name}
                    </div>
                    <div className="text-[9px] text-slate-400 truncate max-w-full">
                      {p.role}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ESTACIÓN CENTRAL DE WALKIE-TALKIE */}
      <div className="relative bg-gradient-to-b from-[#111827] to-[#1e293b] rounded-3xl p-5 text-white shadow-xl border border-slate-800 text-center flex flex-col items-center justify-center min-h-[300px] overflow-hidden">
        {/* Indicador de canal */}
        <div className="z-10 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-700 text-xs font-medium text-slate-300 mb-2">
          <span className={`w-2 h-2 rounded-full ${isTransmitting ? 'bg-red-500 animate-ping' : 'bg-[#42C99A]'}`} />
          <span className="text-slate-400 font-semibold">Destinatario:</span>
          <span className="text-white font-bold truncate max-w-[200px]">
            {getRecipientLabel()}
          </span>
        </div>

        {/* Dynamic Status text */}
        <div className="z-10 h-10 flex flex-col items-center justify-center mb-2">
          {isTransmitting ? (
            <div className="flex flex-col items-center animate-pulse">
              <div className="flex items-center gap-2 text-red-400 font-black text-sm tracking-wide">
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-red-500" />
                TRANSMITIENDO... 00:{transmissionSeconds.toString().padStart(2, '0')}
              </div>
              <p className="text-[11px] text-slate-300 font-medium">
                Hablando con: <span className="text-[#42C99A] font-bold">{getRecipientShortName()}</span>
              </p>
            </div>
          ) : (
            <p className="text-xs text-slate-400 font-medium">
              Simulación de indicación rápida de voz (&lt; 15s)
            </p>
          )}
        </div>

        {/* BOTÓN PRINCIPAL DE MICRÓFONO CON POINTER EVENTS SEGUROS */}
        <div className="relative z-10 my-2 touch-none">
          {/* Animated concentric pulsing waves */}
          {isTransmitting && (
            <>
              <div className="absolute -inset-6 rounded-full bg-[#6857E8]/30 blur-md animate-ping" />
              <div className="absolute -inset-10 rounded-full border-2 border-[#4778F5]/40 animate-pulse" />
              <div className="absolute -inset-14 rounded-full border border-[#42C99A]/30 animate-pulse" />
            </>
          )}

          {/* Equalizer frequency bars when transmitting */}
          {isTransmitting && (
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 flex items-center gap-1 h-8 z-20">
              <span className="w-1.5 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.1s] h-5" />
              <span className="w-1.5 bg-[#4778F5] rounded-full animate-bounce [animation-delay:0.3s] h-8" />
              <span className="w-1.5 bg-[#6857E8] rounded-full animate-bounce [animation-delay:0.2s] h-6" />
              <span className="w-1.5 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.4s] h-7" />
              <span className="w-1.5 bg-[#4778F5] rounded-full animate-bounce [animation-delay:0.15s] h-4" />
            </div>
          )}

          <button
            type="button"
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerEnd}
            onPointerLeave={handlePointerEnd}
            onPointerCancel={handlePointerEnd}
            onContextMenu={(e) => e.preventDefault()}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center transition-all duration-150 select-none cursor-pointer focus:outline-none shadow-2xl relative active:scale-95 ${
              isTransmitting
                ? 'bg-gradient-to-tr from-red-600 via-rose-600 to-orange-500 ring-8 ring-red-500/30 scale-105'
                : 'bg-gradient-to-tr from-[#6857E8] via-[#4778F5] to-[#42C99A] ring-8 ring-[#6857E8]/20 hover:scale-[1.02]'
            }`}
            aria-label="Botón de Walkie Talkie"
          >
            <div className="w-[124px] h-[124px] rounded-full bg-[#111827]/85 backdrop-blur-sm flex flex-col items-center justify-center p-2 text-center border border-white/20">
              <Mic className={`w-8 h-8 mb-1 transition-transform ${isTransmitting ? 'text-red-400 scale-110 animate-pulse' : 'text-white'}`} />
              <span className="text-[11px] font-black tracking-tight uppercase leading-snug px-1 text-slate-100">
                {isTransmitting ? 'Transmitiendo...' : 'Mantén presionado para hablar'}
              </span>
              <span className="text-[8px] font-bold text-[#42C99A] mt-0.5 uppercase tracking-wider">
                Simulación
              </span>
            </div>
          </button>
        </div>

        <p className="z-10 text-[11px] text-slate-400 mt-2 font-medium">
          {isTransmitting ? 'Suelta el botón para finalizar el mensaje' : 'Presiona con el dedo o clic sostenido'}
        </p>

        {/* Confirmation Toast */}
        {sentToast && (
          <div className="absolute bottom-3 left-4 right-4 z-30 bg-[#42C99A] text-slate-950 font-bold text-xs py-2 px-3 rounded-2xl shadow-lg flex items-center justify-center gap-1.5 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span className="truncate">{sentToast}</span>
          </div>
        )}
      </div>

      {/* Historial de Transmisiones de la Reunión */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
              Transmisiones de la Sesión
            </h3>
          </div>
          <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            {activeMeeting?.walkieTransmissions.length || 0} mensajes
          </span>
        </div>

        {(!activeMeeting || activeMeeting.walkieTransmissions.length === 0) ? (
          <div className="py-6 text-center text-slate-400 text-xs">
            Aún no hay transmisiones en esta sesión. Mantén presionado el botón central para simular una indicación.
          </div>
        ) : (
          <div className="space-y-2">
            {activeMeeting.walkieTransmissions.map((tx) => (
              <div
                key={tx.id}
                className="p-3 rounded-2xl border border-slate-150 bg-[#F5F6FA] flex items-start justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900">
                    <span className="text-[#6857E8]">Para: {tx.recipientName}</span>
                    <span className="text-slate-300">·</span>
                    <span className="text-[10px] text-slate-400 font-normal">{tx.timestamp}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                    {tx.detail}
                  </p>
                </div>
                <span className="shrink-0 text-[10px] font-bold text-slate-500 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                  {tx.durationSeconds}s
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL DE CONSENTIMIENTO DE GRABACIÓN */}
      {isRecordingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-100 flex items-center justify-center mx-auto mb-3">
              <ShieldCheck className="w-6 h-6 text-red-600" />
            </div>

            <h3 className="text-base font-extrabold text-slate-900">
              Consentimiento de Grabación
            </h3>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              En cumplimiento de las normas de privacidad académica, la futura aplicación solicitará la aprobación de todos los participantes del equipo antes de registrar audio.
            </p>

            <div className="my-3 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-left text-[11px] text-slate-700 space-y-1">
              <div className="font-bold text-slate-900 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Consentimiento del equipo simulado
              </div>
              <p className="text-slate-500">
                Curso: {activeMeeting?.courseName || 'Proyecto Grupal'}
              </p>
            </div>

            <div className="flex items-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => setIsRecordingModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmStartRecording}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold transition-all shadow-md shadow-red-600/30"
              >
                Aceptar e Iniciar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
