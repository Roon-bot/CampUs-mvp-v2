import React, { useState } from 'react';
import { 
  FolderClock, 
  Search, 
  Calendar, 
  Clock, 
  Users, 
  Disc, 
  FileText, 
  CheckSquare, 
  PenTool, 
  ChevronRight, 
  X, 
  Play, 
  Square,
  BookOpen,
  Filter,
  CheckCircle2,
  Layers,
  Download,
  FolderArchive
} from 'lucide-react';
import { MeetingSession, AcademicSettings } from '../types/campus';
import { formatDuration } from '../utils/academic';
import { soundEffects } from '../utils/sound';
import { downloadMeetingZip } from '../utils/zipExport';

interface HistoryViewProps {
  meetings: MeetingSession[];
  settings: AcademicSettings;
  selectedMeetingDetail: MeetingSession | null;
  onSelectMeetingDetail: (meeting: MeetingSession | null) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  meetings,
  settings,
  selectedMeetingDetail,
  onSelectMeetingDetail,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [courseFilter, setCourseFilter] = useState('all');
  const [weekFilter, setWeekFilter] = useState('all');

  // Detail Modal Tab State
  const [detailTab, setDetailTab] = useState<'grabacion' | 'apuntes' | 'acuerdos' | 'dibujos'>('acuerdos');
  const [simulatingPlayback, setSimulatingPlayback] = useState(false);

  const [downloadingZip, setDownloadingZip] = useState(false);

  const handleDownloadZip = async (session: MeetingSession) => {
    try {
      setDownloadingZip(true);
      await downloadMeetingZip(session);
      soundEffects.playSuccess();
    } catch (e) {
      console.error('Error al descargar ZIP:', e);
    } finally {
      setDownloadingZip(false);
    }
  };

  // Group meetings by Course
  const filteredMeetings = meetings.filter((m) => {
    if (courseFilter !== 'all' && m.courseId !== courseFilter) return false;
    if (weekFilter !== 'all' && m.weekNumber.toString() !== weekFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchCourse = m.courseName.toLowerCase().includes(q);
      const matchProj = m.projectName.toLowerCase().includes(q);
      const matchGroup = m.groupName.toLowerCase().includes(q);
      const matchNotes = m.notes.some((n) => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q));
      const matchAgreements = m.agreements.some((a) => a.description.toLowerCase().includes(q) || a.assignee.toLowerCase().includes(q));
      if (!matchCourse && !matchProj && !matchGroup && !matchNotes && !matchAgreements) return false;
    }
    return true;
  });

  // Unique weeks in history
  const availableWeeks = Array.from(new Set(meetings.map((m) => m.weekNumber))).sort((a, b) => b - a);

  const handleTogglePlayback = () => {
    if (simulatingPlayback) {
      setSimulatingPlayback(false);
    } else {
      setSimulatingPlayback(true);
      soundEffects.playRecordStart();
      setTimeout(() => {
        setSimulatingPlayback(false);
      }, 6000);
    }
  };

  return (
    <div className="flex flex-col gap-4 pb-28 px-4 pt-3 select-none">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <FolderClock className="w-5 h-5 text-[#6857E8]" />
            Historial de Sesiones
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Agrupadas por curso y semana académica
          </p>
        </div>

        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
          Búsqueda &lt; 1 min
        </span>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-3xl p-3.5 shadow-sm border border-slate-200 space-y-2.5">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por curso, proyecto, apunte o acuerdo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-9 pr-3 py-2 rounded-2xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/20"
          />
        </div>

        {/* Filter Pills by Course */}
        <div>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Filtrar por curso:
          </span>
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setCourseFilter('all')}
              className={`text-[10px] px-3 py-1 rounded-xl shrink-0 font-bold transition-all ${
                courseFilter === 'all'
                  ? 'bg-[#111827] text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              Todos los Cursos
            </button>
            {settings.courses.map((c) => (
              <button
                key={c.id}
                onClick={() => setCourseFilter(c.id)}
                className={`text-[10px] px-3 py-1 rounded-xl shrink-0 font-bold transition-all ${
                  courseFilter === c.id
                    ? 'bg-[#6857E8] text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Filter Pills by Week */}
        {availableWeeks.length > 0 && (
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Por semana:
            </span>
            <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              <button
                onClick={() => setWeekFilter('all')}
                className={`text-[10px] px-3 py-1 rounded-xl shrink-0 font-bold transition-all ${
                  weekFilter === 'all'
                    ? 'bg-[#111827] text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Todas las semanas
              </button>
              {availableWeeks.map((w) => (
                <button
                  key={w}
                  onClick={() => setWeekFilter(w.toString())}
                  className={`text-[10px] px-3 py-1 rounded-xl shrink-0 font-bold transition-all ${
                    weekFilter === w.toString()
                      ? 'bg-[#4778F5] text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Semana {w}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Lista Agrupada por Curso */}
      <div className="space-y-4">
        {filteredMeetings.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-dashed border-slate-200">
            <FolderClock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-xs font-bold text-slate-700">No hay reuniones con estos filtros</h4>
            <p className="text-[11px] text-slate-400 mt-1">
              Prueba limpiando los filtros o inicia una nueva reunión desde Inicio.
            </p>
          </div>
        ) : (
          filteredMeetings.map((meeting) => (
            <div
              key={meeting.id}
              onClick={() => {
                onSelectMeetingDetail(meeting);
                soundEffects.playSuccess();
              }}
              className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer flex flex-col gap-2.5"
            >
              {/* Top Course & Week header */}
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-2">
                <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-[#6857E8]">
                    {meeting.courseName}
                  </div>
                  <div className="text-sm font-extrabold text-slate-900 mt-0.5">
                    {meeting.projectName}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900 text-white">
                    Semana {meeting.weekNumber}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>

              {/* Middle row: Date, Time, Duration & Group */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{meeting.startDate} ({meeting.startTime} - {meeting.endTime || 'Fin'})</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Duración: {formatDuration(meeting.durationSeconds)}</span>
                </div>
              </div>

              {/* Participants */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-[11px] text-slate-600 font-medium truncate max-w-[180px]">
                    {meeting.participants.map((p) => p.name).join(', ')}
                  </span>
                </div>

                {/* Counters of notes, agreements, drawings */}
                <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500">
                  {meeting.notes.length > 0 && (
                    <span className="flex items-center gap-0.5 bg-slate-100 px-1.5 py-0.5 rounded">
                      <FileText className="w-3 h-3 text-[#6857E8]" />
                      {meeting.notes.length}
                    </span>
                  )}
                  {meeting.agreements.length > 0 && (
                    <span className="flex items-center gap-0.5 bg-slate-100 px-1.5 py-0.5 rounded">
                      <CheckSquare className="w-3 h-3 text-[#42C99A]" />
                      {meeting.agreements.length}
                    </span>
                  )}
                  {meeting.drawings.length > 0 && (
                    <span className="flex items-center gap-0.5 bg-slate-100 px-1.5 py-0.5 rounded">
                      <PenTool className="w-3 h-3 text-[#4778F5]" />
                      {meeting.drawings.length}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* MODAL DETALLE DE REUNIÓN CON PESTAÑAS: Grabación, Apuntes, Acuerdos, Dibujos */}
      {selectedMeetingDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto flex flex-col gap-3.5 animate-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <div className="text-[10px] font-black uppercase tracking-wider text-[#6857E8] flex items-center gap-1.5">
                  <span>{selectedMeetingDetail.courseName}</span>
                  <span>·</span>
                  <span>Semana {selectedMeetingDetail.weekNumber}</span>
                </div>
                <h2 className="text-base font-extrabold text-slate-900 mt-0.5">
                  {selectedMeetingDetail.projectName}
                </h2>
                <p className="text-[11px] text-slate-500">
                  {selectedMeetingDetail.groupName} · {selectedMeetingDetail.startDate} ({selectedMeetingDetail.startTime} - {selectedMeetingDetail.endTime || 'Fin'})
                </p>
              </div>

              <button
                onClick={() => onSelectMeetingDetail(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Pestañas del Detalle: Grabación, Apuntes, Acuerdos, Dibujos */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-[#F5F6FA] rounded-2xl border border-slate-200 text-xs">
              <button
                onClick={() => setDetailTab('acuerdos')}
                className={`py-1.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1 ${
                  detailTab === 'acuerdos' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                <CheckSquare className="w-3.5 h-3.5 text-[#42C99A]" />
                <span>Acuerdos</span>
              </button>

              <button
                onClick={() => setDetailTab('apuntes')}
                className={`py-1.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1 ${
                  detailTab === 'apuntes' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-[#6857E8]" />
                <span>Apuntes</span>
              </button>

              <button
                onClick={() => setDetailTab('grabacion')}
                className={`py-1.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1 ${
                  detailTab === 'grabacion' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                <Disc className="w-3.5 h-3.5 text-red-500" />
                <span>Audio</span>
              </button>

              <button
                onClick={() => setDetailTab('dibujos')}
                className={`py-1.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1 ${
                  detailTab === 'dibujos' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                <PenTool className="w-3.5 h-3.5 text-[#4778F5]" />
                <span>Dibujos</span>
              </button>
            </div>

            {/* CONTENIDO DE LA PESTAÑA SELECCIONADA */}
            <div className="min-h-[220px]">
              {/* 1. ACUERDOS */}
              {detailTab === 'acuerdos' && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-slate-800 flex items-center justify-between">
                    <span>Acuerdos de la reunión ({selectedMeetingDetail.agreements.length}):</span>
                  </div>

                  {selectedMeetingDetail.agreements.length === 0 ? (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      No se registraron acuerdos en esta sesión.
                    </div>
                  ) : (
                    selectedMeetingDetail.agreements.map((agr) => (
                      <div
                        key={agr.id}
                        className="p-3 rounded-2xl border border-slate-200 bg-[#F5F6FA] flex items-start justify-between gap-2"
                      >
                        <div>
                          <div className="text-xs font-bold text-slate-900 leading-tight">
                            {agr.description}
                          </div>
                          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                            <span>Responsable: <strong className="text-slate-700">{agr.assignee}</strong></span>
                            <span>·</span>
                            <span>Fecha: <strong className="text-slate-700">{agr.deadline}</strong></span>
                          </div>
                        </div>
                        <span
                          className={`text-[9px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                            agr.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {agr.status === 'completed' ? 'Completado' : 'Pendiente'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* 2. APUNTES */}
              {detailTab === 'apuntes' && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-slate-800">
                    Apuntes registrados ({selectedMeetingDetail.notes.length}):
                  </div>

                  {selectedMeetingDetail.notes.length === 0 ? (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      No se registraron notas en esta sesión.
                    </div>
                  ) : (
                    selectedMeetingDetail.notes.map((n) => (
                      <div
                        key={n.id}
                        className="p-3 rounded-2xl border border-slate-200 bg-[#F5F6FA] space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-slate-900">{n.title}</h4>
                          <span className="text-[10px] text-slate-400">{n.createdAt}</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">
                          {n.content}
                        </p>
                        <div className="text-[10px] text-slate-400 pt-1">
                          Autor: {n.author}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* 3. GRABACIÓN */}
              {detailTab === 'grabacion' && (
                <div className="space-y-3">
                  <div className="text-xs font-bold text-slate-800">
                    Registro de Grabación de la Sesión:
                  </div>

                  {selectedMeetingDetail.recording && selectedMeetingDetail.recording.status === 'completed' ? (
                    <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Disc className="w-4 h-4 text-red-500" />
                          <span className="text-xs font-bold">Sesión Grabada (Demostración)</span>
                        </div>
                        <span className="text-xs font-mono font-bold text-[#42C99A]">
                          {formatDuration(selectedMeetingDetail.recording.durationSeconds)}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-800/80 text-[11px] text-slate-300 space-y-0.5">
                        <div>Hora inicio: {selectedMeetingDetail.recording.startTime}</div>
                        <div>Hora fin: {selectedMeetingDetail.recording.endTime}</div>
                        <div className="text-emerald-400 font-semibold">Consentimiento de participantes: Verificado ✓</div>
                      </div>

                      {/* Botón Simular Reproducción de Audio */}
                      <button
                        type="button"
                        onClick={handleTogglePlayback}
                        className="w-full py-2.5 rounded-xl bg-[#6857E8] hover:bg-[#5746db] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
                      >
                        {simulatingPlayback ? <Square className="w-3.5 h-3.5 fill-white" /> : <Play className="w-3.5 h-3.5 fill-white" />}
                        <span>{simulatingPlayback ? 'Detener Reproducción' : 'Simular Reproducción de Audio'}</span>
                      </button>

                      {simulatingPlayback && (
                        <div className="flex items-center justify-center gap-1 pt-1 text-xs text-[#42C99A] font-bold">
                          <span className="w-1.5 h-4 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.1s]" />
                          <span className="w-1.5 h-6 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.2s]" />
                          <span className="w-1.5 h-8 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.3s]" />
                          <span className="w-1.5 h-5 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.15s]" />
                          <span className="text-[11px] ml-1">Simulando audio de la reunión...</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      No se inició grabación durante esta reunión.
                    </div>
                  )}

                  {/* Transmisiones walkie asociadas */}
                  {selectedMeetingDetail.walkieTransmissions.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-100">
                      <span className="text-[11px] font-bold text-slate-700 block mb-1.5">
                        Transmisiones Walkie-Talkie ({selectedMeetingDetail.walkieTransmissions.length}):
                      </span>
                      <div className="space-y-1.5">
                        {selectedMeetingDetail.walkieTransmissions.map((t) => (
                          <div key={t.id} className="p-2 rounded-xl bg-[#F5F6FA] text-[11px] text-slate-700 flex justify-between">
                            <span>Para: <strong>{t.recipientName}</strong> · {t.summary}</span>
                            <span className="text-slate-400 font-mono">{t.durationSeconds}s</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 4. DIBUJOS */}
              {detailTab === 'dibujos' && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-slate-800">
                    Bocetos y dibujos de la pizarra ({selectedMeetingDetail.drawings.length}):
                  </div>

                  {selectedMeetingDetail.drawings.length === 0 ? (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      No se guardaron dibujos de pizarra en esta sesión.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {selectedMeetingDetail.drawings.map((draw) => (
                        <div key={draw.id} className="rounded-2xl border border-slate-200 overflow-hidden bg-white shadow-xs">
                          <div className="h-36 bg-slate-900 flex items-center justify-center p-2">
                            <img src={draw.dataUrl} alt={draw.title} className="max-h-full object-contain rounded-lg" />
                          </div>
                          <div className="p-2.5">
                            <h5 className="text-xs font-bold text-slate-900">{draw.title}</h5>
                            <span className="text-[10px] text-slate-400">{draw.createdAt}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer with ZIP download */}
            <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => handleDownloadZip(selectedMeetingDetail)}
                disabled={downloadingZip}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{downloadingZip ? 'Generando ZIP...' : 'Descargar Paquete ZIP'}</span>
              </button>

              <button
                type="button"
                onClick={() => onSelectMeetingDetail(null)}
                className="px-4 py-2 rounded-xl bg-[#111827] text-white text-xs font-bold hover:bg-slate-800"
              >
                Cerrar Detalle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
