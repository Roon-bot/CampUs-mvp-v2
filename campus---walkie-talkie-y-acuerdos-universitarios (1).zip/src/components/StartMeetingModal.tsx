import React, { useState } from 'react';
import { X, Play, Users, Calendar, Clock, BookOpen, Layers, Check } from 'lucide-react';
import { AcademicSettings, Participant, MeetingSession } from '../types/campus';
import { calculateAcademicWeek, formatTime } from '../utils/academic';
import { DEMO_PARTICIPANTS } from '../config/initialData';
import { soundEffects } from '../utils/sound';

interface StartMeetingModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AcademicSettings;
  onStartMeeting: (meetingData: Omit<MeetingSession, 'id' | 'walkieTransmissions' | 'notes' | 'agreements' | 'drawings' | 'status' | 'durationSeconds'>) => void;
}

export const StartMeetingModal: React.FC<StartMeetingModalProps> = ({
  isOpen,
  onClose,
  settings,
  onStartMeeting,
}) => {
  if (!isOpen) return null;

  const weekInfo = calculateAcademicWeek(settings.startDate, settings.totalWeeks);
  const now = new Date();
  const todayStr = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
  const currentTimeStr = formatTime(now);

  const [selectedCourseId, setSelectedCourseId] = useState<string>(settings.courses[0]?.id || '');
  const selectedCourse = settings.courses.find((c) => c.id === selectedCourseId) || settings.courses[0];

  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    selectedCourse?.projects[0]?.id || 'proj-general'
  );
  const [groupName, setGroupName] = useState<string>('Equipo Principal · Trabajo Final');
  const [selectedParticipantIds, setSelectedParticipantIds] = useState<string[]>([
    'carlos',
    'diego',
    'camila',
    'luis',
  ]);

  const handleCourseChange = (courseId: string) => {
    setSelectedCourseId(courseId);
    const course = settings.courses.find((c) => c.id === courseId);
    if (course && course.projects.length > 0) {
      setSelectedProjectId(course.projects[0].id);
    } else {
      setSelectedProjectId('proj-general');
    }
  };

  const toggleParticipant = (id: string) => {
    if (id === 'carlos') return; // Carlos is mandatory (user)
    setSelectedParticipantIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourse) return;

    const selectedProj = selectedCourse.projects.find((p) => p.id === selectedProjectId);
    const activeParticipants = DEMO_PARTICIPANTS.filter((p) =>
      selectedParticipantIds.includes(p.id)
    );

    onStartMeeting({
      courseId: selectedCourse.id,
      courseName: selectedCourse.name,
      projectId: selectedProjectId,
      projectName: selectedProj ? selectedProj.name : 'Proyecto General',
      groupName: groupName.trim() || 'Equipo de Estudio',
      participants: activeParticipants,
      startDate: todayStr,
      startTime: currentTimeStr,
      weekNumber: weekInfo.weekNumber || 1,
    });

    soundEffects.playSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-[#6857E8]/10 text-[#6857E8] flex items-center justify-center">
              <Play className="w-4 h-4 fill-[#6857E8]" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 leading-tight">
                Iniciar Nueva Reunión
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Vincular sesión a curso y semana académica
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Autocompleted metadata info pills */}
          <div className="grid grid-cols-3 gap-2 p-2.5 rounded-2xl bg-indigo-50/60 border border-indigo-100 text-[11px]">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Semana</span>
              <span className="font-bold text-[#6857E8]">{weekInfo.label}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Fecha</span>
              <span className="font-bold text-slate-800">{todayStr}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Hora inicio</span>
              <span className="font-bold text-slate-800">{currentTimeStr}</span>
            </div>
          </div>

          {/* 1. Curso */}
          <div>
            <label className="text-xs font-bold text-slate-800 block mb-1">
              Curso universitario:
            </label>
            <select
              value={selectedCourseId}
              onChange={(e) => handleCourseChange(e.target.value)}
              className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/30"
              required
            >
              {settings.courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name} ({course.code})
                </option>
              ))}
            </select>
          </div>

          {/* 2. Proyecto */}
          <div>
            <label className="text-xs font-bold text-slate-800 block mb-1">
              Proyecto asociado:
            </label>
            {selectedCourse?.projects && selectedCourse.projects.length > 0 ? (
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/30"
                required
              >
                {selectedCourse.projects.map((proj) => (
                  <option key={proj.id} value={proj.id}>
                    {proj.name}
                  </option>
                ))}
              </select>
            ) : (
              <input
                type="text"
                placeholder="Nombre del proyecto..."
                value="Proyecto General"
                readOnly
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-100 text-slate-500"
              />
            )}
          </div>

          {/* 3. Nombre del grupo */}
          <div>
            <label className="text-xs font-bold text-slate-800 block mb-1">
              Nombre del grupo:
            </label>
            <input
              type="text"
              placeholder="Ej. Equipo Alpha · Sección B"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              className="w-full text-xs font-medium px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/30"
              required
            />
          </div>

          {/* 4. Participantes de demostración */}
          <div>
            <label className="text-xs font-bold text-slate-800 block mb-1.5 flex items-center justify-between">
              <span>Participantes de demostración:</span>
              <span className="text-[10px] font-normal text-slate-400">
                {selectedParticipantIds.length} seleccionados
              </span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DEMO_PARTICIPANTS.map((p) => {
                const isSelected = selectedParticipantIds.includes(p.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => toggleParticipant(p.id)}
                    className={`p-2 rounded-xl border text-left flex items-center justify-between transition-all ${
                      isSelected
                        ? 'border-[#6857E8] bg-[#6857E8]/5 ring-1 ring-[#6857E8]/20'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-full bg-gradient-to-tr ${p.avatarBg} text-white font-bold text-[10px] flex items-center justify-center shrink-0`}>
                        {p.initials}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900 truncate">
                          {p.name}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {p.role}
                        </div>
                      </div>
                    </div>

                    <div className={`w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                      isSelected ? 'bg-[#6857E8] border-[#6857E8] text-white' : 'border-slate-300 bg-white'
                    }`}>
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:text-slate-800 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-2xl bg-[#111827] hover:bg-slate-800 text-white font-extrabold text-xs shadow-md shadow-slate-900/20 transition-all active:scale-95 flex items-center gap-2"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Comenzar Reunión</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
