import React, { useState, useRef, useEffect } from 'react';
import { 
  Users, 
  FolderGit2, 
  User, 
  Mic, 
  Radio, 
  Volume2, 
  Clock, 
  CheckCircle2, 
  Play, 
  Square, 
  Send, 
  Info, 
  MessageCircle,
  ExternalLink,
  ChevronRight,
  Flame,
  Wifi,
  Sparkles
} from 'lucide-react';
import { RecipientType, Transmission, Member, Group } from '../types';
import { 
  DEMO_MEMBERS, 
  DEMO_GROUPS, 
  buildWhatsAppLink, 
  WHATSAPP_NUMBER, 
  WHATSAPP_MESSAGE,
  VALUE_PROPOSITION,
  VALUE_SLOGAN,
  STRATEGIC_PILLARS
} from '../config/constants';
import { soundEffects } from '../utils/sound';

interface WalkieTalkieScreenProps {
  currentGroup: Group;
  transmissions: Transmission[];
  onAddTransmission: (newTx: Transmission) => void;
  onOpenWhatsAppModal: () => void;
}

export const WalkieTalkieScreen: React.FC<WalkieTalkieScreenProps> = ({
  currentGroup,
  transmissions,
  onAddTransmission,
  onOpenWhatsAppModal,
}) => {
  // Recipient selection mode: 'all' | 'group' | 'person'
  const [recipientType, setRecipientType] = useState<RecipientType>('all');
  const [selectedGroup, setSelectedGroup] = useState<Group>(currentGroup);
  const [selectedPerson, setSelectedPerson] = useState<Member>(DEMO_MEMBERS[0]); // Diego by default

  // Walkie-Talkie transmission state
  const [isTransmitting, setIsTransmitting] = useState<boolean>(false);
  const [transmissionSeconds, setTransmissionSeconds] = useState<number>(0);
  const [recentSentNotification, setRecentSentNotification] = useState<string | null>(null);

  // Playback simulator state for historical items
  const [playingTxId, setPlayingTxId] = useState<string | null>(null);

  // Refs for timer and pointer handling
  const timerRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const transmitActiveRef = useRef<boolean>(false);

  // Synchronize selected group if header changed it
  useEffect(() => {
    setSelectedGroup(currentGroup);
  }, [currentGroup]);

  // Clean up timers on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Determine active recipient label for UI
  const getActiveRecipientLabel = (): string => {
    if (recipientType === 'all') {
      return 'Todos (Equipo Completo)';
    }
    if (recipientType === 'group') {
      return `Grupo: ${selectedGroup.name}`;
    }
    return `Persona: ${selectedPerson.name}`;
  };

  const getRecipientSummaryName = (): string => {
    if (recipientType === 'all') return 'Todos';
    if (recipientType === 'group') return selectedGroup.name;
    return selectedPerson.name;
  };

  // Start PTT transmission (on pointer down)
  const handlePointerDown = (e: React.PointerEvent) => {
    // Prevent context menu or mouse drag issues
    e.preventDefault();
    if (transmitActiveRef.current) return;

    transmitActiveRef.current = true;
    setIsTransmitting(true);
    setTransmissionSeconds(0);
    startTimeRef.current = Date.now();

    soundEffects.playPttStart();

    // Start timer for duration
    timerRef.current = window.setInterval(() => {
      setTransmissionSeconds((prev) => prev + 1);
    }, 1000);
  };

  // End PTT transmission (on pointer up, cancel, leave)
  const handlePointerEnd = (e: React.PointerEvent) => {
    e.preventDefault();
    if (!transmitActiveRef.current) return;

    transmitActiveRef.current = false;
    setIsTransmitting(false);

    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    const elapsedMs = Date.now() - startTimeRef.current;
    const finalSeconds = Math.max(1, Math.round(elapsedMs / 1000));

    soundEffects.playPttEnd();

    // Generate formatted time
    const now = new Date();
    const formattedHours = now.getHours().toString().padStart(2, '0');
    const formattedMinutes = now.getMinutes().toString().padStart(2, '0');
    const timeString = `${formattedHours}:${formattedMinutes}`;

    const recipientLabel = getActiveRecipientLabel();
    const recipientName = getRecipientSummaryName();

    const summaryText = recipientType === 'all' 
      ? 'Mensaje para todos' 
      : recipientType === 'group' 
        ? `Mensaje al grupo ${selectedGroup.name}`
        : `Mensaje para ${selectedPerson.name}`;

    const newTransmission: Transmission = {
      id: `tx-${Date.now()}`,
      recipientType,
      recipientName,
      targetLabel: recipientLabel,
      timestamp: timeString,
      timeAgo: 'Hace un instante',
      durationSeconds: finalSeconds,
      summary: `${summaryText} (Simulado)`,
      detail: `[Maqueta MVP] Demostración simulada de indicación (${finalSeconds}s) para ${recipientName}.`,
      channel: recipientType === 'group' ? selectedGroup.name : 'Proyecto de investigación'
    };

    onAddTransmission(newTransmission);

    // Show visual confirmation toast
    setRecentSentNotification(`Simulación completada: Demostración para ${recipientName} (${finalSeconds}s)`);
    setTimeout(() => {
      setRecentSentNotification(null);
    }, 3800);
  };

  // Simulate playback of an existing audio transmission
  const handleTogglePlay = (tx: Transmission) => {
    if (playingTxId === tx.id) {
      setPlayingTxId(null);
    } else {
      setPlayingTxId(tx.id);
      soundEffects.playPlaybackChirp();
      // Auto-stop after duration
      setTimeout(() => {
        setPlayingTxId((current) => (current === tx.id ? null : current));
      }, (tx.durationSeconds || 5) * 1000);
    }
  };

  return (
    <div className="flex flex-col gap-4 pb-24 px-4 pt-3 select-none">
      {/* Dynamic Status / Value Proposition Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/50 rounded-2xl p-3 shadow-md relative overflow-hidden">
        <div className="absolute -right-4 -bottom-4 w-28 h-28 bg-[#6558E8]/15 rounded-full blur-xl pointer-events-none" />
        
        <div className="flex items-start justify-between gap-2 relative z-10">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#42C99A] animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#42C99A]">
                Voz + Acuerdos por Curso y Semana
              </span>
              <span className="text-[9px] bg-[#6558E8]/30 text-[#857BF2] px-1.5 py-0.2 rounded border border-[#6558E8]/40 font-bold">
                Meta: &lt; 1 min
              </span>
            </div>
            <p className="text-xs text-white font-bold tracking-tight">
              «{VALUE_SLOGAN}»
            </p>
            <p className="text-[11px] text-slate-300 font-medium leading-relaxed">
              Encuentra cada decisión y acuerdo de tu equipo en menos de un minuto.
            </p>
          </div>

          <button
            onClick={onOpenWhatsAppModal}
            className="shrink-0 flex items-center gap-1 bg-[#42C99A]/15 hover:bg-[#42C99A]/25 border border-[#42C99A]/40 text-[#42C99A] text-[11px] font-bold px-2.5 py-1.5 rounded-xl transition-all active:scale-95 shadow-sm"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Conocer</span>
          </button>
        </div>
      </div>

      {/* SELECTOR DE DESTINATARIO */}
      <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-2.5">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-[#6558E8]" />
            1. Selecciona a quién hablar
          </label>
          <span className="text-[11px] text-[#6558E8] font-bold bg-[#6558E8]/10 px-2 py-0.5 rounded-full">
            {recipientType === 'all' ? '4 miembros' : recipientType === 'group' ? 'Por grupo' : 'Individual'}
          </span>
        </div>

        {/* 3 Main Selection Tabs: TODOS | GRUPO | PERSONA */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#F4F6FA] rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setRecipientType('all');
              soundEffects.playSuccess();
            }}
            className={`py-2 px-1 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 ${
              recipientType === 'all'
                ? 'bg-[#10172A] text-white shadow-sm shadow-slate-900/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>TODOS</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setRecipientType('group');
              soundEffects.playSuccess();
            }}
            className={`py-2 px-1 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 ${
              recipientType === 'group'
                ? 'bg-[#10172A] text-white shadow-sm shadow-slate-900/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <FolderGit2 className="w-4 h-4" />
            <span>GRUPO</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setRecipientType('person');
              soundEffects.playSuccess();
            }}
            className={`py-2 px-1 rounded-lg text-xs font-bold transition-all flex flex-col items-center gap-1 ${
              recipientType === 'person'
                ? 'bg-[#10172A] text-white shadow-sm shadow-slate-900/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <User className="w-4 h-4" />
            <span>PERSONA</span>
          </button>
        </div>

        {/* Dynamic Context Options based on Tab */}
        <div className="mt-3 pt-3 border-t border-slate-100">
          {/* OPTION 1: TODOS */}
          {recipientType === 'all' && (
            <div className="p-3 bg-gradient-to-r from-indigo-50/70 to-blue-50/70 border border-indigo-100 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#6558E8] to-[#4A75F5] flex items-center justify-center text-white shadow-sm">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">
                    Transmisión general abierta
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Todos los integrantes del equipo ({DEMO_MEMBERS.length} estudiantes)
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                En vivo
              </span>
            </div>
          )}

          {/* OPTION 2: GRUPO */}
          {recipientType === 'group' && (
            <div className="space-y-2">
              <p className="text-[11px] text-slate-500 font-medium">Elige el grupo destinatario:</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {DEMO_GROUPS.map((grp) => {
                  const isSelected = selectedGroup.id === grp.id;
                  return (
                    <button
                      key={grp.id}
                      type="button"
                      onClick={() => {
                        setSelectedGroup(grp);
                        soundEffects.playSuccess();
                      }}
                      className={`text-left p-2.5 rounded-xl border transition-all flex items-start justify-between ${
                        isSelected
                          ? 'border-[#6558E8] bg-[#6558E8]/10 ring-2 ring-[#6558E8]/20 shadow-sm'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs text-slate-800 flex items-center gap-1">
                          {grp.name}
                        </div>
                        <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                          {grp.description}
                        </div>
                        <div className="text-[10px] font-semibold text-[#6558E8] mt-1">
                          {grp.membersCount} integrantes
                        </div>
                      </div>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-[#6558E8] shrink-0 ml-1" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* OPTION 3: PERSONA */}
          {recipientType === 'person' && (
            <div className="space-y-2">
              <p className="text-[11px] text-slate-500 font-medium">Elige el compañero destinatario:</p>
              <div className="grid grid-cols-3 gap-2">
                {DEMO_MEMBERS.filter((m) => m.id !== 'carlos').map((member) => {
                  const isSelected = selectedPerson.id === member.id;
                  return (
                    <button
                      key={member.id}
                      type="button"
                      onClick={() => {
                        setSelectedPerson(member);
                        soundEffects.playSuccess();
                      }}
                      className={`p-2 rounded-xl border text-center transition-all relative flex flex-col items-center ${
                        isSelected
                          ? 'border-[#4A75F5] bg-[#4A75F5]/10 ring-2 ring-[#4A75F5]/25 shadow-sm'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${member.avatarBg} text-white flex items-center justify-center font-bold text-xs shadow-sm mb-1`}>
                        {member.initials}
                      </div>
                      <div className="text-xs font-bold text-slate-800 leading-tight">
                        {member.name}
                      </div>
                      <span className={`text-[9px] font-medium mt-0.5 px-1 rounded ${
                        member.status === 'online' 
                          ? 'text-emerald-700 bg-emerald-50' 
                          : 'text-amber-700 bg-amber-50'
                      }`}>
                        {member.status === 'online' ? 'En línea' : 'En clase'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* CENTRAL WALKIE-TALKIE TRANSMISSION STATION */}
      <div className="relative bg-gradient-to-b from-[#10172A] to-[#18233C] rounded-3xl p-5 text-white shadow-xl border border-slate-800 overflow-hidden text-center flex flex-col items-center justify-center min-h-[300px]">
        {/* Subtle background radar pattern */}
        <div className="absolute inset-0 opacity-10 pointer-events-none flex items-center justify-center">
          <div className="w-72 h-72 rounded-full border border-white/30" />
          <div className="absolute w-52 h-52 rounded-full border border-white/20" />
          <div className="absolute w-36 h-36 rounded-full border border-white/20" />
        </div>

        {/* Maqueta MVP Badge */}
        <div className="z-10 inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-[10px] font-extrabold text-amber-300 uppercase tracking-wider mb-2">
          <span>Maqueta Interactiva · MVP</span>
        </div>

        {/* Channel Indicator Badge */}
        <div className="z-10 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-xs font-medium text-slate-300 mb-3 shadow-inner">
          <span className={`w-2 h-2 rounded-full ${isTransmitting ? 'bg-red-500 animate-ping' : 'bg-[#42C99A]'}`} />
          <span className="text-slate-400 font-semibold">Canal:</span>
          <span className="text-white font-bold truncate max-w-[200px]">
            {getActiveRecipientLabel()}
          </span>
        </div>

        {/* Dynamic Transmission Status Overlay */}
        <div className="z-10 h-10 flex flex-col items-center justify-center mb-2">
          {isTransmitting ? (
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-2 text-red-400 font-extrabold text-sm tracking-wide animate-pulse">
                <span className="inline-block w-2.5 h-2.5 rounded-full bg-red-500" />
                SIMULANDO TRANSMISIÓN... 00:{transmissionSeconds.toString().padStart(2, '0')}
              </div>
              <p className="text-[11px] text-slate-300 font-medium">
                Demostración con: <span className="text-[#42C99A] font-bold">{getRecipientSummaryName()}</span>
              </p>
            </div>
          ) : (
            <p className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
              <span>Simulación de indicación de voz (Demostración)</span>
            </p>
          )}
        </div>

        {/* BIG CENTRAL WALKIE-TALKIE BUTTON */}
        <div className="relative z-10 my-2 touch-none">
          {/* Animated concentric pulsing waves when transmitting */}
          {isTransmitting && (
            <>
              <div className="absolute -inset-6 rounded-full bg-[#6558E8]/30 blur-md animate-ping" />
              <div className="absolute -inset-10 rounded-full border-2 border-[#4A75F5]/40 animate-pulse" />
              <div className="absolute -inset-14 rounded-full border border-[#42C99A]/30 animate-pulse" />
            </>
          )}

          {/* Audio frequency visualizer bars above button when transmitting */}
          {isTransmitting && (
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 flex items-center gap-1 h-8 z-20">
              <span className="w-1.5 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.1s] h-5" />
              <span className="w-1.5 bg-[#4A75F5] rounded-full animate-bounce [animation-delay:0.3s] h-8" />
              <span className="w-1.5 bg-[#6558E8] rounded-full animate-bounce [animation-delay:0.2s] h-6" />
              <span className="w-1.5 bg-[#42C99A] rounded-full animate-bounce [animation-delay:0.4s] h-7" />
              <span className="w-1.5 bg-[#4A75F5] rounded-full animate-bounce [animation-delay:0.15s] h-4" />
            </div>
          )}

          {/* Main button with robust pointer event handlers */}
          <button
            type="button"
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerEnd}
            onPointerLeave={handlePointerEnd}
            onPointerCancel={handlePointerEnd}
            onContextMenu={(e) => e.preventDefault()}
            className={`w-36 h-36 rounded-full flex flex-col items-center justify-center transition-all duration-150 select-none cursor-pointer focus:outline-none shadow-2xl relative active:scale-95 ${
              isTransmitting
                ? 'bg-gradient-to-tr from-red-600 via-rose-600 to-orange-500 ring-8 ring-red-500/30 scale-105'
                : 'bg-gradient-to-tr from-[#6558E8] via-[#4A75F5] to-[#42C99A] ring-8 ring-[#6558E8]/20 hover:scale-[1.02]'
            }`}
            aria-label="Botón de Walkie Talkie"
          >
            {/* Inner glossy disc */}
            <div className="w-[124px] h-[124px] rounded-full bg-[#10172A]/85 backdrop-blur-sm flex flex-col items-center justify-center p-2 text-center border border-white/20">
              <Mic className={`w-8 h-8 mb-1 transition-transform ${isTransmitting ? 'text-red-400 scale-110 animate-pulse' : 'text-white'}`} />
              <span className="text-[11px] font-bold tracking-tight uppercase leading-snug px-1 text-slate-100">
                {isTransmitting ? 'Simulando transmisión...' : 'Mantén presionado para hablar'}
              </span>
              <span className="text-[9px] font-semibold text-[#42C99A] mt-0.5 uppercase tracking-wide">
                (Maqueta)
              </span>
            </div>
          </button>
        </div>

        {/* Safety micro-copy */}
        <p className="z-10 text-[11px] text-slate-400 mt-3 font-medium">
          {isTransmitting ? 'Suelta el botón para finalizar la simulación' : 'Maqueta: Simula la interacción sin micrófono ni transmisión real'}
        </p>

        {/* Success toast notification */}
        {recentSentNotification && (
          <div className="absolute bottom-3 left-4 right-4 z-30 bg-[#42C99A] text-slate-950 font-bold text-xs py-2 px-3 rounded-xl shadow-lg flex items-center justify-center gap-1.5 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span className="truncate">{recentSentNotification}</span>
          </div>
        )}
      </div>

      {/* AVISO DE MAQUETA MVP ACADÉMICA */}
      <div className="bg-amber-50/90 border border-amber-200 rounded-2xl p-3 flex items-start gap-2.5 shadow-xs">
        <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
          MVP
        </div>
        <div className="flex-1">
          <div className="text-[10px] font-extrabold uppercase tracking-wider text-amber-900">
            Maqueta Conceptual
          </div>
          <p className="text-[11px] text-slate-700 font-medium mt-0.5 leading-relaxed">
            Este walkie-talkie es un prototipo interactivo para validar la experiencia de uso y el flujo con los acuerdos por curso y semana. En esta etapa no se encuentra en funcionamiento real ni requiere audio.
          </p>
        </div>
      </div>

      {/* NUEVA PROMESA DE VALOR CARD WITH WHATSAPP ACTION BUTTON */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#6558E8]/20 to-[#42C99A]/20 text-[#6558E8] border border-[#6558E8]/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-[#6558E8]" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#6558E8]">
                Promesa CampUs
              </span>
              <span className="text-[10px] font-bold bg-[#42C99A]/15 text-[#107050] px-2 py-0.5 rounded-full">
                Meta: &lt; 1 min
              </span>
            </div>
            <p className="text-xs text-slate-800 font-semibold mt-1 leading-relaxed">
              "{VALUE_PROPOSITION}"
            </p>
            <p className="text-[11px] text-[#6558E8] font-bold mt-1.5 italic">
              «{VALUE_SLOGAN}»
            </p>
          </div>
        </div>

        {/* 3 Strategic Pillars Breakdown */}
        <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2">
          <div className="p-2.5 rounded-xl bg-[#F4F6FA] border border-slate-200/70">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block">
              1. Persona
            </span>
            <span className="text-xs font-semibold text-slate-800 mt-0.5 block leading-tight">
              {STRATEGIC_PILLARS.persona}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#F4F6FA] border border-slate-200/70">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block">
              2. Acción
            </span>
            <span className="text-xs font-semibold text-slate-800 mt-0.5 block leading-tight">
              {STRATEGIC_PILLARS.action}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200/70">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 block">
              3. Beneficio Medible
            </span>
            <span className="text-xs font-bold text-emerald-900 mt-0.5 block leading-tight">
              {STRATEGIC_PILLARS.measurableBenefit}
            </span>
          </div>
        </div>

        {/* Dedicated WhatsApp Button required by spec */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <span className="text-[11px] text-slate-500">¿Deseas conocer más sobre CampUs o coordinar una prueba piloto?</span>
          <a
            href={buildWhatsAppLink(WHATSAPP_NUMBER, WHATSAPP_MESSAGE)}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs shadow-md shadow-emerald-500/20 transition-all active:scale-95"
          >
            <MessageCircle className="w-4 h-4 fill-white text-[#25D366]" />
            <span>Quiero conocer CampUs</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-75" />
          </a>
        </div>
      </div>

      {/* TRANSMISSION HISTORY */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <h3 className="font-bold text-slate-800 text-sm">Historial de demostraciones (Simuladas)</h3>
          </div>
          <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
            {transmissions.length} simulaciones
          </span>
        </div>

        <div className="space-y-2.5">
          {transmissions.map((tx) => {
            const isPlaying = playingTxId === tx.id;
            return (
              <div
                key={tx.id}
                className={`p-3 rounded-xl border transition-all ${
                  isPlaying 
                    ? 'border-[#6558E8] bg-[#6558E8]/5 ring-1 ring-[#6558E8]/30' 
                    : 'border-slate-150 bg-[#F4F6FA]/60 hover:bg-[#F4F6FA]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* Badge icon depending on recipient */}
                    <div className="w-7 h-7 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600 shadow-2xs">
                      {tx.recipientType === 'all' ? (
                        <Users className="w-3.5 h-3.5 text-[#6558E8]" />
                      ) : tx.recipientType === 'group' ? (
                        <FolderGit2 className="w-3.5 h-3.5 text-[#4A75F5]" />
                      ) : (
                        <User className="w-3.5 h-3.5 text-[#42C99A]" />
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900">
                        {tx.summary}
                      </div>
                      <div className="text-[10px] text-slate-500 font-medium">
                        Destinatario: <span className="font-semibold text-slate-700">{tx.recipientName}</span> · {tx.timeAgo} ({tx.timestamp})
                      </div>
                    </div>
                  </div>

                  {/* Play audio simulation button */}
                  <button
                    type="button"
                    onClick={() => handleTogglePlay(tx)}
                    className={`shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      isPlaying
                        ? 'bg-[#6558E8] text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                    title={isPlaying ? "Detener" : "Reproducir transmisión simulada"}
                  >
                    {isPlaying ? (
                      <>
                        <Square className="w-3 h-3 fill-white" />
                        <span className="text-[10px]">Ondas...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3 h-3 fill-slate-700 text-slate-700" />
                        <span className="text-[10px]">{tx.durationSeconds}s</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Animated voice wave simulator if playing */}
                {isPlaying && (
                  <div className="mt-2 pt-2 border-t border-[#6558E8]/20 flex items-center gap-1.5 text-xs text-[#6558E8] font-medium">
                    <span className="w-1 h-3 bg-[#6558E8] rounded-full animate-bounce [animation-delay:0.1s]" />
                    <span className="w-1 h-4 bg-[#6558E8] rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1 h-6 bg-[#6558E8] rounded-full animate-bounce [animation-delay:0.3s]" />
                    <span className="w-1 h-3 bg-[#6558E8] rounded-full animate-bounce [animation-delay:0.15s]" />
                    <span className="w-1 h-5 bg-[#6558E8] rounded-full animate-bounce [animation-delay:0.25s]" />
                    <span className="text-[10px] ml-1 text-slate-600 italic">
                      {tx.detail || "Reproduciendo indicación de voz..."}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
