import React from 'react';
import { 
  Play, 
  Calendar, 
  FolderKanban, 
  CheckSquare, 
  Clock, 
  BookOpen, 
  Users, 
  ArrowRight, 
  Sparkles,
  Layers,
  ChevronRight,
  Radio,
  MessageCircle
} from 'lucide-react';
import { AcademicSettings, MeetingSession, AgreementItem, NavigationTab } from '../types/campus';
import { calculateAcademicWeek, formatLongDate, formatDuration } from '../utils/academic';
import { EXACT_VALUE_PROMISE } from '../config/initialData';
import { buildWhatsAppLink } from '../config/constants';
import { soundEffects } from '../utils/sound';

interface HomeViewProps {
  settings: AcademicSettings;
  meetings: MeetingSession[];
  agreements: AgreementItem[];
  activeMeeting: MeetingSession | null;
  onOpenStartMeetingModal: () => void;
  onNavigate: (tab: NavigationTab) => void;
  onSelectMeetingDetail: (meeting: MeetingSession) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  settings,
  meetings,
  agreements,
  activeMeeting,
  onOpenStartMeetingModal,
  onNavigate,
  onSelectMeetingDetail,
}) => {
  const weekInfo = calculateAcademicWeek(settings.startDate, settings.totalWeeks);
  const pendingAgreements = agreements.filter((a) => a.status === 'pending');
  const recentMeetings = [...meetings].slice(0, 3);

  // Total projects count across all courses
  const totalProjects = settings.courses.reduce((acc, c) => acc + (c.projects?.length || 0), 0);

  return (
    <div className="flex flex-col gap-4 pb-28 px-4 pt-3 select-none">
      {/* 1. Saludo Personalizado y Fecha Actual */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80 flex items-center justify-between gap-3">
        <div>
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            {formatLongDate(new Date())}
          </div>
          <h1 className="text-xl font-extrabold text-[#111827] mt-0.5 tracking-tight">
            Hola, Carlos 👋
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Coordinador · Trabajos grupales universitarios
          </p>
        </div>

        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#6857E8] to-[#4778F5] text-white flex items-center justify-center font-black text-sm shadow-md shadow-[#6857E8]/20 shrink-0">
          CM
        </div>
      </div>

      {/* 2. Banner de Promesa de Valor Oficial */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/60 rounded-3xl p-4 sm:p-5 text-white shadow-md relative overflow-hidden flex flex-col gap-3">
        <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-[#6857E8]/20 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 space-y-1.5">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#42C99A]" />
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#42C99A]">
              Promesa CampUs
            </span>
          </div>
          <p className="text-xs text-slate-100 font-medium leading-relaxed italic">
            "{EXACT_VALUE_PROMISE}"
          </p>
        </div>

        {/* Botón único de contacto WhatsApp Business en la página de inicio */}
        <div className="relative z-10 pt-2 border-t border-indigo-900/70 flex justify-start">
          <a
            href={buildWhatsAppLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-[#42C99A] to-emerald-500 hover:from-emerald-400 hover:to-[#42C99A] text-slate-950 font-extrabold text-xs shadow-md shadow-emerald-500/20 transition-all active:scale-95 group"
          >
            <MessageCircle className="w-4 h-4 text-slate-950 fill-slate-950/20" />
            <span>Conoce más sobre CampUs</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-950 group-hover:translate-x-0.5 transition-transform" />
          </a>
        </div>
      </div>

      {/* 3. BOTÓN PRINCIPAL DESTACADO: INICIAR REUNIÓN */}
      <div>
        {activeMeeting ? (
          <div className="p-4 rounded-3xl bg-gradient-to-r from-[#6857E8] to-[#4778F5] text-white shadow-lg shadow-[#6857E8]/30 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 text-[#42C99A]">
                <span className="w-2.5 h-2.5 rounded-full bg-[#42C99A] animate-ping" />
                Reunión en progreso
              </span>
              <span className="text-[10px] bg-black/30 px-2 py-0.5 rounded-full font-bold">
                {activeMeeting.weekNumber ? `Semana ${activeMeeting.weekNumber}` : 'Activa'}
              </span>
            </div>
            <div>
              <div className="text-sm font-bold text-white">{activeMeeting.courseName}</div>
              <div className="text-xs text-slate-200 mt-0.5">{activeMeeting.projectName} · {activeMeeting.groupName}</div>
            </div>
            <button
              onClick={() => {
                onNavigate('comunicacion');
                soundEffects.playSuccess();
              }}
              className="w-full py-2.5 rounded-2xl bg-white text-slate-950 font-bold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Radio className="w-4 h-4 text-[#6857E8]" />
              <span>Abrir Controles de la Reunión (Voz, Apuntes, Pizarra)</span>
            </button>
          </div>
        ) : (
          <button
            onClick={() => {
              onOpenStartMeetingModal();
              soundEffects.playSuccess();
            }}
            className="w-full py-4 px-5 rounded-3xl bg-gradient-to-r from-[#111827] via-slate-900 to-[#111827] hover:from-slate-900 hover:to-slate-800 text-white font-extrabold text-sm shadow-xl shadow-slate-900/20 border border-slate-700/80 transition-all active:scale-[0.98] flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#42C99A] text-slate-950 flex items-center justify-center font-bold shadow-md shadow-emerald-500/25 group-hover:scale-105 transition-transform">
                <Play className="w-5 h-5 fill-slate-950 ml-0.5" />
              </div>
              <div className="text-left">
                <span className="block text-base tracking-tight font-black text-white">
                  INICIAR REUNIÓN
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  {weekInfo.label} · Registrar acuerdos, voz y apuntes
                </span>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-[#42C99A] group-hover:translate-x-1 transition-transform" />
          </button>
        )}
      </div>

      {/* 4. Semana Académica y Progreso del Ciclo */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-[#6857E8]" />
            Semana Académica
          </span>
          <span className="text-xs font-bold text-[#6857E8] bg-[#6857E8]/10 px-2 py-0.5 rounded-full">
            {weekInfo.label} de {settings.totalWeeks}
          </span>
        </div>

        {/* Progress bar */}
        <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden my-2">
          <div
            className="h-full bg-gradient-to-r from-[#6857E8] to-[#42C99A] rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, Math.max(5, (weekInfo.weekNumber / settings.totalWeeks) * 100))}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1 font-medium">
          <span>Inicio: {settings.startDate}</span>
          <span>{weekInfo.daysElapsed >= 0 ? `${weekInfo.daysElapsed} días transcurridos` : 'Por iniciar'}</span>
        </div>
      </div>

      {/* 5. Métricas de Cursos y Proyectos Activos */}
      <div className="grid grid-cols-2 gap-2.5">
        <div
          onClick={() => onNavigate('configuracion')}
          className="bg-white p-3.5 rounded-3xl border border-slate-200/80 shadow-xs cursor-pointer hover:border-slate-300 transition-all active:scale-98"
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Cursos
            </span>
            <div className="w-7 h-7 rounded-xl bg-indigo-50 text-[#6857E8] flex items-center justify-center">
              <BookOpen className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-[#111827]">
            {settings.courses.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {totalProjects} proyectos vinculados
          </div>
        </div>

        <div
          onClick={() => onNavigate('acuerdos')}
          className="bg-white p-3.5 rounded-3xl border border-slate-200/80 shadow-xs cursor-pointer hover:border-slate-300 transition-all active:scale-98"
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600">
              Pendientes
            </span>
            <div className="w-7 h-7 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CheckSquare className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-[#111827]">
            {pendingAgreements.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Acuerdos por cumplir
          </div>
        </div>
      </div>

      {/* 6. Cursos Registrados y Proyectos */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#6857E8]" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Cursos y Proyectos Activos
            </h2>
          </div>
          <button
            onClick={() => onNavigate('configuracion')}
            className="text-[11px] font-bold text-[#6857E8] hover:underline"
          >
            Editar
          </button>
        </div>

        <div className="space-y-2">
          {settings.courses.map((course) => (
            <div
              key={course.id}
              className="p-3 rounded-2xl border border-slate-150 bg-[#F5F6FA]/70 flex flex-col gap-1.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: course.color || '#6857E8' }}
                  />
                  <span>{course.name}</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500 font-bold bg-white px-1.5 py-0.5 rounded border border-slate-200">
                  {course.code}
                </span>
              </div>

              {course.projects && course.projects.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1 pl-4">
                  {course.projects.map((proj) => (
                    <span
                      key={proj.id}
                      className="text-[10px] px-2 py-0.5 rounded-lg bg-white text-slate-700 border border-slate-200 font-medium"
                    >
                      {proj.name}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 7. Reuniones Recientes */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Reuniones Recientes
            </h2>
          </div>
          <button
            onClick={() => onNavigate('historial')}
            className="text-[11px] font-bold text-[#6857E8] hover:underline flex items-center gap-0.5"
          >
            <span>Ver todas</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentMeetings.length === 0 ? (
          <div className="py-6 text-center text-slate-400 text-xs">
            Aún no hay reuniones registradas. Pulsa "Iniciar Reunión" para empezar.
          </div>
        ) : (
          <div className="space-y-2">
            {recentMeetings.map((m) => (
              <div
                key={m.id}
                onClick={() => onSelectMeetingDetail(m)}
                className="p-3 rounded-2xl border border-slate-150 hover:border-indigo-200 bg-[#F5F6FA]/50 hover:bg-indigo-50/20 transition-all cursor-pointer flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold text-[#6857E8] bg-[#6857E8]/10 px-1.5 py-0.2 rounded">
                      Semana {m.weekNumber}
                    </span>
                    <span className="text-xs font-bold text-slate-900 truncate">
                      {m.courseName}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate mt-0.5">
                    {m.projectName} · {m.startDate}
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <span className="text-[10px] font-semibold text-slate-400 bg-white px-2 py-1 rounded-lg border border-slate-200">
                    {formatDuration(m.durationSeconds)}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 8. Aviso Discreto sobre la Versión Demostrativa en el Pie de Página */}
      <footer className="pt-2 pb-6 px-1 text-center">
        <div className="p-3.5 rounded-2xl bg-slate-200/40 border border-slate-300/50 text-slate-500 text-[11px] leading-relaxed max-w-sm mx-auto font-normal">
          «Estás viendo una versión demostrativa de CampUs, nuestro proyecto de comunicación y coordinación para grupos universitarios. Esta versión permite conocer y explorar cómo funcionaría la propuesta. Algunas funcionalidades todavía son simuladas y podrían no estar disponibles como en la versión final del producto».
        </div>
      </footer>
    </div>
  );
};
