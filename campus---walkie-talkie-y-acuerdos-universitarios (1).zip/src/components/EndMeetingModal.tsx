import React from 'react';
import { 
  X, 
  CheckCircle2, 
  Disc, 
  FileText, 
  CheckSquare, 
  PenTool, 
  Radio, 
  Calendar, 
  Clock, 
  Download,
  FolderArchive,
  Sparkles
} from 'lucide-react';
import { MeetingSession } from '../types/campus';
import { formatDuration, formatTime } from '../utils/academic';
import { soundEffects } from '../utils/sound';

interface EndMeetingModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeMeeting: MeetingSession | null;
  onConfirmEndMeeting: () => void;
}

export const EndMeetingModal: React.FC<EndMeetingModalProps> = ({
  isOpen,
  onClose,
  activeMeeting,
  onConfirmEndMeeting,
}) => {
  if (!isOpen || !activeMeeting) return null;

  const now = new Date();
  const currentEndTime = formatTime(now);

  const cleanCourse = activeMeeting.courseName.replace(/\s+/g, '_');
  const dateStr = activeMeeting.startDate || now.toISOString().slice(0, 10);
  const anticipatedZipName = `CampUs_${cleanCourse}_Semana${activeMeeting.weekNumber}_${dateStr}.zip`;

  const handleConfirm = () => {
    soundEffects.playSuccess();
    onConfirmEndMeeting();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-3.5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <FolderArchive className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 leading-tight">
                Finalizar y Descargar ZIP
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Guarda la sesión y descarga todos los archivos al dispositivo
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Meeting metadata summary */}
        <div className="p-3.5 rounded-2xl bg-[#F5F6FA] border border-slate-200 text-xs space-y-2">
          <div className="flex items-center justify-between font-bold">
            <span className="text-slate-900">{activeMeeting.courseName}</span>
            <span className="text-[#6857E8] bg-[#6857E8]/10 px-2 py-0.5 rounded-md text-[10px]">
              Semana {activeMeeting.weekNumber}
            </span>
          </div>
          <div className="text-slate-600 text-[11px]">
            {activeMeeting.projectName} · {activeMeeting.groupName}
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
            <span>Inicio: {activeMeeting.startTime}</span>
            <span>Fin: {currentEndTime}</span>
            <span>Duración: {formatDuration(activeMeeting.durationSeconds || 120)}</span>
          </div>
        </div>

        {/* Content checklist of what will be stored */}
        <div className="space-y-1.5 text-xs text-slate-700">
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Archivos generados para el paquete ZIP:
          </span>

          <div className="grid grid-cols-2 gap-2">
            <div className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#4778F5]" />
              <div className="min-w-0">
                <div className="text-[10px] text-slate-400">Block de Notas</div>
                <div className="font-bold text-slate-900">{activeMeeting.notes.length} apunte(s)</div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-[#42C99A]" />
              <div className="min-w-0">
                <div className="text-[10px] text-slate-400">Acuerdos</div>
                <div className="font-bold text-slate-900">{activeMeeting.agreements.length} acuerdo(s)</div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center gap-2">
              <PenTool className="w-4 h-4 text-[#6857E8]" />
              <div className="min-w-0">
                <div className="text-[10px] text-slate-400">Pizarra Infinita</div>
                <div className="font-bold text-slate-900">{activeMeeting.drawings.length} boceto(s)</div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-amber-500" />
              <div className="min-w-0">
                <div className="text-[10px] text-slate-400">Walkie-Talkie</div>
                <div className="font-bold text-slate-900">{activeMeeting.walkieTransmissions.length} registro(s)</div>
              </div>
            </div>
          </div>
        </div>

        {/* Automatic ZIP Download Prominent Box */}
        <div className="p-3 bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/90 rounded-2xl flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-sm">
            <Download className="w-5 h-5 animate-bounce" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-xs font-black text-emerald-900">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Descarga Automática Activada</span>
            </div>
            <p className="text-[11px] text-emerald-800/80 truncate font-mono mt-0.5">
              {anticipatedZipName}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
          >
            Volver a la reunión
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold transition-all shadow-md shadow-emerald-600/30 active:scale-95 flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>FINALIZAR Y DESCARGAR ZIP</span>
          </button>
        </div>
      </div>
    </div>
  );
};
