import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Calendar, 
  User, 
  CheckCircle, 
  Circle, 
  Trash2, 
  Edit3, 
  Search, 
  Filter, 
  AlertTriangle,
  Clock,
  BookOpen
} from 'lucide-react';
import { AgreementItem, MeetingSession, AcademicSettings } from '../types/campus';
import { DEMO_PARTICIPANTS } from '../config/initialData';
import { soundEffects } from '../utils/sound';

interface AgreementsViewProps {
  agreements: AgreementItem[];
  activeMeeting: MeetingSession | null;
  settings: AcademicSettings;
  onAddAgreement: (agr: AgreementItem) => void;
  onUpdateAgreement: (agr: AgreementItem) => void;
  onToggleStatus: (id: string) => void;
  onDeleteAgreement: (id: string) => void;
}

export const AgreementsView: React.FC<AgreementsViewProps> = ({
  agreements,
  activeMeeting,
  settings,
  onAddAgreement,
  onUpdateAgreement,
  onToggleStatus,
  onDeleteAgreement,
}) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAgrId, setEditingAgrId] = useState<string | null>(null);

  // Form fields
  const [description, setDescription] = useState('');
  const [assignee, setAssignee] = useState('Diego');
  const [customAssignee, setCustomAssignee] = useState('');
  const [deadline, setDeadline] = useState('Viernes 18:00');
  const [status, setStatus] = useState<'pending' | 'completed'>('pending');
  const [courseId, setCourseId] = useState(activeMeeting?.courseId || settings.courses[0]?.id || '');
  const [weekNumber, setWeekNumber] = useState(activeMeeting?.weekNumber || 7);

  // Filter & Search
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [agreementToDelete, setAgreementToDelete] = useState<AgreementItem | null>(null);

  const handleOpenNew = () => {
    setEditingAgrId(null);
    setDescription('');
    setAssignee('Diego');
    setCustomAssignee('');
    setDeadline('Viernes 18:00');
    setStatus('pending');
    if (activeMeeting) {
      setCourseId(activeMeeting.courseId);
      setWeekNumber(activeMeeting.weekNumber);
    } else {
      setCourseId(settings.courses[0]?.id || '');
      setWeekNumber(7);
    }
    setIsFormOpen(true);
    soundEffects.playSuccess();
  };

  const handleOpenEdit = (agr: AgreementItem) => {
    setEditingAgrId(agr.id);
    setDescription(agr.description);
    setAssignee(DEMO_PARTICIPANTS.some((p) => p.name === agr.assignee) ? agr.assignee : 'Otro');
    setCustomAssignee(DEMO_PARTICIPANTS.some((p) => p.name === agr.assignee) ? '' : agr.assignee);
    setDeadline(agr.deadline);
    setStatus(agr.status);
    setCourseId(agr.courseId);
    setWeekNumber(agr.weekNumber);
    setIsFormOpen(true);
    soundEffects.playSuccess();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    const finalAssignee = assignee === 'Otro' ? (customAssignee.trim() || 'Compañero') : assignee;
    const courseObj = settings.courses.find((c) => c.id === courseId);

    if (editingAgrId) {
      const existing = agreements.find((a) => a.id === editingAgrId);
      if (existing) {
        onUpdateAgreement({
          ...existing,
          description: description.trim(),
          assignee: finalAssignee,
          deadline: deadline.trim() || 'Sin fecha',
          status,
          courseId,
          courseName: courseObj ? courseObj.name : 'Curso General',
          weekNumber,
        });
      }
    } else {
      const newAgr: AgreementItem = {
        id: `agr-${Date.now()}`,
        description: description.trim(),
        assignee: finalAssignee,
        deadline: deadline.trim() || 'Sin fecha',
        status,
        createdAt: 'Hoy',
        courseId,
        courseName: courseObj ? courseObj.name : 'Curso General',
        weekNumber,
        meetingId: activeMeeting?.id,
      };
      onAddAgreement(newAgr);
    }

    soundEffects.playSuccess();
    setIsFormOpen(false);
    setEditingAgrId(null);
  };

  const confirmDelete = () => {
    if (agreementToDelete) {
      onDeleteAgreement(agreementToDelete.id);
      soundEffects.playPttEnd();
      setAgreementToDelete(null);
    }
  };

  const filteredAgreements = agreements.filter((agr) => {
    if (statusFilter !== 'all' && agr.status !== statusFilter) return false;
    if (courseFilter !== 'all' && agr.courseId !== courseFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchDesc = agr.description.toLowerCase().includes(q);
      const matchAssignee = agr.assignee.toLowerCase().includes(q);
      const matchCourse = agr.courseName.toLowerCase().includes(q);
      if (!matchDesc && !matchAssignee && !matchCourse) return false;
    }
    return true;
  });

  const pendingCount = agreements.filter((a) => a.status === 'pending').length;
  const completedCount = agreements.filter((a) => a.status === 'completed').length;

  return (
    <div className="flex flex-col gap-4 pb-28 px-4 pt-3 select-none">
      {/* Header Bar */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-[#42C99A]" />
            Acuerdos y Responsables
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Registro manual de compromisos del equipo
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-[#111827] hover:bg-slate-800 text-white text-xs font-bold rounded-2xl shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4 text-[#42C99A]" />
          <span>Nuevo Acuerdo</span>
        </button>
      </div>

      {/* Active meeting notice */}
      {activeMeeting && (
        <div className="p-2.5 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-center justify-between text-xs font-medium text-slate-800">
          <div className="flex items-center gap-2 truncate">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shrink-0" />
            <span className="truncate">
              Vinculando a la sesión de: <strong>{activeMeeting.courseName}</strong> (Semana {activeMeeting.weekNumber})
            </span>
          </div>
        </div>
      )}

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600">Pendientes</span>
            <div className="text-xl font-extrabold text-slate-900">{pendingCount}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xs">
            ⏳
          </div>
        </div>

        <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#42C99A]">Completados</span>
            <div className="text-xl font-extrabold text-slate-900">{completedCount}</div>
          </div>
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs">
            ✓
          </div>
        </div>
      </div>

      {/* Formulario Manual de Acuerdos */}
      {isFormOpen && (
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-3xl p-4 shadow-md border border-slate-200 animate-in fade-in slide-in-from-top-2 duration-150 space-y-3"
        >
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              {editingAgrId ? 'Editar Acuerdo' : 'Registrar Nuevo Acuerdo'}
            </span>
            <span className="text-[10px] text-slate-400 font-medium">Registro manual</span>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Descripción del acuerdo:
            </label>
            <input
              type="text"
              placeholder="Ej. Entregar las fuentes y marco teórico"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#42C99A]/40"
            />
          </div>

          {/* Responsable */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Responsable:
            </label>
            <div className="grid grid-cols-4 gap-1.5 mb-1.5">
              {DEMO_PARTICIPANTS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setAssignee(p.name);
                    setCustomAssignee('');
                  }}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold truncate transition-all ${
                    assignee === p.name
                      ? 'bg-[#111827] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setAssignee('Otro')}
              className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                assignee === 'Otro' ? 'bg-[#111827] text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              + Otro nombre
            </button>
            {assignee === 'Otro' && (
              <input
                type="text"
                placeholder="Nombre del responsable..."
                value={customAssignee}
                onChange={(e) => setCustomAssignee(e.target.value)}
                className="w-full mt-1.5 text-xs px-3 py-2 rounded-xl border border-slate-200 bg-[#F5F6FA]"
              />
            )}
          </div>

          {/* Fecha Límite */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Fecha límite:
            </label>
            <div className="flex gap-1.5 mb-1.5 flex-wrap">
              {['Hoy', 'Mañana', 'Viernes 18:00', 'Sábado', 'Lunes 10:00'].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setDeadline(preset)}
                  className={`text-[10px] px-2.5 py-1 rounded-lg border font-medium transition-all ${
                    deadline === preset
                      ? 'bg-indigo-50 border-indigo-300 text-indigo-700 font-bold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
            <input
              type="text"
              placeholder="O escribe la fecha límite personalizada..."
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 bg-[#F5F6FA]"
            />
          </div>

          {/* Curso & Semana */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Curso:</label>
              <select
                value={courseId}
                onChange={(e) => setCourseId(e.target.value)}
                className="w-full text-xs font-medium px-2.5 py-1.5 rounded-xl border border-slate-200 bg-[#F5F6FA]"
              >
                {settings.courses.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-600 block mb-1">Semana:</label>
              <input
                type="number"
                min={1}
                max={settings.totalWeeks}
                value={weekNumber}
                onChange={(e) => setWeekNumber(Number(e.target.value))}
                className="w-full text-xs font-medium px-2.5 py-1.5 rounded-xl border border-slate-200 bg-[#F5F6FA]"
              />
            </div>
          </div>

          {/* Estado inicial */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Estado:</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStatus('pending')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                  status === 'pending'
                    ? 'bg-amber-50 border-amber-300 text-amber-800'
                    : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                }`}
              >
                Pendiente
              </button>
              <button
                type="button"
                onClick={() => setStatus('completed')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                  status === 'completed'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                    : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                }`}
              >
                Completado
              </button>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-[#42C99A] hover:bg-[#36b387] text-slate-950 text-xs font-bold rounded-xl transition-all shadow-sm"
            >
              Guardar Acuerdo
            </button>
          </div>
        </form>
      )}

      {/* Buscador & Filtros de Estado */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por acuerdo, responsable o curso..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-9 pr-3 py-2 rounded-2xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-[#42C99A]/40"
          />
        </div>

        {/* State Filter Buttons */}
        <div className="flex items-center gap-1 p-1 bg-white rounded-2xl border border-slate-200">
          <button
            onClick={() => setStatusFilter('all')}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              statusFilter === 'all' ? 'bg-[#111827] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Todos ({agreements.length})
          </button>
          <button
            onClick={() => setStatusFilter('pending')}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              statusFilter === 'pending' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pendientes ({pendingCount})
          </button>
          <button
            onClick={() => setStatusFilter('completed')}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              statusFilter === 'completed' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Completados ({completedCount})
          </button>
        </div>
      </div>

      {/* Lista Visual de Acuerdos */}
      <div className="space-y-2.5">
        {filteredAgreements.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-dashed border-slate-200">
            <CheckSquare className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="text-xs font-bold text-slate-700">No hay acuerdos con los filtros actuales</h4>
            <p className="text-[11px] text-slate-400 mt-1">
              Usa "Nuevo Acuerdo" para registrar compromisos del equipo.
            </p>
          </div>
        ) : (
          filteredAgreements.map((agr) => {
            const isCompleted = agr.status === 'completed';
            return (
              <div
                key={agr.id}
                className={`p-3.5 rounded-3xl border transition-all bg-white shadow-xs flex items-start gap-3 ${
                  isCompleted ? 'border-emerald-200 bg-emerald-50/20' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Checkbox táctil */}
                <button
                  type="button"
                  onClick={() => {
                    onToggleStatus(agr.id);
                    soundEffects.playSuccess();
                  }}
                  className="mt-0.5 shrink-0 focus:outline-none transition-transform active:scale-90"
                  title={isCompleted ? 'Marcar pendiente' : 'Marcar completado'}
                >
                  {isCompleted ? (
                    <div className="w-6 h-6 rounded-lg bg-[#42C99A] text-slate-950 flex items-center justify-center shadow-xs">
                      <CheckCircle className="w-4 h-4 fill-slate-950 text-[#42C99A]" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-lg border-2 border-slate-300 hover:border-slate-400 flex items-center justify-center bg-white">
                      <Circle className="w-3.5 h-3.5 text-transparent" />
                    </div>
                  )}
                </button>

                {/* Body */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5 mb-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#6857E8]/10 text-[#6857E8]">
                      {agr.courseName}
                    </span>
                    <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700">
                      Semana {agr.weekNumber}
                    </span>
                    <span
                      className={`ml-auto text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        isCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isCompleted ? 'Completado' : 'Pendiente'}
                    </span>
                  </div>

                  <h3
                    className={`text-xs font-bold leading-tight ${
                      isCompleted ? 'text-slate-400 line-through' : 'text-slate-900'
                    }`}
                  >
                    {agr.description}
                  </h3>

                  <div className="flex flex-wrap items-center gap-2 mt-2 text-[11px] text-slate-600 font-medium">
                    <div className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                      <User className="w-3 h-3 text-[#6857E8]" />
                      <span>{agr.assignee}</span>
                    </div>

                    <div className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                      <Calendar className="w-3 h-3 text-[#4778F5]" />
                      <span>{agr.deadline}</span>
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleOpenEdit(agr)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                    title="Editar acuerdo"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setAgreementToDelete(agr)}
                    className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50"
                    title="Eliminar acuerdo"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Confirmación Borrar */}
      {agreementToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-sm font-extrabold text-slate-900">
              ¿Eliminar este acuerdo?
            </h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              "{agreementToDelete.description}" de {agreementToDelete.assignee} se eliminará permanentemente.
            </p>

            <div className="flex items-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => setAgreementToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-all shadow-md shadow-red-600/30"
              >
                Sí, Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
