import React, { useState } from 'react';
import { 
  Settings, 
  Calendar, 
  BookOpen, 
  Plus, 
  Trash2, 
  Save, 
  Check, 
  Layers, 
  Sparkles,
  Info
} from 'lucide-react';
import { AcademicSettings, Course, Project } from '../types/campus';
import { calculateAcademicWeek } from '../utils/academic';
import { soundEffects } from '../utils/sound';

interface AcademicConfigViewProps {
  settings: AcademicSettings;
  onSaveSettings: (settings: AcademicSettings) => void;
}

export const AcademicConfigView: React.FC<AcademicConfigViewProps> = ({
  settings,
  onSaveSettings,
}) => {
  const [startDate, setStartDate] = useState(settings.startDate);
  const [totalWeeks, setTotalWeeks] = useState(settings.totalWeeks || 16);
  const [courses, setCourses] = useState<Course[]>(settings.courses);

  // New course input
  const [newCourseName, setNewCourseName] = useState('');
  const [newCourseCode, setNewCourseCode] = useState('');
  const [newCourseColor, setNewCourseColor] = useState('#6857E8');

  // New project state per course
  const [activeCourseIdForProject, setActiveCourseIdForProject] = useState<string | null>(null);
  const [newProjectName, setNewProjectName] = useState('');

  const [savedFeedback, setSavedFeedback] = useState(false);

  // Live calculation of current academic week based on entered start date
  const weekInfo = calculateAcademicWeek(startDate, totalWeeks);

  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCourseName.trim()) return;

    const newCourse: Course = {
      id: `course-${Date.now()}`,
      name: newCourseName.trim(),
      code: newCourseCode.trim() || 'CURSO',
      color: newCourseColor,
      projects: [],
    };

    setCourses([...courses, newCourse]);
    setNewCourseName('');
    setNewCourseCode('');
    soundEffects.playSuccess();
  };

  const handleDeleteCourse = (id: string) => {
    setCourses(courses.filter((c) => c.id !== id));
    soundEffects.playPttEnd();
  };

  const handleAddProject = (courseId: string) => {
    if (!newProjectName.trim()) return;

    setCourses(
      courses.map((c) => {
        if (c.id === courseId) {
          const newProj: Project = {
            id: `proj-${Date.now()}`,
            name: newProjectName.trim(),
          };
          return { ...c, projects: [...(c.projects || []), newProj] };
        }
        return c;
      })
    );

    setNewProjectName('');
    setActiveCourseIdForProject(null);
    soundEffects.playSuccess();
  };

  const handleDeleteProject = (courseId: string, projectId: string) => {
    setCourses(
      courses.map((c) => {
        if (c.id === courseId) {
          return {
            ...c,
            projects: c.projects.filter((p) => p.id !== projectId),
          };
        }
        return c;
      })
    );
    soundEffects.playPttEnd();
  };

  const handleSaveAll = () => {
    onSaveSettings({
      startDate,
      totalWeeks: Math.max(1, totalWeeks),
      courses,
    });
    soundEffects.playSuccess();
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 2500);
  };

  return (
    <div className="flex flex-col gap-4 pb-28 px-4 pt-3 select-none">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#6857E8]" />
            Configuración Académica
          </h1>
          <p className="text-xs text-slate-500 font-medium">
            Fecha de inicio, semanas, cursos y proyectos
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-[#6857E8] hover:bg-[#5746db] text-white text-xs font-bold rounded-2xl shadow-md shadow-[#6857E8]/20 transition-all active:scale-95"
        >
          <Save className="w-4 h-4" />
          <span>Guardar Cambios</span>
        </button>
      </div>

      {savedFeedback && (
        <div className="p-3 bg-emerald-500 text-slate-950 font-bold text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 animate-in fade-in duration-150">
          <Check className="w-4 h-4" />
          <span>Configuración académica guardada correctamente</span>
        </div>
      )}

      {/* 1. Calendario del Ciclo y Cálculo Automático de Semana */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <Calendar className="w-4 h-4 text-[#6857E8]" />
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Ciclo Académico y Semanas
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Fecha de inicio del ciclo:
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/30"
            />
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              Se introduce una sola vez y rige el cálculo del ciclo.
            </span>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Número de semanas del ciclo:
            </label>
            <input
              type="number"
              min={1}
              max={30}
              value={totalWeeks}
              onChange={(e) => setTotalWeeks(Number(e.target.value))}
              className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 bg-[#F5F6FA] focus:outline-none focus:ring-2 focus:ring-[#6857E8]/30"
            />
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              Valor estándar universitario: 16 semanas.
            </span>
          </div>
        </div>

        {/* Live Calculation Display */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Cálculo de Semana Automático
            </span>
            <div className="text-sm font-black text-[#6857E8] mt-0.5">
              {weekInfo.label}
            </div>
          </div>
          <span className="text-xs font-semibold text-slate-600 bg-white px-2.5 py-1 rounded-xl border border-slate-200">
            {weekInfo.daysElapsed >= 0 ? `${weekInfo.daysElapsed} días transcurridos` : 'Ciclo futuro'}
          </span>
        </div>
      </div>

      {/* 2. Cursos y Proyectos Asociados */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200/80 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#6857E8]" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Cursos Registrados ({courses.length})
            </h2>
          </div>
        </div>

        {/* Formulario rápido para añadir curso */}
        <form onSubmit={handleAddCourse} className="p-3 rounded-2xl bg-[#F5F6FA] border border-slate-200 space-y-2">
          <span className="text-[11px] font-bold text-slate-700 block">Agregar nuevo curso:</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              placeholder="Nombre del curso (ej. Marketing Estratégico)"
              value={newCourseName}
              onChange={(e) => setNewCourseName(e.target.value)}
              required
              className="text-xs px-3 py-2 rounded-xl border border-slate-200 bg-white sm:col-span-2"
            />
            <input
              type="text"
              placeholder="Código (ej. MKT-201)"
              value={newCourseCode}
              onChange={(e) => setNewCourseCode(e.target.value)}
              className="text-xs px-3 py-2 rounded-xl border border-slate-200 bg-white"
            />
          </div>
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-500 font-medium">Color:</span>
              {['#6857E8', '#4778F5', '#42C99A', '#F59E0B', '#EF4444'].map((col) => (
                <button
                  key={col}
                  type="button"
                  onClick={() => setNewCourseColor(col)}
                  className={`w-5 h-5 rounded-full border ${newCourseColor === col ? 'ring-2 ring-slate-900 scale-110' : ''}`}
                  style={{ backgroundColor: col }}
                />
              ))}
            </div>

            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl bg-[#111827] text-white text-xs font-bold hover:bg-slate-800 transition-colors"
            >
              + Agregar Curso
            </button>
          </div>
        </form>

        {/* Lista de Cursos y Proyectos */}
        <div className="space-y-3 pt-2">
          {courses.map((course) => (
            <div
              key={course.id}
              className="p-3.5 rounded-2xl border border-slate-200 bg-white space-y-2.5 shadow-2xs"
            >
              {/* Course Title Row */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: course.color || '#6857E8' }}
                  />
                  <h3 className="font-extrabold text-xs text-slate-900">{course.name}</h3>
                  <span className="text-[10px] font-mono text-slate-400 font-bold bg-slate-100 px-1.5 py-0.2 rounded">
                    {course.code}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleDeleteCourse(course.id)}
                  className="p-1 rounded-lg text-slate-400 hover:text-red-600 transition-colors"
                  title="Eliminar curso"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Projects of this course */}
              <div className="pl-5 space-y-1.5 border-l-2 border-slate-100">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                  <span>Proyectos del curso:</span>
                  <button
                    type="button"
                    onClick={() => setActiveCourseIdForProject(activeCourseIdForProject === course.id ? null : course.id)}
                    className="text-[10px] text-[#6857E8] font-bold hover:underline"
                  >
                    + Agregar proyecto
                  </button>
                </div>

                {/* Add project input if open */}
                {activeCourseIdForProject === course.id && (
                  <div className="flex items-center gap-1.5 pt-1">
                    <input
                      type="text"
                      placeholder="Nombre del proyecto (ej. Trabajo Final)"
                      value={newProjectName}
                      onChange={(e) => setNewProjectName(e.target.value)}
                      className="flex-1 text-xs px-2.5 py-1.5 rounded-xl border border-slate-200 bg-[#F5F6FA]"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddProject(course.id)}
                      className="px-2.5 py-1.5 bg-[#6857E8] text-white text-xs font-bold rounded-xl"
                    >
                      Añadir
                    </button>
                  </div>
                )}

                {/* List of projects */}
                {(!course.projects || course.projects.length === 0) ? (
                  <div className="text-[10px] text-slate-400 italic">
                    Sin proyectos asociados aún.
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {course.projects.map((proj) => (
                      <span
                        key={proj.id}
                        className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-1 rounded-xl bg-slate-100 text-slate-700 border border-slate-200/80"
                      >
                        <span>{proj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteProject(course.id, proj.id)}
                          className="text-slate-400 hover:text-red-500 ml-1"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
