import React from 'react';
import { 
  Home, 
  Radio, 
  FileText, 
  CheckSquare, 
  PenTool, 
  FolderClock, 
  Settings, 
  SquareCheck,
  Disc,
  XCircle
} from 'lucide-react';
import { NavigationTab, MeetingSession } from '../types/campus';
import { soundEffects } from '../utils/sound';

interface BottomNavProps {
  activeTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  activeMeeting: MeetingSession | null;
  onOpenEndMeetingModal: () => void;
  pendingAgreementsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onNavigate,
  activeMeeting,
  onOpenEndMeetingModal,
  pendingAgreementsCount,
}) => {
  const tabs = [
    { id: 'inicio' as NavigationTab, label: 'Inicio', icon: Home },
    { id: 'comunicacion' as NavigationTab, label: 'Voz', icon: Radio },
    { id: 'apuntes' as NavigationTab, label: 'Apuntes', icon: FileText },
    { id: 'acuerdos' as NavigationTab, label: 'Acuerdos', icon: CheckSquare, badge: pendingAgreementsCount > 0 ? pendingAgreementsCount : null },
    { id: 'pizarra' as NavigationTab, label: 'Pizarra', icon: PenTool },
    { id: 'historial' as NavigationTab, label: 'Historial', icon: FolderClock },
    { id: 'configuracion' as NavigationTab, label: 'Ajustes', icon: Settings },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 max-w-lg mx-auto">
      {/* Active Meeting Session Floating Strip if a meeting is running */}
      {activeMeeting && (
        <div className="mx-2 mb-1.5 p-2 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 shadow-xl flex items-center justify-between gap-2 animate-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse shrink-0 ml-1" />
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-wider text-red-400 font-extrabold flex items-center gap-1">
                <span>Sesión en Vivo</span>
                <span>·</span>
                <span className="text-slate-300 font-semibold">{activeMeeting.projectName}</span>
              </div>
              <div className="text-xs font-bold text-white truncate">
                {activeMeeting.courseName}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                onNavigate('comunicacion');
                soundEffects.playSuccess();
              }}
              className="px-2.5 py-1 rounded-xl bg-[#6857E8] text-white text-[11px] font-bold hover:bg-[#5746db] transition-colors"
            >
              Hablar
            </button>
            <button
              onClick={onOpenEndMeetingModal}
              className="px-2.5 py-1 rounded-xl bg-red-600 hover:bg-red-700 text-white text-[11px] font-bold transition-colors shadow-sm"
            >
              Finalizar
            </button>
          </div>
        </div>
      )}

      {/* Main 7-Section Bottom Navigation Bar */}
      <nav className="bg-[#111827]/95 backdrop-blur-md border-t border-slate-800 px-1 py-1 shadow-2xl select-none">
        <div className="grid grid-cols-7 gap-0.5 items-center">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;

            return (
              <button
                key={tab.id}
                onClick={() => {
                  onNavigate(tab.id);
                  soundEffects.playSuccess();
                }}
                className={`min-h-[48px] flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all relative ${
                  isActive
                    ? 'text-white bg-slate-800/90 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 font-medium'
                }`}
                aria-label={tab.label}
              >
                {/* Active Indicator Pip */}
                {isActive && (
                  <span className="absolute top-1 w-4 h-0.5 rounded-full bg-[#6857E8]" />
                )}

                <div className="relative">
                  <Icon
                    className={`w-4 h-4 transition-transform ${
                      isActive ? 'scale-110 text-[#42C99A]' : 'text-slate-400'
                    }`}
                  />
                  {tab.badge && (
                    <span className="absolute -top-1 -right-2 text-[8px] font-black bg-amber-500 text-slate-950 px-1 rounded-full">
                      {tab.badge}
                    </span>
                  )}
                </div>

                <span className="text-[9px] mt-0.5 tracking-tight truncate max-w-full">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
