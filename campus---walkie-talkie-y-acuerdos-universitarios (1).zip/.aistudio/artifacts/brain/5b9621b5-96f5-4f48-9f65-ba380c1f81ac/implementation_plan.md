# CampUs — Prototipo Maestro de Demostración Universitaria

Prototipo interactivo móvil de alta fidelidad para estudiantes universitarios que realizan trabajos grupales, integrando comunicación por voz simulada (walkie-talkie), grabación de sesiones, apuntes manuales, acuerdos con responsables, pizarra de dibujo HTML5 Canvas y organización automática por curso y semana académica para encontrar lo trabajado en menos de un minuto.

---

## Decisiones Críticas y Preferencias Confirmadas

> [!IMPORTANT]
> Decisiones de experiencia acordadas con el usuario durante la fase de clarificación:
> - **Datos Iniciales**: Se incluye un ciclo académico de demostración precargado con cursos (ej. *Emprendimiento I*, *Proyecto de Investigación*, *Laboratorio*) y proyectos editables, permitiendo probar la app inmediatamente o personalizarla en la sección de Configuración.
> - **Navegación en Reunión**: Durante una reunión en curso se activa una barra de sesión dedicada con acceso rápido a Walkie-Talkie, Grabación, Apuntes, Acuerdos, Pizarra y el botón "Finalizar Reunión".
> - **Pizarra y Dibujos**: El lienzo se guarda automáticamente como dibujo de la sesión al pulsar "Finalizar Reunión", además de permitir exportar o descargar la imagen en cualquier momento.

---

### 1. Visión General y Concepto Central

- **Propósito**: Facilitar la coordinación y el registro de decisiones en trabajos grupales universitarios sin perder el rastro de acuerdos ni saturarse de videollamadas.
- **Promesa de Valor**: *"Para estudiantes que hacen trabajos grupales, CampUs permite hablar por voz con una persona, un grupo o todo el equipo, grabar la reunión y guardar sus apuntes, acuerdos y dibujos por curso y semana para encontrar lo trabajado en menos de un minuto."*
- **Público Objetivo**: Estudiantes universitarios de pregrado y posgrado coordinando entregables en múltiples cursos simultáneos.
- **Alcance del Prototipo**:
  - Funcional localmente: Configuración académica, cálculo automático de semanas, apuntes, acuerdos, pizarra táctil HTML5 y archivo de reuniones en `localStorage`.
  - Simulado: Transmisión de voz walkie-talkie, grabación de reunión y colaboración multicelular (sin acceso al micrófono, sin backend, sin dependencias de IA).

---

### 2. Experiencia de Usuario y Diseño Visual

#### Flujo de Usuario Principal
1. **Inicio**: Dashboard con saludo, fecha local, semana académica actual calculada automáticamente, cursos, proyectos activos, acuerdos pendientes y botón destacado **"INICIAR REUNIÓN"**.
2. **Modal Iniciar Reunión**: Selección de curso, proyecto, nombre de grupo y participantes de demostración. Fecha, hora y semana académica autocompletadas.
3. **Modo Reunión Activa**:
   - **Walkie-Talkie**: Selector de destinatario (*Todos*, *Grupo*, *Persona*) con botón táctil PTT (PointerDown/Up con ondas animadas, audio sintetizado web y prevención de bloqueo).
   - **Grabación Simulada**: Modal de consentimiento informado previo, timer rojo en vivo, controles de pausa y finalización.
   - **Apuntes**: Creación, edición, eliminación con confirmación, vinculados a la sesión.
   - **Acuerdos**: Registro de descripción, responsable, fecha límite y estado con filtros.
   - **Pizarra Canvas**: Dibujo con dedo/mouse, selector de trazo/color, borrador, deshacer y limpieza.
   - **Finalizar Reunión**: Empaqueta todo en una sesión consolidada, confirma el guardado y almacena en el historial.
4. **Historial**: Vista agrupada por Curso y Semana lectiva, buscador en tiempo real, filtros y vista detallada con pestañas (*Grabación*, *Apuntes*, *Acuerdos*, *Dibujos*).
5. **Configuración Académica**: Edición de fecha de inicio del ciclo, número de semanas (default 16), gestión de cursos y proyectos con cálculo dinámico del estado del ciclo (*Antes del ciclo*, *Semana 1 a 16*, *Ciclo finalizado*).

#### Identidad Visual y Paleta de Colores
- **Fondo / Lienzo Neutro**: Azul noche `#111827` en elementos oscuros / Gris claro `#F5F6FA` en área de contenido.
- **Color Primario Marca**: Violeta `#6857E8`.
- **Acento Secundario**: Azul `#4778F5`.
- **Acento Positivo**: Verde menta `#42C99A`.
- **Superficies**: Blanco `#FFFFFF` y bordes sutiles sin saturación visual.
- **Tipografía**: Plus Jakarta Sans / Inter con jerarquía tipográfica limpia y números tabulares (`tabular-nums`).
- **Ergonomía Móvil**: Botones con área táctil $\ge 44\text{px}$, barra inferior flotante con blur (`backdrop-blur-md`), adaptable también a escritorio con marco simulador o vista fluida.

---

### 3. Decisiones de Producto y Arquitectura de Estado

- **Cálculo de Semana Académica**:
  $$\text{weekNumber} = 1 + \left\lfloor \frac{\text{currentDate} - \text{semesterStartDate}}{7 \times 24 \times 60 \times 60 \times 1000} \right\rfloor$$
  Se maneja con normalización de zona horaria local a medianoche para evitar desfasajes horarios.
- **Pizarra HTML5 Canvas**: Canvas responsivo con soporte táctil (`touch-action: none`), buffers de trazo, selector de pincel y guardado del dibujo en formato base64/PNG dentro de la sesión.
- **Persistencia Local**: `localStorage` estructurado con esquema versionado para configuración, reuniones históricas, apuntes y acuerdos globales.

---

### 4. Arquitectura del Sistema y Flujo de Datos

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CampUs Application Core                         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
    ┌───────────────────────────────┼──────────────────────────────┐
    ▼                               ▼                              ▼
┌──────────────────┐    ┌────────────────────────┐    ┌──────────────────┐
│  Academic Config │    │  Active Meeting State  │    │ Persistent Store │
│  & Week Engine   │    │  (PTT, Rec, Notes,     │    │  (localStorage)  │
│  (Course/Project)│    │   Agreements, Canvas)  │    │                  │
└─────────┬────────┘    └───────────┬────────────┘    └─────────┬────────┘
          │                         │                           │
          └─────────────────────────┼───────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                          Navigation & Views                            │
├─────────────┬─────────────┬─────────────┬─────────────┬────────────────┤
│ 1. Inicio   │ 2. Walkie   │ 3. Apuntes  │ 4. Acuerdos │ 5. Pizarra     │
│             │    Talkie   │             │             │    Canvas      │
├─────────────┴─────────────┼─────────────┴─────────────┴────────────────┤
│ 6. Historial por Curso    │ 7. Configuración Académica                 │
│    y Semana (Detalle Tabs)│    (Cursos, Proyectos, Ciclo)              │
└───────────────────────────┴────────────────────────────────────────────┘
```

#### Estructura de Entidades Principales
- **AcademicSettings**: `startDate`, `totalWeeks`, `courses[]` (con sus `projects[]`).
- **MeetingSession**: `id`, `courseId`, `courseName`, `projectId`, `projectName`, `groupName`, `participants[]`, `startDate`, `startTime`, `endDate`, `endTime`, `weekNumber`, `durationSeconds`, `walkieTransmissions[]`, `recording` (duración, timestamps simulados), `notes[]`, `agreements[]`, `drawingImages[]`.
- **Note**: `id`, `title`, `content`, `author`, `createdAt`, `meetingId`, `courseId`, `weekNumber`.
- **Agreement**: `id`, `description`, `assignee`, `deadline`, `status` (*pending* | *completed*), `meetingId`, `courseId`, `weekNumber`.
